rootProject.name = "VietDictApp"
include(":app")
