# -*- coding: utf-8 -*-
"""
Clean up orphaned audio files not referenced in dict_data.json
"""
import os, json

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

with open(JSON_PATH, encoding='utf-8') as f:
    data = json.load(f)

valid_files = set(item['audio'] for item in data)
print(f"Total valid audio files needed: {len(valid_files)}")

all_files = os.listdir(AUDIO_DIR)
removed = 0
for f in all_files:
    if f not in valid_files:
        try:
            os.remove(os.path.join(AUDIO_DIR, f))
            removed += 1
        except Exception:
            pass

print(f"Removed {removed} legacy/orphaned files. Remaining files on disk: {len(os.listdir(AUDIO_DIR))}")
