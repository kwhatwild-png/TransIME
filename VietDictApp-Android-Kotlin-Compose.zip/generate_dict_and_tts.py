# -*- coding: utf-8 -*-
"""
Generate Vietnamese normalized search keys and offline TTS audio files via Google Vietnamese Neural Voice
"""
import os, sys, json, time, re, unicodedata
import urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from raw_seed import RAW_ENTRIES

OUTPUT_AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
OUTPUT_JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

os.makedirs(OUTPUT_AUDIO_DIR, exist_ok=True)
os.makedirs(os.path.dirname(OUTPUT_JSON_PATH), exist_ok=True)

def remove_vietnamese_accents(text: str) -> str:
    """
    Remove all accents and diacritics from Vietnamese text:
    tôi -> toi, cảm ơn -> cam on, đ -> d, etc.
    """
    text = text.replace('đ', 'd').replace('Đ', 'D')
    nfkd = unicodedata.normalize('NFKD', text)
    res = ''.join([c for c in nfkd if not unicodedata.combining(c)])
    return re.sub(r'\s+', ' ', res).strip().lower()

def safe_filename(text: str, index: int) -> str:
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', remove_vietnamese_accents(text)).strip('_')
    return f"{index:03d}_{slug}.mp3"

def fetch_tts_audio(text: str, retries=5):
    url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=tw-ob&q=' + urllib.parse.quote(text)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=15) as resp:
                content = resp.read()
                if len(content) > 500:
                    return content
        except Exception as e:
            if attempt == retries:
                print(f"[FAIL] TTS failed for '{text}': {e}")
                return None
            time.sleep(1.0 * attempt)
    return None

def build_database_and_audios():
    print(f"Total entries to process: {len(RAW_ENTRIES)}")
    final_dict = []

    tasks = []
    for idx, item in enumerate(RAW_ENTRIES, 1):
        vi = item["vi"].strip()
        zh = item["zh"].strip()
        cat = item["cat"].strip()
        eg_vi = item["eg_vi"].strip()
        eg_zh = item["eg_zh"].strip()
        
        norm_key = remove_vietnamese_accents(vi)
        audio_name = safe_filename(vi, idx)
        audio_path = os.path.join(OUTPUT_AUDIO_DIR, audio_name)

        entry = {
            "id": idx,
            "vi": vi,
            "norm": norm_key,
            "zh": zh,
            "cat": cat,
            "eg_vi": eg_vi,
            "eg_zh": eg_zh,
            "audio": audio_name
        }
        final_dict.append(entry)
        tasks.append((idx, vi, audio_path))

    print("Starting audio downloading and local caching...")
    
    def process_task(task):
        idx, vi, audio_path = task
        if os.path.exists(audio_path) and os.path.getsize(audio_path) > 1000:
            return idx, vi, True
        audio_bytes = fetch_tts_audio(vi)
        if audio_bytes:
            with open(audio_path, 'wb') as f:
                f.write(audio_bytes)
            return idx, vi, True
        return idx, vi, False

    success_cnt = 0
    # Use 4 threads with a polite delay to prevent rate limit
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_map = {executor.submit(process_task, t): t for t in tasks}
        for future in as_completed(future_map):
            idx, vi, ok = future.result()
            if ok:
                success_cnt += 1
            if success_cnt % 20 == 0 or success_cnt == len(tasks):
                print(f"Generated and cached {success_cnt}/{len(tasks)} audio files...")

    # Write final json
    with open(OUTPUT_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(final_dict, f, ensure_ascii=False, indent=2)

    print(f"[SUCCESS] Dictionary JSON saved to: {OUTPUT_JSON_PATH}")
    print(f"[SUCCESS] Total Audio files saved to: {OUTPUT_AUDIO_DIR}")

if __name__ == '__main__':
    build_database_and_audios()
