# -*- coding: utf-8 -*-
"""
Enrich Chinese definitions for all 1,834 Vietnamese words with natural Chinese colloquial synonyms.
Keeps original meaning accurate while expanding search triggers:
e.g.
  làm -> 做、干、搞、弄、办
  xem -> 看、瞧、查看、浏览
  đẹp -> 漂亮、美丽、好看、美观
  ngon -> 好吃、美味、可口、棒
  sửa -> 修改、修理、维修、整改
"""
import urllib.request, json, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'

JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

print(f"Total entries loaded for enrichment: {len(entries)}")

# Batch size: 60 items per prompt for high accuracy & fast processing
BATCH_SIZE = 60
batches = []
for i in range(0, len(entries), BATCH_SIZE):
    batch = entries[i:i + BATCH_SIZE]
    batches.append((i, batch))

print(f"Total batches to process: {len(batches)}")

def enrich_batch(batch_tuple, retries=5):
    start_idx, batch_items = batch_tuple
    
    # Simple input mapping for model
    compact_input = [{"id": item["id"], "vi": item["vi"], "zh": item["zh"]} for item in batch_items]
    
    prompt = f"""
你是一名资深中越双语语言学专家。为了方便中国人通过各种中文近义词和口语习惯来检索越南语，
请为以下越南语词条的中文释义（zh）进行科学扩充，补全中国人最常用的生活口语同义词、近义词或并列常见词义。

规则要求：
1. 保留原本核心词义不变；
2. 针对多义词、常用动词、形容词，扩充 2-4 个最常用的口语同义词（用顿号“、”连接），例如：
   - làm: 原来是“做”，扩充为“做、干、弄、搞、办”
   - xem: 原来是“看”，扩充为“看、瞧、查看、查阅”
   - ngon: 原来是“好吃、美味”，扩充为“好吃、美味、可口”
   - đẹp: 保持“漂亮、美丽、好看、美观”
   - đi: 原来是“去”，扩充为“去、走、出行、出发”
   - sửa: 原来是“修改”，扩充为“修改、修理、维修、整改”
3. 单一专有名词（如“水泥”、“大蒜”、“西瓜”）保持精准精炼，不要胡乱添加多余解释；
4. 严格只输出 JSON 数组，包含 "id" 和扩充后的 "zh"：
   [{{"id": 123, "zh": "扩充后的中文释义"}}]

待处理词条列表：
{json.dumps(compact_input, ensure_ascii=False)}
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.1
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=35) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                result_array = json.loads(raw)
                return {item['id']: item['zh'] for item in result_array if 'id' in item and 'zh' in item}
        except Exception as e:
            time.sleep(1.5 * attempt)
    return {}

def main():
    print("Starting concurrent synonym enrichment with Gemini 3.1 Flash Lite...")
    id_to_enriched_zh = {}
    
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_map = {executor.submit(enrich_batch, b): b for b in batches}
        for future in as_completed(future_map):
            mapping = future.result()
            id_to_enriched_zh.update(mapping)
            print(f"[Enrichment Progress] {len(id_to_enriched_zh)}/{len(entries)} words enriched...")

    # Update entries
    updated_cnt = 0
    for item in entries:
        eid = item['id']
        if eid in id_to_enriched_zh:
            new_zh = id_to_enriched_zh[eid].strip()
            if new_zh and new_zh != item['zh']:
                item['zh'] = new_zh
                updated_cnt += 1

    print(f"Enrichment completed! Updated {updated_cnt} words with richer synonyms.")

    # Save back to dict_data.json
    with open(JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)
    print(f"Saved updated dictionary to: {JSON_PATH}")

if __name__ == '__main__':
    main()
