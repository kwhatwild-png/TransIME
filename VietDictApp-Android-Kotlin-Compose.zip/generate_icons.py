# -*- coding: utf-8 -*-
"""
Generate Sogou Input Style App Icon:
- Vibrant orange gradient background (Sogou Orange #FF5722 / #FF7043)
- Smooth rounded square corner
- Clean white bold '词' glyph in center with subtle shadow
- Generate all Android mipmap resolutions (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi)
"""
import os
from PIL import Image, ImageDraw, ImageFont

RES_DIR = r'd:\Antigravity\VietDictApp\app\src\main\res'
FONT_PATH = r'C:\Windows\Fonts\msyh.ttc'

SIZES = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}

def create_base_icon(size=512):
    # Create image
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # 1. Gradient rounded rectangle (Sogou Style: Warm Coral Orange)
    # Gradient from #FF5252 / #FF5722 to #FF8A65
    top_color = (255, 75, 43, 255)    # #FF4B2B
    bottom_color = (255, 110, 64, 255) # #FF6E40

    # Draw vertical gradient
    gradient = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    g_draw = ImageDraw.Draw(gradient)
    for y in range(size):
        ratio = y / float(size)
        r = int(top_color[0] * (1 - ratio) + bottom_color[0] * ratio)
        g = int(top_color[1] * (1 - ratio) + bottom_color[1] * ratio)
        b = int(top_color[2] * (1 - ratio) + bottom_color[2] * ratio)
        g_draw.line([(0, y), (size, y)], fill=(r, g, b, 255))

    # Mask for rounded corners
    corner_radius = int(size * 0.22)
    mask = Image.new('L', (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.rounded_rectangle([(0, 0), (size, size)], radius=corner_radius, fill=255)

    # Composite gradient with mask
    icon = Image.composite(gradient, img, mask)
    icon_draw = ImageDraw.Draw(icon)

    # 2. Draw '词' character in center
    font_size = int(size * 0.58)
    try:
        font = ImageFont.truetype(FONT_PATH, font_size)
    except Exception:
        font = ImageFont.load_default()

    text = "词"
    bbox = icon_draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]

    # Center position
    x = (size - text_w) // 2 - bbox[0]
    y = (size - text_h) // 2 - bbox[1] - int(size * 0.02)

    # Subtle drop shadow
    shadow_offset = int(size * 0.015)
    icon_draw.text((x + shadow_offset, y + shadow_offset), text, font=font, fill=(180, 40, 20, 100))
    # Crisp white text
    icon_draw.text((x, y), text, font=font, fill=(255, 255, 255, 255))

    return icon

def create_round_icon(base_icon):
    size = base_icon.size[0]
    mask = Image.new('L', (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.ellipse([(0, 0), (size, size)], fill=255)
    
    round_img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    return Image.composite(base_icon, round_img, mask)

def main():
    base_512 = create_base_icon(512)
    round_512 = create_round_icon(base_512)

    for folder_name, px in SIZES.items():
        folder_path = os.path.join(RES_DIR, folder_name)
        os.makedirs(folder_path, exist_ok=True)

        # Normal launcher icon
        normal_resized = base_512.resize((px, px), Image.Resampling.LANCZOS)
        normal_resized.save(os.path.join(folder_path, 'ic_launcher.png'), 'PNG')

        # Round launcher icon
        round_resized = round_512.resize((px, px), Image.Resampling.LANCZOS)
        round_resized.save(os.path.join(folder_path, 'ic_launcher_round.png'), 'PNG')
        print(f"Generated {folder_name}: {px}x{px}")

    print("All icons successfully generated in res mipmap folders!")

if __name__ == '__main__':
    main()
