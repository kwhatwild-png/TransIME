# -*- coding: utf-8 -*-
"""
Filter out low-frequency academic jargon to produce a super clean, high-frequency,
high-practicality dictionary (~1200 - 1500 words), keeping total zip well under 12 MB!
"""
import os, json, shutil

SRC_JSON = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'
AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'

# Categories to completely exclude (too academic or rarely spoken in daily/work life)
EXCLUDE_CATS = {
    "生物生态", "化学物质", "哲学思辨", "论述思辨", "文学鉴赏", "文化艺术", 
    "学科研究", "仲裁与调解", "知识产权保护", "民法", "劳动法", "法律维权",
    "法律诉讼", "道德品格", "成语名言", "地球环境", "环境资源"
}

# Categories to keep unconditionally (daily life, practical communication, work)
MUST_KEEP_CATS = {
    "基础单字", "人称社交", "人称代词", "日常问候", "日常交际", "常用应答", "疑问代词",
    "餐饮生活", "交通出行", "居家住宿", "生活日常", "购物商贸", "数字时间", "时间数字", 
    "数字财务", "地道口语", "工作工程", "工程工作", "工程施工", "工作商务", "经贸洽谈",
    "商业运营", "健康医疗", "医疗急救", "气候自然", "情感状态", "核心动词", "常用动词",
    "常用形容词", "高级动词", "高级形容词", "高级连接词与转折词", "复杂心理"
}

with open(SRC_JSON, encoding='utf-8') as f:
    entries = json.load(f)

print(f"Original total entries: {len(entries)}")

filtered_entries = []
for item in entries:
    cat = item.get("cat", "")
    vi = item.get("vi", "")
    
    # Exclude academic/formal jargon categories
    if cat in EXCLUDE_CATS:
        continue
    
    # Exclude math & physics heavy jargon except basic ones
    if cat in ("数学数理", "物理科学"):
        # Only keep useful daily math words (area, volume, speed, etc.)
        useful_math = ["cộng", "trừ", "nhân", "chia", "diện tích", "thể tích", "vận tốc", "gia tốc", "áp suất", "công suất"]
        if not any(k in vi.lower() for k in useful_math):
            continue
            
    filtered_entries.append(item)

print(f"Filtered high-frequency practical entries: {len(filtered_entries)}")

# Re-assign sequential IDs
for idx, item in enumerate(filtered_entries, 1):
    item["id"] = idx

# Save back to dict_data.json
with open(SRC_JSON, 'w', encoding='utf-8') as f:
    json.dump(filtered_entries, f, ensure_ascii=False, indent=2)

# Clean up audio directory: remove mp3s not in filtered_entries
valid_audios = set(item['audio'] for item in filtered_entries)
removed_cnt = 0
for f in os.listdir(AUDIO_DIR):
    if f not in valid_audios:
        try:
            os.remove(os.path.join(AUDIO_DIR, f))
            removed_cnt += 1
        except Exception:
            pass

print(f"Removed {removed_cnt} low-frequency audio files.")
print(f"Remaining audio files on disk: {len(os.listdir(AUDIO_DIR))}")
