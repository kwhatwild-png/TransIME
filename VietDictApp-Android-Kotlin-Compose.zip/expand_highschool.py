# -*- coding: utf-8 -*-
"""
High-school vocabulary expansion: batch prompt generator for 3000 words
"""
import urllib.request, json, time, os, unicodedata, re
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'

# 40 targeted high school topics, aiming for 60-70 words each (~2500+ new entries)
TOPIC_SPECS = [
    # --- 自然科学与数理地理 ---
    ("数理科学", "高中数学与物理常用词汇: cộng trừ nhân chia, diện tích, thể tích, đạo hàm, tích phân, vận tốc, gia tốc, lực, công suất, áp suất, điện trở, tần số, chu kỳ, quỹ đạo..."),
    ("化学与生物", "高中化学与生物常用词汇: nguyên tử, phân tử, phản ứng, dung dịch, axit, bazơ, muối, kim loại, phi kim, tế bào, mô, cơ quan, di truyền, nhiễm sắc thể, đột biến..."),
    ("地理与环境", "地理地形与生态气候: địa hình, đồng bằng, cao nguyên, lưu vực sông, thủy triều, khoáng sản, biến đổi khí hậu, hiệu ứng nhà kính, ô nhiễm môi trường, xói mòn, bảo tồn..."),
    
    # --- 政治公民与社会法律 ---
    ("公民政治", "公民与社会制度: công dân, quyền lợi, nghĩa vụ, hiến pháp, pháp luật, quốc hội, chính phủ, tòa án, dân chủ, bình đẳng, trật tự xã hội, an ninh quốc gia, chủ quyền..."),
    ("法律经济", "基础法律与市场经济: vi phạm pháp luật, xử phạt, bồi thường, hợp đồng kinh tế, tranh chấp, thị trường, cung cầu, lạm phát, cạnh tranh, độc quyền, vốn đầu tư..."),
    ("行政体制", "国家机关与行政程序: cơ quan nhà nước, thủ tục hành chính, công chứng, hộ khẩu, căn cước công dân, giấy phép, đăng ký kinh doanh, quyết định xử lý, đơn từ, kiến nghị..."),

    # --- 历史文化与思想哲学 ---
    ("历史传统", "越南历史与文化遗产: lịch sử, triều đại, kháng chiến, giành độc lập, di sản văn hóa, phong tục tập quán, lễ hội truyền thống, văn hóa dân gian, cổ vật, bảo tàng..."),
    ("哲学思辨", "基础哲学思想与思辨表达: mâu thuẫn, bản chất, hiện tượng, nguyên nhân, kết quả, tất nhiên, ngẫu nhiên, quy luật, nhận thức, thực tiễn, quan điểm, lập luận..."),
    ("道德伦理", "伦理道德与处世品格: đạo đức, lương tâm, trách nhiệm, lòng nhân ái, trung thực, khiêm tốn, dũng cảm, kiên trì, tôn sư trọng đạo, hiếu thảo, vị tha, kỷ luật..."),

    # --- 语文文学与修辞修养 ---
    ("文学阅读", "越南文学与阅读鉴赏: tác phẩm, tác giả, nhân vật, cốt truyện, thể loại, văn xuôi, thơ ca, kịch bản, nghệ thuật ẩn dụ, hoán dụ, nhân hóa, so sánh, cảm thụ..."),
    ("议论写作", "高中议论文与逻辑表达: nghị luận xã hội, nghị luận văn học, luận điểm, luận cứ, dẫn chứng, lập luận chặt chẽ, mở bài, thân bài, kết bài, phản biện, đồng tình..."),
    ("成语俗语", "越南常用成语谚语与熟语: tục ngữ, ca dao, thành ngữ quen thuộc trong đời sống và văn học (khoảng 60 câu từ súc tích)..."),

    # --- 现代教育与学校生活 ---
    ("学校教育", "学校体制与课程体系: trường trung học phổ thông, ban tự nhiên, ban xã hội, kỳ thi tốt nghiệp, tuyển sinh đại học, điểm chuẩn, học bổng, nội quy trường học..."),
    ("学习考试", "课堂学习与备考用语: bài tập về nhà, ôn tập, kiểm tra định kỳ, đề thi, phòng thi, giám thị, kết quả, xếp loại học lực, giấy báo trúng tuyển, lễ bế giảng..."),

    # --- 科技信息与现代生活 ---
    ("信息科技", "计算机网络与数字技术: máy tính, phần mềm, phần cứng, hệ điều hành, trí tuệ nhân tạo, an ninh mạng, dữ liệu số, thuật toán, mã hóa, lập trình, đường truyền..."),
    ("社交媒体", "现代移动互联网与通信: mạng xã hội, ứng dụng di động, tin nhắn trực tuyến, phát trực tiếp, đăng tải, chia sẻ thông tin, tài khoản cá nhân, mật khẩu, lừa đảo mạng..."),
    ("电子数码", "现代电子产品与智能设备: điện thoại thông minh, máy tính bảng, màn hình cảm ứng, sạc pin dự phòng, tai nghe bluetooth, bộ nhớ trong, camera độ phân giải cao..."),

    # --- 商业商务与金融贸易 ---
    ("金融银行", "现代银行业务与金融理财: tài khoản ngân hàng, chuyển tiền điện tử, lãi suất gửi tiết kiệm, vay thế chấp, thẻ tín dụng, bảo hiểm nhân thọ, thanh toán trực tuyến..."),
    ("商务贸易", "商品贸易与商业洽谈: đàm phán hợp đồng, đối tác chiến lược, điều khoản giao hàng, thanh toán quốc tế, hải quan xuất nhập khẩu, kiểm tra chất lượng hàng hóa..."),
    ("财务税收", "企业财务与税收发票: doanh thu, lợi nhuận ròng, chi phí vận hành, hóa đơn điện tử, thuế giá trị gia tăng, thuế thu nhập cá nhân, kiểm toán tài chính, báo cáo thuế..."),

    # --- 工程建造与工业制造 ---
    ("建筑工程", "建筑工程结构与施工现场: kết cấu bê tông cốt thép, móng cọc, dầm sàn, cột chịu lực, giàn giáo xây dựng, trắc địa công trình, chống thấm mái, cốt cao độ..."),
    ("水暖电安", "安装与机电工程 (MEP): hệ thống cấp thoát nước, đường dây điện chiếu sáng, trạm biến áp, điều hòa trung tâm, phòng cháy chữa cháy, báo khói, van điều tiết..."),
    ("机械制造", "机械工器具与设备制造: động cơ máy móc, bánh răng, trục xoay, máy hàn xì, máy cắt kim loại, khuôn đúc, bảo dưỡng định kỳ, linh kiện thay thế, độ chính xác..."),

    # --- 城市交通与物流出行 ---
    ("城市交通", "交通法规与基础设施: luật giao thông đường bộ, giấy phép lái xe, đèn tín hiệu, làn đường ưu tiên, cầu vượt, hầm chui, cao tốc, ùn tắc giao thông, va chạm..."),
    ("物流仓储", "快递物流与供应链仓储: vận chuyển hàng hóa, kho bãi trung chuyển, đóng gói hàng, mã vận đơn, giao hàng tận nơi, phí vận chuyển, thất lạc kiện hàng..."),

    # --- 医学健康与心理生理 ---
    ("生理医疗", "人体组织与医学检查: hệ tuần hoàn, hệ tiêu hóa, huyết áp, xét nghiệm máu, chụp X-quang, siêu âm, nội soi, chẩn đoán bệnh, đơn thuốc, hồi phục sức khỏe..."),
    ("心理情感", "复杂心理状态与情绪感受: tâm lý học, căng thẳng lo âu, tự tin, mặc cảm, thất vọng, đồng cảm, phấn khởi, trầm cảm, động lực, vượt qua khó khăn, kiên cường..."),

    # --- 日常生活进阶词汇 ---
    ("烹饪食材", "各类食材配料与烹饪手艺: nguyên liệu nấu ăn, gia vị thảo mộc, hầm canh, xào nấu, nướng than, chiên giòn, sơ chế nguyên liệu, bảo quản thực phẩm tươi sống..."),
    ("家居日用", "进阶家居装饰与生活用品: đồ nội thất, thiết bị gia dụng thông minh, sửa chữa điện nước gia đình, vệ sinh môi trường sống, mua sắm đồ dùng tiện ích..."),
    ("服饰穿搭", "服装面料与美容穿着: chất liệu vải cotton, lụa tơ tằm, kiểu dáng thời trang, phụ kiện may mặc, giặt khô là hơi, thẩm mỹ, kích cỡ trang phục..."),

    # --- 逻辑抽象动词与形容词进阶 ---
    ("进阶动词1", "认知思辨与决策动词: phân tích, tổng hợp, đánh giá, cân nhắc, quyết định, lựa chọn, thừa nhận, bác bỏ, khẳng định, giả định, dự đoán, giải thích..."),
    ("进阶动词2", "组织管理与行动动词: tổ chức, điều phối, triển khai, thực hiện, giám sát, khắc phục, cải tiến, phát triển, thúc đẩy, ngăn chặn, hợp tác, can thiệp..."),
    ("进阶动词3", "人际交往与沟通动词: thuyết phục, trao đổi, thương lượng, tranh luận, chỉ trích, động viên, an ủi, ca ngợi, phê bình, xin ý kiến, thông báo..."),
    ("进阶形容词1", "性质特质与深度特征形容词: khách quan, chủ quan, toàn diện, phiến diện, phức tạp, đơn giản, rõ ràng, mơ hồ, trừu tượng, cụ thể, thực tế, viển vông..."),
    ("进阶形容词2", "效率程度与状态描述形容词: hiệu quả, lãng phí, nhanh chóng, kịp thời, chậm trễ, ổn định, bất thường, bền vững, tạm thời, vượt trội, hoàn hảo, thiếu sót..."),

    # --- 综合情景复合短语 ---
    ("情景短语1", "职场与学术讨论高频短语: theo ý kiến của tôi, trên thực tế, mặt khác, tóm lại là, đáng chú ý là, căn cứ vào, giải pháp tối ưu, mục tiêu đề ra..."),
    ("情景短语2", "日常生活处理问题常用短语: để tôi xem đã, không có vấn đề gì, đành phải vậy, làm ơn cho hỏi, xử lý thế nào, càng sớm càng tốt, đúng như dự kiến..."),
]

def fetch_single_topic(cat_name, prompt_desc, retries=5):
    prompt = f"""
你是越南语语言学专家与高中高级教育学者。
请针对主题【{cat_name}: {prompt_desc}】，列出 65 到 75 个极其标准、地道、具备高中及以上文化素养的常用越南语词汇或精炼词组。
必须严格输出合法的 JSON 数组，每个元素包含：
- "vi": 越南语单词或词组 (严格带正确越南语音标)
- "zh": 对应的简体中文精确释义
- "cat": "{cat_name}"
- "eg_vi": 规范的高中文雅实用例句 (8-12个词)
- "eg_zh": 例句的中文翻译

严格以 JSON Array 输出:
[
  {{"vi": "...", "zh": "...", "cat": "{cat_name}", "eg_vi": "...", "eg_zh": "..."}}
]
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.2
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=40) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                items = json.loads(raw)
                if isinstance(items, list) and len(items) > 0:
                    print(f"[OK] Topic '{cat_name}' fetched {len(items)} items.")
                    return items
        except Exception as e:
            time.sleep(2.0 * attempt)
    return []

def main():
    print(f"Starting High-School Expansion with {len(TOPIC_SPECS)} comprehensive academic topics...")
    all_results = []
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_map = {executor.submit(fetch_single_topic, cat, desc): cat for cat, desc in TOPIC_SPECS}
        for future in as_completed(future_map):
            items = future.result()
            all_results.extend(items)
            print(f"Accumulated high school items: {len(all_results)}...")
            
    out_file = r'd:\Antigravity\VietDictApp\highschool_vocab.json'
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"[COMPLETED] Total {len(all_results)} items saved to {out_file}")

if __name__ == '__main__':
    main()
