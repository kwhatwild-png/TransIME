# -*- coding: utf-8 -*-
"""
Generate comprehensive high-school vocabulary for Vietnamese Dictionary
Saves incrementally to avoid data loss.
"""
import urllib.request, json, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'
OUT_FILE = r'd:\Antigravity\VietDictApp\highschool_vocab.json'

TOPIC_SPECS = [
    # 1. 数理科学
    ("数学数理", "高中代数、几何与高等运算: cộng trừ nhân chia, diện tích, thể tích, đạo hàm, tích phân, hàm số, phương trình, bất đẳng thức, ma trận, xác suất, thống kê, vectơ, góc vuông..."),
    ("物理科学", "高中物理力学热学光学电磁学: vận tốc, gia tốc, lực hấp dẫn, ma sát, công suất, áp suất, điện trở, hiệu điện thế, cường độ dòng điện, tần số, chu kỳ, bước sóng, quang phổ..."),
    # 2. 化学与生物环境
    ("化学物质", "高中化学反应与物质元素: nguyên tử, phân tử, phản ứng hóa học, dung dịch, nồng độ, axit, bazơ, muối, kim loại, phi kim, chất xúc tác, kết tủa, bay hơi, oxy hóa khử..."),
    ("生物生态", "高中生物遗传进化与生态: tế bào, ADN, ARN, gen di truyền, nhiễm sắc thể, đột biến, quang hợp, hô hấp, hệ sinh thái, chuỗi thức ăn, đa dạng sinh học, chọn lọc tự nhiên..."),
    ("地球环境", "地理气候地形与环境保护: địa hình, đồng bằng, cao nguyên, lưu vực sông, thủy triều, khoáng sản, biến đổi khí hậu, hiệu ứng nhà kính, ô nhiễm môi trường, xói mòn, bảo tồn..."),

    # 3. 政治公民与法律体制
    ("公民政治", "公民权利义务与国家制度: công dân, quyền lợi, nghĩa vụ, hiến pháp, pháp luật, quốc hội, chính phủ, tòa án, dân chủ, bình đẳng, trật tự xã hội, an ninh quốc gia, chủ quyền..."),
    ("经济市场", "商品经济与市场规律: thị trường, cung cầu, giá cả, lạm phát, thiểu phát, cạnh tranh lành mạnh, độc quyền, vốn đầu tư, năng suất lao động, tăng trưởng kinh tế, hội nhập..."),
    ("法律诉讼", "法律责任纠纷与行政程序: vi phạm pháp luật, xử phạt hành chính, bồi thường thiệt hại, tranh chấp dân事, khiếu nại, tố cáo, công chứng, thủ tục pháp lý, quyền sở hữu trí tuệ..."),

    # 4. 文学修辞与哲学思辨
    ("哲学思辨", "唯物辩证与认知思维: mâu thuẫn biện chứng, bản chất và hiện tượng, nguyên nhân kết quả, tất nhiên ngẫu nhiên, quy luật phủ định, nhận thức cảm tính, lý tính, thực tiễn..."),
    ("道德品格", "品德修养与人生价值观: đạo đức, lương tâm, trách nhiệm xã hội, lòng nhân ái, trung thực, khiêm tốn, dũng cảm, kiên trì, tự trọng, vị tha, ý chí vươn lên, lý tưởng sống..."),
    ("文学鉴赏", "文学体裁形象与修辞技巧: tác phẩm văn học, hình tượng nhân vật, cốt truyện, chủ đề tư tưởng, văn xuôi, thi ca, kịch bản, ẩn dụ, hoán dụ, nhân hóa, so sánh, điệp từ..."),
    ("论述思辨", "议论文写作与逻辑推理: luận điểm chính, luận cứ xác đáng, dẫn chứng thực tế, lập luận chặt chẽ, mở bài khái quát, thân bài phân tích, kết bài đúc kết, phản biện bác bỏ..."),
    ("成语名言", "高中生必知越南经典成语熟语: thành ngữ, tục ngữ, ca dao quen thuộc đúc kết kinh nghiệm sống và đạo lý làm người (50-60 câu từ súc tích)..."),

    # 5. 学校教育与学术成长
    ("学校升学", "高中学业与高考升学: kỳ thi tốt nghiệp THPT, xét tuyển đại học, nguyện vọng xét tuyển, khối thi, điểm chuẩn trúng tuyển, học bổng khuyến khích, du học, hướng nghiệp..."),
    ("学科研究", "学术探究与综合实践: nghiên cứu khoa học, đề tài sáng tạo, thuyết trình báo cáo, làm việc nhóm, phản biện học thuật, thu thập số liệu, khảo sát thực tế, tổng kết..."),

    # 6. 信息科技与现代数字生活
    ("信息技术", "计算机软件硬件与前沿科技: trí tuệ nhân tạo, an toàn thông tin, bảo mật dữ liệu, mã nguồn, thuật toán tìm kiếm, mạng viễn thông, điện toán đám mây, chuyển đổi số..."),
    ("数字生活", "互联网生活与网络公德: không gian mạng, danh tính số, quyền riêng tư, lừa đảo công nghệ cao, bản quyền nội dung, giao tiếp trực tuyến, học tập từ xa..."),

    # 7. 商务经贸与工业工程进阶
    ("经贸洽谈", "商业会谈与经济契约: đàm phán thương mại, hợp đồng kinh tế, điều khoản thanh toán, giao nhận hàng hóa, thủ tục hải quan, tỷ giá hối đoái, xuất nhập khẩu chính ngạch..."),
    ("工业工程", "工程设计施工与质量验收: thiết kế kỹ thuật, bản vẽ thi công, tiến độ dự án, an toàn lao động, kiểm định chất lượng, kết cấu bê tông cốt thép, trắc địa, nghiệm thu bàn giao..."),

    # 8. 心理情绪与高级表达
    ("复杂心理", "心理情绪与人际互动深度描绘: tâm lý tích cực, áp lực căng thẳng, tự ti mặc cảm, hoài bão ước mơ, thấu cảm chia sẻ, mâu thuẫn nội tâm, bản lĩnh vượt khó..."),
    ("高级动词", "高级书面与思维动作动词: phân tích, đánh giá, cân nhắc, quyết định, khẳng định, bác bỏ, điều phối, thúc đẩy, cải cách, thích ứng, cống hiến, kiến tạo, bảo đảm..."),
    ("高级形容词", "深度特性与程度评价形容词: khách quan, toàn diện, sâu sắc, thực tiễn, bền vững, ưu việt, hiệu quả, bất khả kháng, tiên tiến, chính xác, nghiêm minh, chuẩn mực...")
]

def fetch_topic(cat_name, desc, retries=5):
    prompt = f"""
你是越南语高级教育与语言学专家。请针对高中生核心学科与社会认知主题【{cat_name}: {desc}】，
整理 90 到 100 个高中及以上必备的规范越南语单词和复合词组。
必须严格输出合法的 JSON 数组，每个元素包含：
- "vi": 越南语单词或词组 (严格带正确越南语音标)
- "zh": 对应的简体中文精确释义
- "cat": "{cat_name}"
- "eg_vi": 规范的高中文雅实用例句 (8-12个词)
- "eg_zh": 例句的中文翻译

严格以 JSON Array 输出:
[
  {{"vi": "...", "zh": "...", "cat": "{cat_name}", "eg_vi": "...", "eg_zh": "..."}}
]
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.2
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=45) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                items = json.loads(raw)
                if isinstance(items, list) and len(items) > 0:
                    print(f"[OK] Topic '{cat_name}' fetched {len(items)} items.")
                    return items
        except Exception as e:
            time.sleep(2.0 * attempt)
    return []

def main():
    print("Generating comprehensive academic high school vocabulary...")
    all_results = []
    
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_map = {executor.submit(fetch_topic, cat, desc): cat for cat, desc in TOPIC_SPECS}
        for future in as_completed(future_map):
            items = future.result()
            all_results.extend(items)
            print(f"Total collected so far: {len(all_results)} items...")
            # Save incrementally
            with open(OUT_FILE, 'w', encoding='utf-8') as f:
                json.dump(all_results, f, ensure_ascii=False, indent=2)

    print(f"Finished! Total {len(all_results)} high school items saved.")

if __name__ == '__main__':
    main()
