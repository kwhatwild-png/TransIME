# -*- coding: utf-8 -*-
"""
Generate remaining natural neural audio using edge_tts CLI sequentially in background batches
"""
import os, json, time, subprocess, sys
from concurrent.futures import ThreadPoolExecutor, as_completed

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'
VOICE = 'vi-VN-HoaiMyNeural'

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

# Record modification timestamp of each audio file
# Files updated recently are already new Microsoft Neural
now = time.time()
todo = []
for item in entries:
    p = os.path.join(AUDIO_DIR, item['audio'])
    # If file was modified earlier than 10 minutes ago, re-render it with HoaiMyNeural
    if not os.path.exists(p) or (now - os.path.getmtime(p)) > 600:
        todo.append(item)

print(f"Total entries: {len(entries)}. Remaining to upgrade to HoaiMyNeural: {len(todo)}")

def render_cli(item):
    p = os.path.join(AUDIO_DIR, item['audio'])
    text = item['vi']
    cmd = [
        sys.executable, "-m", "edge_tts",
        "--voice", VOICE,
        "--text", text,
        "--write-media", p
    ]
    try:
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=12)
        if os.path.exists(p) and os.path.getsize(p) > 500:
            return True
    except Exception:
        pass
    return False

if todo:
    done = 0
    with ThreadPoolExecutor(max_workers=6) as executor:
        futures = [executor.submit(render_cli, item) for item in todo]
        for f in as_completed(futures):
            if f.result():
                done += 1
            if done % 50 == 0 or done == len(todo):
                print(f"Progress: {done}/{len(todo)} upgraded to Microsoft Neural...")

print("All audio files completely upgraded to Microsoft Natural Neural voice!")
