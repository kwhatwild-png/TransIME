# -*- coding: utf-8 -*-
"""
Generate and cache all audio files (.mp3) for master 2,749 words
Outputs clean mp3 files directly into app assets
"""
import os, sys, json, time, urllib.request, urllib.parse, re, unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

os.makedirs(AUDIO_DIR, exist_ok=True)

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

def remove_vietnamese_accents(text: str) -> str:
    text = text.replace('đ', 'd').replace('Đ', 'D')
    nfkd = unicodedata.normalize('NFKD', text)
    res = ''.join([c for c in nfkd if not unicodedata.combining(c)])
    return re.sub(r'\s+', ' ', res).strip().lower()

# Update entries audio filename to .mp3 format
for item in entries:
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', remove_vietnamese_accents(item['vi'])).strip('_')
    item['audio'] = f"{item['id']:04d}_{slug}.mp3"

with open(JSON_PATH, 'w', encoding='utf-8') as f:
    json.dump(entries, f, ensure_ascii=False, indent=2)

print(f"Total vocabulary to voice: {len(entries)} items.")

def fetch_tts(text: str, retries=5):
    url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=tw-ob&q=' + urllib.parse.quote(text)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=12) as resp:
                content = resp.read()
                if len(content) > 500:
                    return content
        except Exception:
            time.sleep(0.5 * attempt)
    return None

def process_one(entry):
    idx = entry['id']
    vi = entry['vi']
    audio_filename = entry['audio']
    out_path = os.path.join(AUDIO_DIR, audio_filename)

    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return idx, vi, True

    audio_bytes = fetch_tts(vi)
    if audio_bytes:
        with open(out_path, 'wb') as f:
            f.write(audio_bytes)
        return idx, vi, True
    return idx, vi, False

def main():
    print("Starting rapid multithreaded audio caching...")
    success = 0
    with ThreadPoolExecutor(max_workers=8) as executor:
        future_map = {executor.submit(process_one, entry): entry for entry in entries}
        for future in as_completed(future_map):
            idx, vi, ok = future.result()
            if ok:
                success += 1
            if success % 100 == 0 or success == len(entries):
                print(f"[Audio Progress] {success}/{len(entries)} files cached...")

    print(f"Complete! All {success}/{len(entries)} offline audio files cached in: {AUDIO_DIR}")

if __name__ == '__main__':
    main()
