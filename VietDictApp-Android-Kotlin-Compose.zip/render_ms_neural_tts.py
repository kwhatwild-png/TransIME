# -*- coding: utf-8 -*-
"""
Generate ultra-natural Vietnamese pronunciations using Microsoft Azure Neural TTS:
Voice: vi-VN-HoaiMyNeural (Natural, human-like, expressive, pure native Vietnamese)
"""
import asyncio, os, json, time, zipfile
import edge_tts

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'
VOICE = 'vi-VN-HoaiMyNeural'  # Top-tier natural Vietnamese female voice

os.makedirs(AUDIO_DIR, exist_ok=True)

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

print(f"Total entries to voice via Microsoft Natural Neural ({VOICE}): {len(entries)}")

async def render_audio(vi_text: str, out_path: str, retries=5):
    for attempt in range(1, retries + 1):
        try:
            communicate = edge_tts.Communicate(vi_text, VOICE, rate="+0%", pitch="+0Hz")
            await communicate.save(out_path)
            if os.path.exists(out_path) and os.path.getsize(out_path) > 500:
                return True
        except Exception as e:
            if attempt == retries:
                print(f"[FAIL] {vi_text}: {e}")
                return False
            await asyncio.sleep(0.5 * attempt)
    return False

async def worker(queue, progress_counter):
    while not queue.empty():
        item = await queue.get()
        out_path = os.path.join(AUDIO_DIR, item['audio'])
        
        ok = await render_audio(item['vi'], out_path)
        progress_counter['done'] += 1
        cnt = progress_counter['done']
        total = progress_counter['total']
        if cnt % 100 == 0 or cnt == total:
            print(f"[Microsoft Neural Progress] {cnt}/{total} audios generated...")
        queue.task_done()

async def main():
    queue = asyncio.Queue()
    for item in entries:
        await queue.put(item)

    progress_counter = {'done': 0, 'total': len(entries)}
    
    # Run 12 concurrent workers for rapid generation
    concurrency = 12
    tasks = [asyncio.create_task(worker(queue, progress_counter)) for _ in range(concurrency)]
    await queue.join()

    for t in tasks:
        t.cancel()

    print("[SUCCESS] All Microsoft Natural Neural voices rendered successfully!")

if __name__ == '__main__':
    asyncio.run(main())
