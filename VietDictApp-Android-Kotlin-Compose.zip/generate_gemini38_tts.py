# -*- coding: utf-8 -*-
"""
Generate offline audio for all dictionary items using Gemini 3.8 Flash Lite TTS:
gemini-3.8-flash-lite-tts
Outputs standard 24kHz WAV audio files.
"""
import os, sys, json, time, wave, base64, io
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
TTS_MODEL = 'gemini-3.8-flash-lite-tts'
TTS_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{TTS_MODEL}:generateContent?key={API_KEY}'

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

os.makedirs(AUDIO_DIR, exist_ok=True)

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

print(f"Total vocabulary to voice via gemini-3.8-flash-lite-tts: {len(entries)}")

def pcm_to_wav_bytes(pcm_data: bytes, sample_rate=24000, channels=1, sampwidth=2) -> bytes:
    wav_buf = io.BytesIO()
    with wave.open(wav_buf, 'wb') as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sampwidth)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_data)
    return wav_buf.getvalue()

def fetch_gemini_tts(text: str, retries=6):
    payload = {
        'contents': [{'parts': [{'text': text}]}],
        'generationConfig': {
            'response_modalities': ['AUDIO'],
            'speech_config': {
                'voice_config': {
                    'prebuilt_voice_config': {
                        'voice_name': 'Puck'
                    }
                }
            }
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                TTS_URL,
                data=data_bytes,
                headers={'Content-Type': 'application/json'}
            )
            with urllib.request.urlopen(req, timeout=25) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                part = res['candidates'][0]['content']['parts'][0]
                b64_audio = part.get('inlineData', {}).get('data', '')
                if b64_audio:
                    pcm_bytes = base64.b64decode(b64_audio)
                    return pcm_to_wav_bytes(pcm_bytes, sample_rate=24000)
        except Exception as e:
            # If 429 rate limited, back off progressively
            time.sleep(2.0 * attempt)
    return None

def process_item(item):
    idx = item['id']
    vi = item['vi']
    audio_filename = item['audio']
    out_path = os.path.join(AUDIO_DIR, audio_filename)

    if os.path.exists(out_path) and os.path.getsize(out_path) > 1000:
        return idx, vi, True # Cached

    wav_bytes = fetch_gemini_tts(vi)
    if wav_bytes:
        with open(out_path, 'wb') as f:
            f.write(wav_bytes)
        return idx, vi, True
    return idx, vi, False

def main():
    print(f"Starting Gemini 3.8 Flash Lite TTS generation for {len(entries)} items...")
    success = 0
    with ThreadPoolExecutor(max_workers=4) as executor:
        future_map = {executor.submit(process_item, entry): entry for entry in entries}
        for future in as_completed(future_map):
            idx, vi, ok = future.result()
            if ok:
                success += 1
            if success % 50 == 0 or success == len(entries):
                print(f"[Gemini 3.8 TTS Progress] {success}/{len(entries)} audio files generated...")

    print(f"Gemini 3.8 TTS generation complete! {success}/{len(entries)} audio files saved to: {AUDIO_DIR}")

if __name__ == '__main__':
    main()
