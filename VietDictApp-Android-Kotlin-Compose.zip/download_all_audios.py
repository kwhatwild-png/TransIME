# -*- coding: utf-8 -*-
"""
Generate and cache all audio files for full_dictionary.json using concurrent download pipeline
"""
import os, sys, json, time, urllib.request, urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_SRC = r'd:\Antigravity\VietDictApp\full_dictionary.json'
JSON_DEST = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

os.makedirs(AUDIO_DIR, exist_ok=True)

with open(JSON_SRC, encoding='utf-8') as f:
    entries = json.load(f)

# Copy to app assets
with open(JSON_DEST, 'w', encoding='utf-8') as f:
    json.dump(entries, f, ensure_ascii=False, indent=2)

print(f"Updated dict_data.json in assets with {len(entries)} entries.")

def fetch_tts_audio(text: str, retries=5):
    url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=tw-ob&q=' + urllib.parse.quote(text)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=12) as resp:
                content = resp.read()
                if len(content) > 500:
                    return content
        except Exception as e:
            if attempt == retries:
                return None
            time.sleep(0.5 * attempt)
    return None

tasks = []
for item in entries:
    audio_path = os.path.join(AUDIO_DIR, item['audio'])
    tasks.append((item['id'], item['vi'], audio_path))

def process_one(task):
    idx, vi, audio_path = task
    if os.path.exists(audio_path) and os.path.getsize(audio_path) > 1000:
        return idx, vi, True
    content = fetch_tts_audio(vi)
    if content:
        with open(audio_path, 'wb') as f:
            f.write(content)
        return idx, vi, True
    return idx, vi, False

print(f"Starting batch audio caching for {len(tasks)} items...")
success_cnt = 0
with ThreadPoolExecutor(max_workers=6) as executor:
    future_map = {executor.submit(process_one, t): t for t in tasks}
    for future in as_completed(future_map):
        idx, vi, ok = future.result()
        if ok:
            success_cnt += 1
        if success_cnt % 50 == 0 or success_cnt == len(tasks):
            print(f"Progress: {success_cnt}/{len(tasks)} audio files cached...")

print(f"Finished! Total successfully cached audio files: {success_cnt}/{len(tasks)}")
