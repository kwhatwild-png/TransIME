# -*- coding: utf-8 -*-
import urllib.request, json, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'
OUT_FILE = r'd:\Antigravity\VietDictApp\highschool_supplement.json'

EXTRA_TOPICS = [
    ("文化艺术", "绘画、音乐、雕塑、建筑艺术、民间戏曲歌舞: hội họa, điêu khắc, âm nhạc cổ điển, nhạc cụ dân tộc, sân khấu kịch, tuồng, chèo, cải lương, giá trị thẩm mỹ, cảm xúc nghệ thuật (85个词)"),
    ("现代医学", "疾病预防、免疫系统、疫苗接种、营养卫生、现代临床医学: hệ miễn dịch, kháng thể, vắc-xin phòng bệnh, lây nhiễm virus, cân bằng dinh dưỡng, vệ sinh an toàn thực phẩm, chẩn đoán hình ảnh (85个词)"),
    ("法律维权", "劳动法、民法、知识产权保护、仲裁与调解: hợp đồng lao động, bảo hiểm xã hội, sở hữu công nghiệp, bản quyền tác giả, trọng tài thương mại, hòa giải cơ sở, tranh tụng tại tòa án (85个词)"),
    ("环境资源", "生态危机、可再生能源、碳排放、绿色转型: khủng hoảng sinh thái, năng lượng tái tạo, năng lượng mặt trời, điện gió, phát thải khí nhà kính, chuyển đổi xanh, kinh tế tuần hoàn (85个词)"),
    ("商业运营", "市场营销、品牌打造、供应链管理、电子商务: chiến lược tiếp thị, định vị thương hiệu, chuỗi cung ứng, thương mại điện tử, thanh toán không tiền mặt, hành vi người tiêu dùng, thị phần (85个词)"),
    ("高级连接词与转折词", "高中议论文严密逻辑连接词与副词: trái lại, ngược lại, hơn nữa, thậm chí, tuy nhiên, nói cách khác, xét về phương diện, trên cơ sở, nhìn chung mà nói, không thể phủ nhận rằng (85个词)")
]

def fetch_one(cat_name, desc, retries=5):
    prompt = f"""
你是越南语高级教育专家。针对高中主题【{cat_name}: {desc}】，
整理 80 到 90 个高中及以上水准的常用越南语单词和词组。
严格输出 JSON 数组:
[
  {{"vi": "...", "zh": "...", "cat": "{cat_name}", "eg_vi": "...", "eg_zh": "..."}}
]
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.2
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=40) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                items = json.loads(raw)
                if isinstance(items, list) and len(items) > 0:
                    print(f"[OK] Extra Topic '{cat_name}' fetched {len(items)} items.")
                    return items
        except Exception as e:
            time.sleep(2.0 * attempt)
    return []

def main():
    results = []
    with ThreadPoolExecutor(max_workers=3) as executor:
        future_map = {executor.submit(fetch_one, cat, desc): cat for cat, desc in EXTRA_TOPICS}
        for future in as_completed(future_map):
            items = future.result()
            results.extend(items)
    with open(OUT_FILE, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"Extra {len(results)} items saved.")

if __name__ == '__main__':
    main()
