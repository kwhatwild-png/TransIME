# -*- coding: utf-8 -*-
"""
Merge and deduplicate seed, round 1 and round 2 vocabulary entries
"""
import json, unicodedata, re, os
from raw_seed import RAW_ENTRIES

def remove_vietnamese_accents(text: str) -> str:
    text = text.replace('đ', 'd').replace('Đ', 'D')
    nfkd = unicodedata.normalize('NFKD', text)
    res = ''.join([c for c in nfkd if not unicodedata.combining(c)])
    return re.sub(r'\s+', ' ', res).strip().lower()

def safe_filename(text: str, index: int) -> str:
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', remove_vietnamese_accents(text)).strip('_')
    return f"{index:04d}_{slug}.mp3"

with open(r'd:\Antigravity\VietDictApp\expanded_vocab.json', encoding='utf-8') as f1:
    r1 = json.load(f1)
with open(r'd:\Antigravity\VietDictApp\expanded_vocab_round2.json', encoding='utf-8') as f2:
    r2 = json.load(f2)

raw_pool = RAW_ENTRIES + r1 + r2
print(f"Total raw items pooled: {len(raw_pool)}")

seen_vi = set()
unique_entries = []

for item in raw_pool:
    vi = item.get("vi", "").strip()
    if not vi:
        continue
    norm_key = remove_vietnamese_accents(vi)
    vi_lower = vi.lower()
    
    # Deduplicate based on exact vietnamese text
    if vi_lower in seen_vi:
        continue
    seen_vi.add(vi_lower)

    zh = item.get("zh", "").strip()
    cat = item.get("cat", "日常生活").strip()
    eg_vi = item.get("eg_vi", "").strip()
    eg_zh = item.get("eg_zh", "").strip()

    unique_entries.append({
        "vi": vi,
        "norm": norm_key,
        "zh": zh,
        "cat": cat,
        "eg_vi": eg_vi,
        "eg_zh": eg_zh
    })

# Sort entries cleanly
unique_entries.sort(key=lambda x: (x["norm"], x["vi"]))

# Re-assign IDs and filenames
final_entries = []
for idx, entry in enumerate(unique_entries, 1):
    audio_file = safe_filename(entry["vi"], idx)
    entry["id"] = idx
    entry["audio"] = audio_file
    final_entries.append(entry)

print(f"Total distinct high-quality entries after deduplication: {len(final_entries)}")

out_path = r'd:\Antigravity\VietDictApp\full_dictionary.json'
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(final_entries, f, ensure_ascii=False, indent=2)

print(f"Full dictionary saved to: {out_path}")
