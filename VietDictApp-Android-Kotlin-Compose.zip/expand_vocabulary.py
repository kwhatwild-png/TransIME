# -*- coding: utf-8 -*-
"""
Expand full daily Vietnamese vocabulary and phrases using multi-topic Gemini expansion
"""
import urllib.request, json, time, os, unicodedata, re
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'

CATEGORIES_AND_PROMPTS = [
    # 1. 基础高频单字与虚词
    ("基础单字", "越南语最常用的核心单字、连词、介词、助词、副词 (如: và, nhưng, vì, nếu, đã, đang, sẽ, lại, cũng, rất, quá, lắm, nhé, nha, này, đó, kia, nào, tự, cùng, với, cho, để, do, bởi, tại, theo, về...)"),
    # 2. 人称称谓与社交
    ("人称社交", "越南语完整人称称谓体系与亲属社会关系 (如: tôi, tao, tớ, mình, bạn, anh, chị, em, ông, bà, chú, bác, cô, dì, thím, dượng, con, cháu, chàng, nàng, quý khách, đồng chí, sếp, giám đốc, bạn bè, đồng nghiệp, người yêu, vợ, chồng, cha, mẹ...)"),
    # 3. 日常问候与礼貌交际
    ("日常交际", "越南语日常打招呼、感谢、道歉、祝贺、客套用语与常用口语句型 (如: xin chào, chào buổi sáng, chúc ngủ ngon, cảm ơn nhiều, xin lỗi, không sao đâu, làm phiền, tạm biệt, hẹn gặp lại, bảo trọng, chúc mừng, may mắn, vâng, dạ, ừ, không, đúng rồi, thôi bỏ đi...)"),
    # 4. 时间、日期与数字货币
    ("时间数字", "越南语数字量词、货币计算、星期月份、时间频度 (如: số không, một, hai, mười, trăm, nghìn, triệu, tỷ, đồng, đô la, hôm nay, hôm qua, ngày mai, ngày kia, tuần trước, tháng sau, năm nay, sáng, trưa, chiều, tối, đêm, giây, phút, giờ, bao giờ, luôn luôn, thỉnh thoảng, hiếm khi...)"),
    # 5. 餐饮美食与买单消费
    ("餐饮生活", "越南餐馆就餐、点菜、特色美食、味道口感受、调料食材、结账买单词汇短语 (如: phở bò, phở gà, bún chả, bún bò huế, bánh mì, gỏi cuốn, cơm tấm, cà phê sữa đá, trà đá, nước mía, nước ngọt, bia, cay, ngọt, chua, mặn, nhạt, đắng, béo, nóng, lạnh, đá, đường, ớt, chanh, nước mắm, xì dầu, tính tiền, hóa đơn, mang về, đắt quá, giảm giá, khuyến mãi...)"),
    # 6. 交通出行与方位问路
    ("交通出行", "越南搭车乘机、骑车、方向定位、问路导航短语 (如: đi, về, đến, dừng lại, rẽ trái, rẽ phải, đi thẳng, quay đầu, ngã ba, ngã tư, đèn đỏ, xe máy, xe ôm, grab, taxi, xe buýt, máy bay, sân bay, bến xe, nhà ga, vé xe, đường, phố, xa, gần, ở đâu, bên cạnh, đối diện, phía trước, đằng sau...)"),
    # 7. 租房住宿与家居生活
    ("居家住宿", "租房、酒店入住、退房、水电家电、房间设施、日用品 (如: khách sạn, nhà nghỉ, thuê phòng, đặt phòng, trả phòng, tiền cọc, chìa khóa, thang máy, máy lạnh, điều hòa, quạt gió, nóng lạnh, wifi, mật khẩu, giường, gối, chăn, khăn tắm, bàn chải, xà phòng, mất điện, mất nước, nhà vệ sinh, phòng tắm...)"),
    # 8. 购物逛街与商贸价格
    ("购物商贸", "集市超市买东西、砍价还价、尺码颜色、付款方式 (如: mua, bán, bao nhiêu tiền, đắt, rẻ, bớt đi, giảm giá chút đi, vừa vặn, rộng, chật, màu đỏ, màu xanh, màu trắng, màu đen, áo, quần, giày dép, tiền mặt, quét mã, chuyển khoản, đổi trả, lấy cái này, không mua đâu...)"),
    # 9. 身体健康与医疗求助
    ("健康医疗", "身体部位、生病就医、买药、急诊报警求助短语 (如: đầu, mắt, mũi, miệng, răng, họng, bụng, tay, chân, đau đầu, đau bụng, sốt, cảm cúm, ho, tiêu chảy, dị ứng, bệnh viện, phòng khám, hiệu thuốc, bác sĩ, y tá, uống thuốc, cấp cứu, cứu tôi với, báo cảnh sát, cháy, mất đồ...)"),
    # 10. 工作办公与工程建筑
    ("工作工程", "工地施工、材料设备、质检进度、商务开会、办公室高频 (如: công ty, văn phòng, nhà xưởng, công trường, thi công, tiến độ, chất lượng, an toàn, bản vẽ, thiết kế, kỹ sư, công nhân, giám sát, nhà thầu, chủ đầu tư, xi măng, bê tông, cốt thép, gạch, cát, máy xúc, cẩu tháp, nghiệm thu, biên bản, hợp đồng, báo cáo, họp, tăng ca, lương, nghỉ phép, nhanh lên, cẩn thận...)"),
    # 11. 天气气候与自然环境
    ("气候自然", "越南天气、季节气候、地理环境 (如: thời tiết, trời mưa, trời nắng, nhiều mây, bão, lũ lụt, sấm sét, gió, nhiệt độ, mùa mưa, mùa khô, mùa hè, mùa đông, nóng bức, ẩm ướt, lạnh buốt, sông, biển, núi, đảo, bãi biển, nông thôn, thành phố...)"),
    # 12. 常用动词大全
    ("核心动词", "日常必须的高频动作动词 (如: làm, ăn, uống, ngủ, thức dậy, tắm, rửa, đi, chạy, nhảy, ngồi, đứng, nằm, nói, kể, bảo, nghe, nhìn, xem, thấy, đọc, viết, học, dạy, biết, hiểu, nhớ, quên, nghĩ, tìm, kiếm, gặp, chờ, đợi, đưa, lấy, cầm, mang, gửi, nhận, mở, đóng, bật, tắt...)"),
    # 13. 常用形容词与情绪副词
    ("常用形容词", "外貌、性质、情绪、状态描述 (如: tốt, xấu, đẹp, xinh, xấu xí, cao, thấp, béo, gầy, nhanh, chậm, sớm, muộn, đúng, sai, dễ, khó, sạch, bẩn, vui, buồn, giận, sợ, lo lắng, mệt, khỏe, no, đói, khát, giàu, nghèo, mới, cũ, nặng, nhẹ, cứng, mềm...)"),
    # 14. 常用地道口头禅与情景短语
    ("地道口语", "越南人天天挂在嘴边的口头短语 (如: trời ơi, đúng rồi, thế à, sao vậy, kệ nó đi, không sao đâu, biết rồi, hiểu chưa, đi thôi, nhanh lên nào, từ từ thôi, thật không, chuẩn luôn, chết tiệt, vui quá, chán quá, mệt mỏi quá, làm sao bây giờ, tùy bạn, thoải mái đi...)")
]

def fetch_category_words(category_name, topic_desc, retries=5):
    prompt = f"""
你是越南语与中文语言专家。请针对以下主题【{category_name}: {topic_desc}】，
列出至少 35 到 50 个最地道、最常用的日常越南语单词和短语词组。
必须严格输出合法的 JSON 数组，每个元素包含：
- "vi": 越南语单词或词组 (严格带标准越南语音标)
- "zh": 对应中文精确释义
- "cat": 分类名称 (固定填 "{category_name}")
- "eg_vi": 极简日常实用例句 (5-8个词左右)
- "eg_zh": 例句的中文翻译

格式严格遵循 JSON Array:
[
  {{"vi": "...", "zh": "...", "cat": "{category_name}", "eg_vi": "...", "eg_zh": "..."}}
]
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.2
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                items = json.loads(raw)
                if isinstance(items, list) and len(items) > 0:
                    print(f"[OK] Fetched {len(items)} items for '{category_name}'")
                    return items
        except Exception as e:
            print(f"[RETRY {attempt}] Error fetching '{category_name}': {e}")
            time.sleep(2.0 * attempt)
    return []

def main():
    print("Starting massive vocabulary expansion with Gemini...")
    all_results = []
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        future_map = {executor.submit(fetch_category_words, cat, desc): cat for cat, desc in CATEGORIES_AND_PROMPTS}
        for future in as_completed(future_map):
            items = future.result()
            all_results.extend(items)

    print(f"Total newly generated items from Gemini: {len(all_results)}")
    out_file = r'd:\Antigravity\VietDictApp\expanded_vocab.json'
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"Saved to: {out_file}")

if __name__ == '__main__':
    main()
