package com.antigravity.vietdict.util

import android.content.Context
import android.media.MediaPlayer
import android.util.Log

class AudioPlayer(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null

    fun playAssetAudio(fileName: String, onCompletion: (() -> Unit)? = null) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null

            val afd = context.assets.openFd("audio/$fileName")
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                setOnCompletionListener {
                    onCompletion?.invoke()
                }
                start()
            }
        } catch (e: Exception) {
            Log.e("AudioPlayer", "Error playing audio: $fileName", e)
            onCompletion?.invoke()
        }
    }

    fun release() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            Log.e("AudioPlayer", "Error releasing player", e)
        }
    }
}
