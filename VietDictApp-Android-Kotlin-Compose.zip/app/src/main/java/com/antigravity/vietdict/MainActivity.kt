package com.antigravity.vietdict

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.antigravity.vietdict.model.WordEntry
import com.antigravity.vietdict.util.AudioPlayer
import com.antigravity.vietdict.util.DictRepository

// 搜狗输入法经典主题色调：活力暖橙与清爽界面
val SogouOrangePrimary = Color(0xFFFF5722)
val SogouOrangeGradientStart = Color(0xFFFF4B2B)
val SogouOrangeGradientEnd = Color(0xFFFF6E40)
val SogouOrangeLight = Color(0xFFFFF3E0)
val SogouTextDark = Color(0xFF263238)
val SogouTextMuted = Color(0xFF78909C)
val SogouBg = Color(0xFFF9FAFB)

class MainActivity : ComponentActivity() {
    private lateinit var audioPlayer: AudioPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioPlayer = AudioPlayer(this)

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = SogouOrangePrimary,
                    secondary = SogouOrangeGradientEnd,
                    background = SogouBg,
                    surface = Color.White
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VietDictScreen(
                        onPlayAudio = { fileName ->
                            audioPlayer.playAssetAudio(fileName)
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VietDictScreen(onPlayAudio: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val allEntries = remember { DictRepository.loadDictionary(context) }

    var searchQuery by remember { mutableStateOf("") }
    var playingAudioName by remember { mutableStateOf<String?>(null) }

    // 直接对全部词库进行全局模糊/智能相关度检索，彻底移除分类
    val displayList = remember(searchQuery, allEntries) {
        DictRepository.search(allEntries, searchQuery)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // --- 搜狗风格顶部暖橙渐变 Header ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(SogouOrangeGradientStart, SogouOrangeGradientEnd)
                    ),
                    shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // 搜狗经典方圆图标徽标
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "词",
                            color = SogouOrangePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = "单词本",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // --- 搜索框：固定一个单字高度，空白无提示，有字时才显示清空按钮 ---
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = SogouOrangePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { searchQuery = "" },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = Color(0xFF78909C),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color(0xFFFFAB91),
                        unfocusedBorderColor = Color.Transparent
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // --- 统计提示栏 ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "共 ${displayList.size} 个词条",
                color = SogouTextMuted,
                fontSize = 12.sp
            )
            if (searchQuery.isNotBlank()) {
                Text(
                    text = "检索: \"$searchQuery\"",
                    color = SogouOrangePrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // --- 词条卡片列表 ---
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 6.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(displayList, key = { it.id }) { item ->
                WordCard(
                    entry = item,
                    isPlaying = playingAudioName == item.audio,
                    onPlay = {
                        playingAudioName = item.audio
                        onPlayAudio(item.audio)
                    }
                )
            }
        }
    }
}

@Composable
fun WordCard(
    entry: WordEntry,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 左侧：仅突出显示越南语单词（无任何多余分类标签与音标提示）
                Text(
                    text = entry.vi,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouTextDark,
                    modifier = Modifier.weight(1f)
                )

                // 搜狗橙发音按钮
                FilledIconButton(
                    onClick = onPlay,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isPlaying) Color(0xFF4CAF50) else SogouOrangeLight,
                        contentColor = if (isPlaying) Color.White else SogouOrangePrimary
                    ),
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PlayArrow else Icons.Default.VolumeUp,
                        contentDescription = "发音",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Divider(color = Color(0xFFF5F5F5), thickness = 1.dp)
            Spacer(modifier = Modifier.height(6.dp))

            // 中文释义
            Text(
                text = entry.zh,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = SogouTextDark
            )

            // 例句部分
            if (entry.eg_vi.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFAFAFA))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "例: ${entry.eg_vi}",
                        fontSize = 12.sp,
                        color = Color(0xFF455A64),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = entry.eg_zh,
                        fontSize = 11.sp,
                        color = SogouTextMuted
                    )
                }
            }
        }
    }
}
