package com.antigravity.vietdict

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.antigravity.vietdict.model.WordEntry
import com.antigravity.vietdict.util.AudioPlayer
import com.antigravity.vietdict.util.DictRepository

// 搜狗输入法经典主题色调：活力暖橙与清爽界面
val SogouOrangePrimary = Color(0xFFFF5722)
val SogouOrangeGradientStart = Color(0xFFFF4B2B)
val SogouOrangeGradientEnd = Color(0xFFFF6E40)
val SogouOrangeLight = Color(0xFFFFF3E0)
val SogouOrangeBorder = Color(0xFFFFCCBC)
val SogouTextDark = Color(0xFF263238)
val SogouTextMuted = Color(0xFF78909C)
val SogouBg = Color(0xFFF9FAFB)

class MainActivity : ComponentActivity() {
    private lateinit var audioPlayer: AudioPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioPlayer = AudioPlayer(this)

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = SogouOrangePrimary,
                    secondary = SogouOrangeGradientEnd,
                    background = SogouBg,
                    surface = Color.White
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VietDictScreen(
                        onPlayAudio = { fileName ->
                            audioPlayer.playAssetAudio(fileName)
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        audioPlayer.release()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VietDictScreen(onPlayAudio: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val allEntries = remember { DictRepository.loadDictionary(context) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("全部") }
    var playingAudioName by remember { mutableStateOf<String?>(null) }

    val categories = remember(allEntries) {
        listOf("全部") + allEntries.map { it.cat }.distinct()
    }

    val displayList = remember(searchQuery, selectedCategory, allEntries) {
        DictRepository.search(allEntries, searchQuery, selectedCategory)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // --- 搜狗风格顶部暖橙渐变 Header ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(SogouOrangeGradientStart, SogouOrangeGradientEnd)
                    ),
                    shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                )
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // 搜狗经典方圆图标徽标
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "词",
                            color = SogouOrangePrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "单词本",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "支持打中文或字母检索（如 toi 匹配所有声调）",
                            color = Color(0xFFFFE0B2),
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 搜狗风格圆润清爽搜索框
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = {
                        Text(
                            "输入中文或无声调字母 (如: toi, cam on, 晚上)",
                            fontSize = 14.sp,
                            color = Color(0xFFB0BEC5)
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = SogouOrangePrimary
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear",
                                    tint = Color.Gray
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = Color(0xFFFFAB91),
                        unfocusedBorderColor = Color.Transparent
                    )
                )
            }
        }

        // --- 搜狗风格分类胶囊标签 ---
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) SogouOrangePrimary else SogouOrangeLight)
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) Color.White else Color(0xFFE64A19),
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        // --- 统计提示栏 ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "共收录 ${displayList.size} 个常用词条",
                color = SogouTextMuted,
                fontSize = 12.sp
            )
            if (searchQuery.isNotBlank()) {
                Text(
                    text = "正在匹配: \"$searchQuery\"",
                    color = SogouOrangePrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // --- 词条卡片列表 ---
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(displayList, key = { it.id }) { item ->
                WordCard(
                    entry = item,
                    isPlaying = playingAudioName == item.audio,
                    onPlay = {
                        playingAudioName = item.audio
                        onPlayAudio(item.audio)
                    }
                )
            }
        }
    }
}

@Composable
fun WordCard(
    entry: WordEntry,
    isPlaying: Boolean,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = entry.vi,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = SogouTextDark
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SogouOrangeLight)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = entry.cat,
                                fontSize = 11.sp,
                                color = Color(0xFFD84315),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "无音标输入: ${entry.norm}",
                        fontSize = 11.sp,
                        color = SogouTextMuted
                    )
                }

                // 搜狗橙发音按钮
                FilledIconButton(
                    onClick = onPlay,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (isPlaying) Color(0xFF4CAF50) else SogouOrangeLight,
                        contentColor = if (isPlaying) Color.White else SogouOrangePrimary
                    ),
                    modifier = Modifier.size(42.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PlayArrow else Icons.Default.VolumeUp,
                        contentDescription = "发音",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color(0xFFF5F5F5), thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // 中文释义
            Text(
                text = entry.zh,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = SogouTextDark
            )

            // 例句部分
            if (entry.eg_vi.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFAFAFA))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "例: ${entry.eg_vi}",
                        fontSize = 13.sp,
                        color = Color(0xFF455A64),
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = entry.eg_zh,
                        fontSize = 12.sp,
                        color = SogouTextMuted
                    )
                }
            }
        }
    }
}
