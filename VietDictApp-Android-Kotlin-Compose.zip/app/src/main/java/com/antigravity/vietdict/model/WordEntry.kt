package com.antigravity.vietdict.model

data class WordEntry(
    val id: Int,
    val vi: String,
    val norm: String,
    val zh: String,
    val cat: String,
    val eg_vi: String,
    val eg_zh: String,
    val audio: String
)
