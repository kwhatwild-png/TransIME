package com.antigravity.vietdict.util

import android.content.Context
import com.antigravity.vietdict.model.WordEntry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.InputStreamReader

object DictRepository {
    private var cachedList: List<WordEntry>? = null

    fun loadDictionary(context: Context): List<WordEntry> {
        cachedList?.let { return it }

        return try {
            context.assets.open("dict_data.json").use { inputStream ->
                InputStreamReader(inputStream, Charsets.UTF_8).use { reader ->
                    val type = object : TypeToken<List<WordEntry>>() {}.type
                    val list: List<WordEntry> = Gson().fromJson(reader, type)
                    cachedList = list
                    list
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * Search dictionary with Smart Relevance Ranking:
     * 1. If English/Alphabet: match against norm (toi -> tôi, tối, tội, tới, tỏi)
     * 2. If Chinese: match against zh (primary translation) FIRST, then eg_zh
     * 3. Sort strictly by relevance:
     *    - Exact match on vi or zh comes FIRST! (e.g. search "我" -> "tôi" is #1)
     *    - zh starts with query comes next
     *    - zh contains query comes next
     *    - eg_zh (example sentence) matches come last
     */
    fun search(allEntries: List<WordEntry>, query: String, category: String? = null): List<WordEntry> {
        val trimmed = query.trim().lowercase()

        var filtered = allEntries
        if (!category.isNullOrBlank() && category != "全部") {
            filtered = filtered.filter { it.cat == category }
        }

        if (trimmed.isEmpty()) {
            return filtered
        }

        val isAsciiAlphabet = trimmed.all { it in 'a'..'z' || it in '0'..'9' || it.isWhitespace() }

        return filtered.mapNotNull { entry ->
            val score = calculateRelevanceScore(entry, trimmed, isAsciiAlphabet)
            if (score > 0) Pair(entry, score) else null
        }.sortedWith(compareByDescending<Pair<WordEntry, Int>> { it.second }
            .thenBy { it.first.vi.length }
            .thenBy { it.first.id }
        ).map { it.first }
    }

    private fun calculateRelevanceScore(entry: WordEntry, query: String, isAscii: Boolean): Int {
        val norm = entry.norm
        val viLower = entry.vi.lowercase()
        val zhLower = entry.zh.lowercase()
        val egZhLower = entry.eg_zh.lowercase()

        if (isAscii) {
            return when {
                norm == query || viLower == query -> 1000 // Exact match (e.g. toi == tôi)
                norm.startsWith(query) -> 800           // Prefix match (e.g. toi... )
                norm.contains(query) -> 500             // Substring match
                zhLower.contains(query) -> 200
                else -> 0
            }
        } else {
            // Chinese search
            return when {
                // Exact match on Chinese definition (e.g. "我" exactly matches "我" in "我 (正式/通用)")
                zhLower == query || zhLower.startsWith("$query ") || zhLower.startsWith("$query（") || zhLower.startsWith("$query(") -> 1000
                zhLower.startsWith(query) -> 800        // Starts with "我..." (e.g. 我们)
                zhLower.contains(query) -> 600          // Definition contains "我"
                viLower.contains(query) -> 400
                egZhLower.contains(query) -> 100        // Only matched inside example sentence (low priority)
                else -> 0
            }
        }
    }
}
