package com.antigravity.vietdict.util

import android.content.Context
import com.antigravity.vietdict.model.WordEntry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.InputStreamReader

object DictRepository {
    private var cachedList: List<WordEntry>? = null

    fun loadDictionary(context: Context): List<WordEntry> {
        cachedList?.let { return it }

        return try {
            context.assets.open("dict_data.json").use { inputStream ->
                InputStreamReader(inputStream, Charsets.UTF_8).use { reader ->
                    val type = object : TypeToken<List<WordEntry>>() {}.type
                    val list: List<WordEntry> = Gson().fromJson(reader, type)
                    cachedList = list
                    list
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * 去除中文释义中的括号及备注解释：
     * 如 "自己/亲昵称呼（爱人/好友）" -> "自己/亲昵称呼"
     * 如 "我 (正式/通用)" -> "我"
     * 如 "奶奶；女士 (尊称年长女士)" -> "奶奶；女士"
     * 确保搜索 "好" 绝不会匹配到括号里的 "好友"，只有真正释义是 "好" 的词才会匹配！
     */
    private fun getCoreChineseText(zh: String): String {
        return zh.replace(Regex("[\uff08\\(（\\[\u3010].*?[\uff09\\)）\\]\u3011]"), "").trim()
    }

    /**
     * 智能相关度检索：
     * 1. 严格不检索括号内的备注与例句解释
     * 2. 纯字母匹配无音标词（如 toi -> tôi, tối, tới, tội, tỏi）
     * 3. 中文精准优先：核心词完全相同 > 核心词前缀 > 核心词包含
     */
    fun search(allEntries: List<WordEntry>, query: String, category: String? = null): List<WordEntry> {
        val trimmed = query.trim().lowercase()

        var filtered = allEntries
        if (!category.isNullOrBlank() && category != "全部") {
            filtered = filtered.filter { it.cat == category }
        }

        if (trimmed.isEmpty()) {
            return filtered
        }

        val isAsciiAlphabet = trimmed.all { it in 'a'..'z' || it in '0'..'9' || it.isWhitespace() }

        return filtered.mapNotNull { entry ->
            val score = calculateRelevanceScore(entry, trimmed, isAsciiAlphabet)
            if (score > 0) Pair(entry, score) else null
        }.sortedWith(compareByDescending<Pair<WordEntry, Int>> { it.second }
            .thenBy { it.first.vi.length }
            .thenBy { it.first.id }
        ).map { it.first }
    }

    private fun calculateRelevanceScore(entry: WordEntry, query: String, isAscii: Boolean): Int {
        val norm = entry.norm
        val viLower = entry.vi.lowercase()
        // 获取去除所有括号和补充说明后的纯净核心中文释义
        val coreZh = getCoreChineseText(entry.zh).lowercase()

        if (isAscii) {
            return when {
                norm == query || viLower == query -> 1000 // 完全匹配（如 toi == tôi）
                norm.startsWith(query) -> 800           // 前缀匹配
                norm.contains(query) -> 500             // 包含匹配
                coreZh.contains(query) -> 200
                else -> 0
            }
        } else {
            // 中文检索：只在去除括号后的核心释义 coreZh 中比对！彻底屏蔽括号内容！
            if (!coreZh.contains(query)) {
                return 0
            }

            // 按分割符拆出多个释义项（如 "可以、行、好" -> ["可以", "行", "好"]）
            val defParts = coreZh.split(Regex("[/、;,；\\s]+")).map { it.trim() }

            return when {
                // 核心释义中有完全等于当前搜索词的项（例如搜索"好"，匹配到 tốt: "好" 或 được: "可以、行、好"里的"好"）
                defParts.any { it == query } -> 1000
                // 核心释义以搜索词开头（例如"好朋友"、"好处"）
                defParts.any { it.startsWith(query) } -> 800
                // 核心释义中间包含搜索词
                else -> 500
            }
        }
    }
}
