package com.antigravity.vietdict.util

import android.content.Context
import com.antigravity.vietdict.model.WordEntry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.InputStreamReader

object DictRepository {
    private var cachedList: List<WordEntry>? = null

    fun loadDictionary(context: Context): List<WordEntry> {
        cachedList?.let { return it }

        return try {
            context.assets.open("dict_data.json").use { inputStream ->
                InputStreamReader(inputStream, Charsets.UTF_8).use { reader ->
                    val type = object : TypeToken<List<WordEntry>>() {}.type
                    val list: List<WordEntry> = Gson().fromJson(reader, type)
                    cachedList = list
                    list
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * Search dictionary:
     * - If query has English letters (e.g. "toi", "cam on"), match against normalized field 'norm' or exact 'vi'
     * - If query has Chinese/other characters, match against 'zh' or 'eg_zh'
     * - Empty query returns full list
     */
    fun search(allEntries: List<WordEntry>, query: String, category: String? = null): List<WordEntry> {
        val trimmed = query.trim().lowercase()

        var filtered = allEntries
        if (!category.isNullOrBlank() && category != "全部") {
            filtered = filtered.filter { it.cat == category }
        }

        if (trimmed.isEmpty()) {
            return filtered
        }

        // Check if query is mostly ASCII / English alphabet (user typing without accents)
        val isAsciiAlphabet = trimmed.all { it in 'a'..'z' || it in '0'..'9' || it.isWhitespace() }

        return filtered.filter { entry ->
            if (isAsciiAlphabet) {
                // Match normalized vietnamese (e.g. 'toi' matches 'tôi', 'tối', 'tội', 'tới')
                entry.norm.contains(trimmed) || 
                entry.vi.lowercase().contains(trimmed) ||
                entry.zh.lowercase().contains(trimmed)
            } else {
                // Chinese or symbol search
                entry.zh.contains(trimmed, ignoreCase = true) ||
                entry.eg_zh.contains(trimmed, ignoreCase = true) ||
                entry.vi.contains(trimmed, ignoreCase = true)
            }
        }.sortedWith(compareBy(
            // Prioritize exact match or prefix match on norm or vi
            { !(it.norm == trimmed || it.vi.lowercase() == trimmed) },
            { !it.norm.startsWith(trimmed) },
            { it.id }
        ))
    }
}
