# -*- coding: utf-8 -*-
"""
Generate exact missing audios based on hash slug of vi text
"""
import os, sys, json, time, urllib.request, urllib.parse, hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

# Re-assign deterministic audio name based on MD5 of vietnamese text
for item in entries:
    h = hashlib.md5(item['vi'].strip().lower().encode('utf-8')).hexdigest()[:12]
    item['audio'] = f"{item['id']:04d}_{h}.mp3"

with open(JSON_PATH, 'w', encoding='utf-8') as f:
    json.dump(entries, f, ensure_ascii=False, indent=2)

print(f"Total entries: {len(entries)}")

def fetch_tts(text: str, retries=5):
    url = 'https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=tw-ob&q=' + urllib.parse.quote(text)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                content = resp.read()
                if len(content) > 500:
                    return content
        except Exception:
            time.sleep(0.3 * attempt)
    return None

missing_entries = []
for item in entries:
    p = os.path.join(AUDIO_DIR, item['audio'])
    if not os.path.exists(p) or os.path.getsize(p) < 500:
        missing_entries.append(item)

print(f"Need to download/cache {len(missing_entries)} audio files...")

def download_one(entry):
    out_path = os.path.join(AUDIO_DIR, entry['audio'])
    data = fetch_tts(entry['vi'])
    if data:
        with open(out_path, 'wb') as f:
            f.write(data)
        return True
    return False

if missing_entries:
    done = 0
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(download_one, item) for item in missing_entries]
        for f in as_completed(futures):
            if f.result():
                done += 1
            if done % 100 == 0 or done == len(missing_entries):
                print(f"Downloaded {done}/{len(missing_entries)} audio files...")

print("All audio files verified!")
