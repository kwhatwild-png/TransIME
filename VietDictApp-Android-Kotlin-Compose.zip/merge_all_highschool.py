# -*- coding: utf-8 -*-
"""
Merge all parts: seed + round1 + round2 + highschool + highschool_supplement
Target: ~3000 distinct words
"""
import json, unicodedata, re, os
from raw_seed import RAW_ENTRIES

def remove_vietnamese_accents(text: str) -> str:
    text = text.replace('đ', 'd').replace('Đ', 'D')
    nfkd = unicodedata.normalize('NFKD', text)
    res = ''.join([c for c in nfkd if not unicodedata.combining(c)])
    return re.sub(r'\s+', ' ', res).strip().lower()

def safe_filename(text: str, index: int) -> str:
    slug = re.sub(r'[^a-zA-Z0-9]+', '_', remove_vietnamese_accents(text)).strip('_')
    return f"{index:04d}_{slug}.wav"

files_to_load = [
    r'd:\Antigravity\VietDictApp\expanded_vocab.json',
    r'd:\Antigravity\VietDictApp\expanded_vocab_round2.json',
    r'd:\Antigravity\VietDictApp\highschool_vocab.json',
    r'd:\Antigravity\VietDictApp\highschool_supplement.json'
]

raw_pool = list(RAW_ENTRIES)
for f_path in files_to_load:
    if os.path.exists(f_path):
        with open(f_path, encoding='utf-8') as f:
            items = json.load(f)
            raw_pool.extend(items)

print(f"Total entries collected in pool: {len(raw_pool)}")

seen_vi = set()
unique_entries = []

for item in raw_pool:
    vi = item.get("vi", "").strip()
    if not vi or len(vi) > 40: # filter out overly long paragraphs
        continue
    norm_key = remove_vietnamese_accents(vi)
    vi_lower = vi.lower()

    if vi_lower in seen_vi:
        continue
    seen_vi.add(vi_lower)

    zh = item.get("zh", "").strip()
    cat = item.get("cat", "综合词汇").strip()
    eg_vi = item.get("eg_vi", "").strip()
    eg_zh = item.get("eg_zh", "").strip()

    unique_entries.append({
        "vi": vi,
        "norm": norm_key,
        "zh": zh,
        "cat": cat,
        "eg_vi": eg_vi,
        "eg_zh": eg_zh
    })

unique_entries.sort(key=lambda x: (x["norm"], x["vi"]))

final_entries = []
for idx, entry in enumerate(unique_entries, 1):
    audio_file = safe_filename(entry["vi"], idx)
    entry["id"] = idx
    entry["audio"] = audio_file
    final_entries.append(entry)

print(f"Total High-School Level Distinct Entries: {len(final_entries)}")

out_master = r'd:\Antigravity\VietDictApp\master_3000_dictionary.json'
with open(out_master, 'w', encoding='utf-8') as f:
    json.dump(final_entries, f, ensure_ascii=False, indent=2)

# Also update the app assets dict_data.json
app_dict_path = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'
with open(app_dict_path, 'w', encoding='utf-8') as f:
    json.dump(final_entries, f, ensure_ascii=False, indent=2)

print(f"Successfully saved to: {out_master} and {app_dict_path}")
