# -*- coding: utf-8 -*-
"""
Expert-Curated Synonym Expansion Database for High-Frequency Vietnamese Words
Enriches daily colloquial Chinese keywords for seamless, intelligent search.
"""
import json, os

JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

# Comprehensive high-frequency colloquial Vietnamese-to-Chinese synonym mappings
SYNONYM_RULES = {
    # 常用动词
    "làm": "做、干、弄、搞、办、从事",
    "xem": "看、瞧、查看、浏览、观摩",
    "đi": "去、走、出发、前往、出行",
    "về": "回、归、回去、返回",
    "đến": "到、来到、到达、抵达",
    "tới": "到、来、到达、来临",
    "ăn": "吃、用餐、进食",
    "uống": "喝、饮用",
    "nói": "说、讲、言谈、说话",
    "nghe": "听、收听、听闻、听取",
    "biết": "知道、会、懂得、晓得",
    "hiểu": "懂、明白、理解、领会",
    "nhớ": "想念、记得、回忆",
    "quên": "忘记、遗忘、疏忽",
    "mua": "买、购买、采购、选购",
    "bán": "卖、出售、贩卖、销售",
    "giúp": "帮助、帮忙、协助、援手",
    "cần": "需要、要、需求",
    "muốn": "想、要、希望、想要",
    "thích": "喜欢、喜爱、中意",
    "yêu": "爱、喜爱、热爱",
    "sửa": "修改、修理、维修、整改、改进",
    "sửa lại": "修改、重做、整改、返工",
    "đổi": "换、更换、交换、兑换",
    "tìm": "找、寻找、搜寻、查找",
    "gặp": "见、遇见、碰见、会面",
    "chờ": "等、等待、稍等、等候",
    "đợi": "等、等待、期盼",
    "mang": "带、拿、携带、佩戴",
    "cầm": "拿、握、持有、端着",
    "lấy": "拿、取、领、拿取",
    "đưa": "给、递、送、带去",
    "cho": "给、赠送、让、允许",
    "nhận": "收、接收、领受、认领",
    "gửi": "发、送、邮寄、寄送、转达",
    "mở": "开、打开、开启、启动",
    "đóng": "关、关闭、合上、封闭",
    "bật": "开、打开、开启（电器/开关）",
    "tắt": "关、关掉、熄灭、断电",
    "học": "学、学习、念书",
    "dạy": "教、传授、教授",
    "ngủ": "睡、睡觉、就寝、休息",
    "thức dậy": "起床、醒来",
    "tắm": "洗澡、冲凉、沐浴",
    "rửa": "洗、清洗、冲洗",
    "hỏi": "问、打听、询问、请教",
    "trả lời": "回答、答复、回应",
    "nghĩ": "想、思考、琢磨、考虑",
    "nghỉ": "休息、放假、歇着",
    "dừng lại": "停、停车、停下、止步",

    # 常用形容词
    "đẹp": "漂亮、美丽、好看、美观、标致",
    "đẹp quá": "太漂亮了、太好看了、绝美",
    "xấu": "难看、丑、坏、差劲",
    "tốt": "好、优秀、良好、善良",
    "ngon": "好吃、美味、可口、棒、香",
    "dở": "难吃、差、拙劣、糟糕",
    "nhiều": "多、大量、很多、丰富",
    "ít": "少、少量、稀少",
    "to": "大、巨大、宏大",
    "lớn": "大、重大、庞大、年长",
    "nhỏ": "小、微小、细小",
    "bé": "小、幼小、娇小",
    "nóng": "热、烫、炎热",
    "lạnh": "冷、寒冷、冰凉",
    "ấm": "暖、暖和、温和",
    "mát": "凉、凉爽、凉快",
    "đắt": "贵、昂贵、价高",
    "rẻ": "便宜、实惠、廉价",
    "nhanh": "快、敏捷、迅速、赶紧",
    "chậm": "慢、缓慢、迟缓",
    "sớm": "早、提早、清早",
    "muộn": "晚、迟、迟到",
    "mới": "新、新鲜、崭新",
    "cũ": "旧、陈旧、破旧",
    "sạch": "干净、清洁、整洁",
    "bẩn": "脏、污秽、邋遢",
    "vui": "开心、高兴、快乐、愉快",
    "buồn": "伤心、难过、悲伤、郁闷",
    "mệt": "累、疲倦、疲惫、辛苦",
    "khỏe": "健康、健壮、硬朗、有力",
    "đói": "饿、饥饿",
    "no": "饱、吃饱",
    "khát": "渴、口渴",
    "dễ": "容易、简单、好办",
    "khó": "难、困难、不容易、艰巨",
    "đúng": "对、正确、准、没错",
    "sai": "错、错误、差错",
    "tiện": "方便、顺便、便利",
    "rảnh": "有空、闲暇、空闲",
    "bận": "忙、忙碌、繁忙",

    # 生活高频
    "tính tiền": "结账、买单、算账、付款",
    "thanh toán": "付款、结算、结清、支付",
    "tiền": "钱、现金、钞票、款项",
    "đường": "路、道路、马路、街道；白糖、糖分",
    "đá": "冰、冰块；石头、岩石",
    "nước": "水、水分；国家、国度",
    "xe máy": "摩托车、机车、电瓶车",
    "xe ô tô": "汽车、轿车、小车",
    "nhà vệ sinh": "洗手间、厕所、卫生间、便所",
    "khách sạn": "酒店、宾馆、饭店、旅馆",
    "sân bay": "机场、候机楼",
    "bến xe": "车站、客运站、汽车站",
    "phòng": "房间、屋子、客房",
    "công trường": "工地、现场、工区",
    "tiến độ": "进度、工期、进程",
    "thi công": "施工、干活、作业",
    "an toàn": "安全、平安、稳妥",
    "chất lượng": "质量、品质、好坏",
    "bản vẽ": "图纸、设计图、图样",
    "vật liệu": "材料、建材、原料",
    "công nhân": "工人、师傅、劳工、民工",
    "kỹ sư": "工程师、技术员",
    "giám sát": "监理、监督、监控",
    "hợp đồng": "合同、契约、协议",
    "báo cáo": "汇报、报告、总结",
    "nhanh lên": "快点、抓紧、赶快、赶紧",
    "cẩn thận": "小心、当心、留神、注意",
    "trời ơi": "我的天、天哪、哎呀、天公",
    "đúng rồi": "对的、没错、是的、正是",
    "sao vậy": "怎么了、怎么回事、发生什么事了",
    "không sao": "没事、不要紧、没关系、无大碍",
    "kệ nó": "别管它、由它去、随它便",
    "chuẩn luôn": "太准了、完全正确、绝了、丝毫不差",
}

updated_cnt = 0
for item in entries:
    vi_clean = item['vi'].strip().lower()
    if vi_clean in SYNONYM_RULES:
        item['zh'] = SYNONYM_RULES[vi_clean]
        updated_cnt += 1

print(f"Applied enriched synonyms to {updated_cnt} core high-frequency words.")

with open(JSON_PATH, 'w', encoding='utf-8') as f:
    json.dump(entries, f, ensure_ascii=False, indent=2)

print("Dictionary JSON successfully updated!")
