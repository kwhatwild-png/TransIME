# -*- coding: utf-8 -*-
"""
Lightning fast async Edge TTS renderer with persistent connection session
"""
import asyncio, os, json, time
import edge_tts

AUDIO_DIR = r'd:\Antigravity\VietDictApp\app\src\main\assets\audio'
JSON_PATH = r'd:\Antigravity\VietDictApp\app\src\main\assets\dict_data.json'
VOICE = 'vi-VN-HoaiMyNeural'

with open(JSON_PATH, encoding='utf-8') as f:
    entries = json.load(f)

# Find items that need upgrade
cutoff = time.time() - 900
todo = []
for item in entries:
    p = os.path.join(AUDIO_DIR, item['audio'])
    if not os.path.exists(p) or os.path.getmtime(p) < cutoff:
        todo.append(item)

print(f"Items to process: {len(todo)}")

async def render_one(sem, item):
    async with sem:
        p = os.path.join(AUDIO_DIR, item['audio'])
        text = item['vi']
        for attempt in range(3):
            try:
                comm = edge_tts.Communicate(text, VOICE)
                await comm.save(p)
                if os.path.exists(p) and os.path.getsize(p) > 500:
                    return True
            except Exception:
                await asyncio.sleep(0.3)
        return False

async def main():
    sem = asyncio.Semaphore(15)
    tasks = [render_one(sem, item) for item in todo]
    results = await asyncio.gather(*tasks)
    print(f"Upgraded {sum(1 for r in results if r)}/{len(todo)} items!")

if __name__ == '__main__':
    asyncio.run(main())
