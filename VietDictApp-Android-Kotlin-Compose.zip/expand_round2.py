# -*- coding: utf-8 -*-
"""
Generate more supplementary words to reach ~1000 comprehensive entries
"""
import urllib.request, json, time, os
from concurrent.futures import ThreadPoolExecutor, as_completed

API_KEY = os.environ.get('GEMINI_API_KEY') or 'AQ.Ab8RN6IsKN7J1CGlUHdbJ420fhaa2kPYdtOAg2m2CsYJO7CPyg'
MODEL = 'gemini-3.1-flash-lite'
API_URL = f'https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={API_KEY}'

TOPICS = [
    ("基础单字", "越南语最常用的核心单音节字、助词、副词、虚词、连接词 (补充40个)"),
    ("人称社交", "亲属称呼、职场称呼、朋友称呼、各年龄层尊称 (补充40个)"),
    ("餐饮生活", "各种越南街头小吃、调料、蔬菜、海鲜、肉类、饮料、餐具、就餐短句 (补充45个)"),
    ("交通出行", "出租车、网约车、找路、火车站、加油、修理、换乘、方向位置短语 (补充40个)"),
    ("生活日常", "租房找房、水电燃气、洗衣服、打扫卫生、快递外卖、理发、逛街买菜 (补充45个)"),
    ("工作商务", "办公室日常、会议交流、收发邮件、请假出差、工资考勤、加班、辞职、面试 (补充45个)"),
    ("工程施工", "工地现场安全、隐患排查、机械设备、测量放线、隐蔽工程验收、工人调配 (补充45个)"),
    ("数字财务", "日常记账、汇率兑换、银行开户、转账支付、发票报销、税金、借钱还钱 (补充40个)"),
    ("医疗急救", "看病问诊、描述症状、药店买药、各类常用药、急救报警电话、突发事故应对 (补充40个)"),
    ("情感状态", "喜怒哀乐、性格评价、精神状态、生理感受(饿/渴/困/累)、态度表达 (补充40个)"),
    ("核心动词", "最常用的肢体动作、脑力动作、社交动作、生活动作 (补充45个)"),
    ("地道口语", "越南年轻人常用网络流行语、口头禅、反问句、感叹短语 (补充40个)")
]

def fetch_topic(topic_name, desc, retries=5):
    prompt = f"""
你是越南语母语专家。请针对以下主题【{topic_name}: {desc}】，补充 40 到 45 个极其实用、地道的日常越南语单词和短语。
必须严格输出合法的 JSON 数组，每个元素包含：
- "vi": 越南语单词或短语 (严格带标准越南语音标)
- "zh": 对应的中文精确翻译
- "cat": 分类名称 (固定填 "{topic_name}")
- "eg_vi": 极简短实用例句
- "eg_zh": 例句中文翻译

严格遵循 JSON Array:
[
  {{"vi": "...", "zh": "...", "cat": "{topic_name}", "eg_vi": "...", "eg_zh": "..."}}
]
"""
    payload = {
        'contents': [{'parts': [{'text': prompt}]}],
        'generationConfig': {
            'response_mime_type': 'application/json',
            'temperature': 0.2
        }
    }
    data_bytes = json.dumps(payload).encode('utf-8')
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(API_URL, data=data_bytes, headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=30) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                raw = res['candidates'][0]['content']['parts'][0]['text'].strip()
                items = json.loads(raw)
                if isinstance(items, list) and len(items) > 0:
                    print(f"[OK] Fetched {len(items)} supplementary items for '{topic_name}'")
                    return items
        except Exception as e:
            time.sleep(2.0 * attempt)
    return []

def main():
    print("Starting round 2 expansion...")
    results = []
    with ThreadPoolExecutor(max_workers=3) as executor:
        future_map = {executor.submit(fetch_topic, name, desc): name for name, desc in TOPICS}
        for future in as_completed(future_map):
            items = future.result()
            results.extend(items)
    
    out_file = r'd:\Antigravity\VietDictApp\expanded_vocab_round2.json'
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"Round 2 generated {len(results)} items saved to {out_file}")

if __name__ == '__main__':
    main()
