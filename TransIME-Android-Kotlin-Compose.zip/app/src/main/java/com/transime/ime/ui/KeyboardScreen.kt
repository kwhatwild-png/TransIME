package com.transime.ime.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.TranslationMode
import com.transime.ime.network.GeminiTranslationService
import com.transime.ime.speech.SpeechRecognitionHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Jetpack Compose 键盘主组件
 */
@Composable
fun KeyboardScreen(
    preferencesManager: PreferencesManager,
    onCommitText: (String) -> Unit,
    onDeleteBackward: () -> Unit,
    onPerformEditorAction: (Int) -> Unit,
    onSwitchToNextInputMethod: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }
    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLanguage by remember { mutableStateOf("") }
    var translationNotes by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }
    var isListeningVoice by remember { mutableStateOf(false) }

    val translationService = remember { GeminiTranslationService(context, preferencesManager) }
    val speechHelper = remember {
        SpeechRecognitionHelper(context) { resultText, isFinal ->
            inputText = resultText
            if (isFinal) {
                isListeningVoice = false
            }
        }
    }

    var debounceJob by remember { mutableStateOf<Job?>(null) }

    // 当输入文本变化时，防抖触发 Gemini Flash 实时互译
    LaunchedEffect(inputText, currentMode) {
        if (inputText.isBlank()) {
            translatedText = ""
            detectedLanguage = ""
            translationNotes = ""
            return@LaunchedEffect
        }

        debounceJob?.cancel()
        debounceJob = coroutineScope.launch {
            delay(350) // 350ms 防抖
            isTranslating = true
            try {
                val result = translationService.translateText(
                    text = inputText,
                    mode = currentMode,
                    tone = preferencesManager.getTonePreference(),
                    vietnameseHonorific = preferencesManager.getVietnameseHonorific()
                )
                translatedText = result.translatedText
                detectedLanguage = result.detectedLang
                translationNotes = result.notes
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isTranslating = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1E212B))
            .padding(bottom = 6.dp)
    ) {
        // 1. 顶部工具栏 (翻译模式切换按钮: 中 ⇄ 英、中 ⇄ 越，麦克风按钮，设置快捷入口)
        TopToolbar(
            currentMode = currentMode,
            onModeSelected = { currentMode = it },
            isListeningVoice = isListeningVoice,
            onToggleVoice = {
                if (isListeningVoice) {
                    speechHelper.stopListening()
                    isListeningVoice = false
                } else {
                    val targetLangCode = if (currentMode == TranslationMode.ZH_EN) "zh-CN" else "vi-VN"
                    speechHelper.startListening(targetLangCode)
                    isListeningVoice = true
                }
            },
            onSwitchIme = onSwitchToNextInputMethod
        )

        // 2. 双栏预览条 (识别原文 + AI 译文 + 一键上屏按钮)
        DualPanePreviewBar(
            inputText = inputText,
            translatedText = translatedText,
            detectedLanguage = detectedLanguage,
            translationNotes = translationNotes,
            isTranslating = isTranslating,
            onClearInput = {
                inputText = ""
                translatedText = ""
            },
            onCommit = {
                val textToCommit = if (translatedText.isNotEmpty()) translatedText else inputText
                if (textToCommit.isNotEmpty()) {
                    onCommitText(textToCommit)
                    // 上屏后清空当前暂存
                    inputText = ""
                    translatedText = ""
                }
            }
        )

        // 3. 软键盘打字区 (QWERTY 虚拟键区)
        VirtualQwertyKeyboard(
            onKeyTyped = { char -> inputText += char },
            onDelete = {
                if (inputText.isNotEmpty()) {
                    inputText = inputText.dropLast(1)
                } else {
                    onDeleteBackward()
                }
            },
            onSpace = { inputText += " " },
            onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
        )
    }
}

/**
 * 键盘顶部工具栏：中英 / 中越模式切换、麦克风语音按钮
 */
@Composable
fun TopToolbar(
    currentMode: TranslationMode,
    onModeSelected: (TranslationMode) -> Unit,
    isListeningVoice: Boolean,
    onToggleVoice: () -> Unit,
    onSwitchIme: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF151821))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // 模式切换按钮 1: 中 ⇄ 英
            FilterChip(
                selected = currentMode == TranslationMode.ZH_EN,
                onClick = { onModeSelected(TranslationMode.ZH_EN) },
                label = { Text("中 ⇄ 英", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF10B981),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF282C37),
                    labelColor = Color(0xFF94A3B8)
                )
            )

            // 模式切换按钮 2: 中 ⇄ 越
            FilterChip(
                selected = currentMode == TranslationMode.ZH_VI,
                onClick = { onModeSelected(TranslationMode.ZH_VI) },
                label = { Text("中 ⇄ 越", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF0EA5E9),
                    selectedLabelColor = Color.White,
                    containerColor = Color(0xFF282C37),
                    labelColor = Color(0xFF94A3B8)
                )
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            // 麦克风语音按钮 (调用 Android SpeechRecognizer)
            IconButton(
                onClick = onToggleVoice,
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (isListeningVoice) Color(0xFFEF4444) else Color(0xFF282C37),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isListeningVoice) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = "语音输入",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // 切换系统输入法小地球图标
            IconButton(onClick = onSwitchIme, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "切换输入法",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * 双栏预览条：展示‘识别原文’与‘译文’，以及一键‘上屏/发送’按钮
 */
@Composable
fun DualPanePreviewBar(
    inputText: String,
    translatedText: String,
    detectedLanguage: String,
    translationNotes: String,
    isTranslating: Boolean,
    onClearInput: () -> Unit,
    onCommit: () -> Unit
) {
    if (inputText.isBlank() && translatedText.isBlank()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .background(Color(0xFF242836), RoundedCornerShape(8.dp))
                .padding(8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "轻点下方打字或按麦克风语音输入，AI 即时互译...",
                color = Color(0xFF64748B),
                fontSize = 12.sp
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .background(Color(0xFF242836), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        // 原文行
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "原文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                modifier = Modifier.width(36.dp)
            )
            Text(
                text = inputText,
                fontSize = 13.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClearInput, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "清空", tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 译文行 + 一键上屏按钮
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "译文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF10B981),
                modifier = Modifier.width(36.dp)
            )

            if (isTranslating) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = Color(0xFF10B981),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Gemini Flash 翻译中...", fontSize = 12.sp, color = Color(0xFF10B981))
                }
            } else {
                Text(
                    text = translatedText.ifEmpty { "等待翻译..." },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF34D399),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // 一键上屏/发送按钮
            Button(
                onClick = onCommit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("上屏", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        if (translationNotes.isNotEmpty()) {
            Text(
                text = "💡 $translationNotes",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

/**
 * 虚拟 QWERTY 键盘布局
 */
@Composable
fun VirtualQwertyKeyboard(
    onKeyTyped: (String) -> Unit,
    onDelete: () -> Unit,
    onSpace: () -> Unit,
    onEnter: () -> Unit
) {
    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        // 第一行
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row1.forEach { key ->
                KeyButton(label = key, modifier = Modifier.weight(1f)) { onKeyTyped(key.lowercase()) }
            }
        }

        // 第二行
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row2.forEach { key ->
                KeyButton(label = key, modifier = Modifier.weight(1f)) { onKeyTyped(key.lowercase()) }
            }
        }

        // 第三行 (含退格按键)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            KeyButton(label = "⇧", modifier = Modifier.weight(1.5f), backgroundColor = Color(0xFF282C37)) { }
            row3.forEach { key ->
                KeyButton(label = key, modifier = Modifier.weight(1f)) { onKeyTyped(key.lowercase()) }
            }
            KeyButton(label = "⌫", modifier = Modifier.weight(1.5f), backgroundColor = Color(0xFF282C37)) { onDelete() }
        }

        // 第四行 (符号、空格、发送)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            KeyButton(label = "?123", modifier = Modifier.weight(1.5f), backgroundColor = Color(0xFF282C37)) { }
            KeyButton(label = ",", modifier = Modifier.weight(1f)) { onKeyTyped(",") }
            KeyButton(label = "空格 (Space)", modifier = Modifier.weight(4.5f)) { onSpace() }
            KeyButton(label = ".", modifier = Modifier.weight(1f)) { onKeyTyped(".") }
            KeyButton(label = "发送", modifier = Modifier.weight(2f), backgroundColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

@Composable
fun KeyButton(
    label: String,
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color(0xFF333846),
    textColor: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}