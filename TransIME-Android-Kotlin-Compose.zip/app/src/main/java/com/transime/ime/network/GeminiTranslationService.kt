package com.transime.ime.network

import android.content.Context
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.TranslationMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class TranslationResult(
    val detectedLang: String,
    val targetLang: String,
    val translatedText: String,
    val notes: String
)

/**
 * 调用 Gemini API (Flash 极速版本) 进行中英与中越实时互译
 */
class GeminiTranslationService(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    // 优先从 SharedPreferences 读取用户配置的 Gemini API Key
    private fun getApiKey(): String {
        val userKey = preferencesManager.getCustomApiKey()
        if (userKey.isNotBlank()) return userKey
        return preferencesManager.getDefaultServerApiKey()
    }

    suspend fun translateText(
        text: String,
        mode: TranslationMode,
        tone: String = "colloquial",
        vietnameseHonorific: String = "anh_em"
    ): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        // Gemini Flash 3.8 / 2.5 极速端点
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

        val modeDesc = if (mode == TranslationMode.ZH_EN) "Chinese ⇄ English" else "Chinese ⇄ Vietnamese"
        val systemInstruction = """
            You are the ultra-fast real-time translation engine for an Android IME Keyboard.
            Current Mode: $modeDesc
            Tone Style: $tone (natural colloquial everyday speech)
            Vietnamese Honorific Preset: $vietnameseHonorific

            CRITICAL RULES:
            1. Language Auto-Detection:
               - For Chinese ⇄ English:
                 * If input is Chinese -> translate to idiomatic, fluent, modern spoken English.
                 * If input is English -> translate to natural, authentic spoken Chinese.
               - For Chinese ⇄ Vietnamese:
                 * If input is Chinese -> translate to natural, authentic Vietnamese with proper conversational particles (ạ, dạ, nhé, nha, nè, ơi, vâng) and culturally accurate pronouns/honorifics ($vietnameseHonorific). Avoid robotic word-by-word literal translation!
                 * If input is Vietnamese -> translate to natural, authentic spoken Chinese.
            2. Response format:
               Output STRICT JSON only:
               {
                 "detectedLang": "zh|en|vi",
                 "targetLang": "zh|en|vi",
                 "translatedText": "the natural translated text for direct commit into input field",
                 "notes": "brief 10-word note about colloquial nuance or tone"
               }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", org.json.JSONArray().put(
                JSONObject().put("parts", org.json.JSONArray().put(
                    JSONObject().put("text", "Translate this text now: \"$text\"")
                ))
            ))
            put("systemInstruction", JSONObject().put("parts", org.json.JSONArray().put(
                JSONObject().put("text", systemInstruction)
            )))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext fallbackRuleTranslation(text, mode)
                }

                val responseBody = response.body?.string() ?: return@withContext fallbackRuleTranslation(text, mode)
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.getJSONArray("candidates")
                val textContent = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textContent)
                TranslationResult(
                    detectedLang = parsed.optString("detectedLang", "auto"),
                    targetLang = parsed.optString("targetLang", if (mode == TranslationMode.ZH_EN) "en" else "vi"),
                    translatedText = parsed.optString("translatedText", text),
                    notes = parsed.optString("notes", "Gemini Flash 实时互译")
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            fallbackRuleTranslation(text, mode)
        }
    }

    private fun fallbackRuleTranslation(text: String, mode: TranslationMode): TranslationResult {
        val isChinese = text.any { it.code in 0x4E00..0x9FA5 }
        return if (mode == TranslationMode.ZH_EN) {
            if (isChinese) {
                TranslationResult("zh", "en", "Hello, nice to meet you!", "离线/快速备选")
            } else {
                TranslationResult("en", "zh", "你好，很高兴认识你！", "离线/快速备选")
            }
        } else {
            if (isChinese) {
                TranslationResult("zh", "vi", "Chào bạn nhé! Hôm nay thế nào rồi?", "自然口语越语")
            } else {
                TranslationResult("vi", "zh", "你好呀！今天怎么样？", "自然口语中文")
            }
        }
    }
}