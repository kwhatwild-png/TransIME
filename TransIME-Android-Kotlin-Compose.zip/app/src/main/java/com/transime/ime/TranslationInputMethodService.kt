package com.transime.ime

import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.ViewTreeLifecycleOwner
import androidx.lifecycle.ViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.ViewTreeSavedStateRegistryOwner
import com.transime.ime.data.PreferencesManager
import com.transime.ime.ui.KeyboardScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * 实时中英/中越翻译输入法服务
 * 继承自 Android InputMethodService，支持在微信、WhatsApp、浏览器等任意 App 调起
 */
class TranslationInputMethodService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        preferencesManager = PreferencesManager(applicationContext)
    }

    override fun onCreateInputView(): View {
        val composeView = ComposeView(this).apply {
            // 装配 Jetpack Compose 在 Service 中的生命周期与状态树
            ViewTreeLifecycleOwner.set(this, this@TranslationInputMethodService)
            ViewTreeViewModelStoreOwner.set(this, this@TranslationInputMethodService)
            ViewTreeSavedStateRegistryOwner.set(this, this@TranslationInputMethodService)

            setContent {
                KeyboardScreen(
                    preferencesManager = preferencesManager,
                    onCommitText = { text -> commitTextToApp(text) },
                    onDeleteBackward = { deleteBackward() },
                    onPerformEditorAction = { actionId -> performEditorAction(actionId) },
                    onSwitchToNextInputMethod = {
                        // 切换至系统其他输入法
                        try {
                            switchToNextInputMethod(false)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                )
            }
        }
        return composeView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    /**
     * 一键上屏：通过 InputConnection.commitText 将译文填入当前宿主 App 光标位置
     */
    private fun commitTextToApp(text: String) {
        val ic: InputConnection? = currentInputConnection
        if (ic != null && text.isNotEmpty()) {
            ic.commitText(text, 1)
        }
    }

    /**
     * 退格删除操作
     */
    private fun deleteBackward() {
        val ic: InputConnection? = currentInputConnection
        ic?.deleteSurroundingText(1, 0)
    }

    /**
     * 执行回车或发送 Action (如微信发送、搜索、换行等)
     */
    private fun performEditorAction(actionId: Int) {
        val ic: InputConnection? = currentInputConnection
        ic?.performEditorAction(actionId)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()
    }
}