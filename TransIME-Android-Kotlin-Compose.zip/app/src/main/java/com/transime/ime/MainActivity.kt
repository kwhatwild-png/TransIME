package com.transime.ime

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.TranslationMode

/**
 * 主应用配置页 Activity
 */
class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesManager = PreferencesManager(applicationContext)

        setContent {
            MaterialTheme {
                SettingsScreen(
                    preferencesManager = preferencesManager,
                    onOpenSystemImeSettings = {
                        // 引导开启系统输入法权限
                        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                        startActivity(intent)
                    },
                    onOpenImePicker = {
                        // 弹出系统输入法切换对话框
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showInputMethodPicker()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    onOpenSystemImeSettings: () -> Unit,
    onOpenImePicker: () -> Unit
) {
    val context = LocalContext.current
    var apiKey by remember { mutableStateOf(preferencesManager.getCustomApiKey()) }
    var defaultMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }
    var vietnameseHonorific by remember { mutableStateOf(preferencesManager.getVietnameseHonorific()) }
    var savedMessageVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 顶部品牌标题
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Translate, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("TransIME 实时翻译输入法", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("中英 / 中越极速双向智能互译 (Gemini Flash)", fontSize = 12.sp, color = Color(0xFF94A3B8))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 步骤 1: 引导开启系统输入法
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("第一步：启用输入法服务", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "请进入系统设置中启用 TransIME 输入法，以便在微信、WhatsApp 等任意应用中调用。",
                    fontSize = 13.sp,
                    color = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onOpenSystemImeSettings,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("前往系统设置开启 TransIME")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 步骤 2: 切换当前输入法为 TransIME
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("第二步：选择 TransIME 为当前输入法", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "点击下方按钮弹出系统输入法切换列表，选择 TransIME 即可立即体验。",
                    fontSize = 13.sp,
                    color = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onOpenImePicker,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF38BDF8)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Keyboard, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("弹出选择输入法弹窗")
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 步骤 3: Gemini API Key 填写与存储
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("第三步：Gemini Flash API 配置", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "使用 Google Gemini 极速 Flash 模型提供高质量口语化互译。可填入您的 Gemini API Key：",
                    fontSize = 13.sp,
                    color = Color(0xFFCBD5E1)
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color(0xFF10B981),
                        focusedBorderColor = Color(0xFF10B981)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        preferencesManager.saveCustomApiKey(apiKey)
                        savedMessageVisible = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("保存 API Key")
                }

                if (savedMessageVisible) {
                    Text("已成功保存 API Key 到本地安全配置！", color = Color(0xFF10B981), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 步骤 4: 常用偏好设置 (越南语称谓习惯、默认模式)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("翻译偏好与越南语称谓", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))

                Text("默认启动模式:", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = defaultMode == TranslationMode.ZH_EN,
                        onClick = {
                            defaultMode = TranslationMode.ZH_EN
                            preferencesManager.saveDefaultMode(TranslationMode.ZH_EN)
                        },
                        label = { Text("中 ⇄ 英") }
                    )
                    FilterChip(
                        selected = defaultMode == TranslationMode.ZH_VI,
                        onClick = {
                            defaultMode = TranslationMode.ZH_VI
                            preferencesManager.saveDefaultMode(TranslationMode.ZH_VI)
                        },
                        label = { Text("中 ⇄ 越") }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("越南语默认称谓 (符合当地习惯):", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(4.dp))
                val honorificOptions = listOf(
                    "anh_em" to "我自称 Em，称对方 Anh (常用于对年长男性/长辈)",
                    "em_anh" to "我自称 Anh，称对方 Em (常用于对弟妹/晚辈)",
                    "ban_minh" to "平等朋友: Mình / Bạn (日常同龄朋友)",
                    "chi_em" to "我自称 Em，称对方 Chị (常用于女性客户/姐姐)"
                )

                honorificOptions.forEach { (key, desc) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        RadioButton(
                            selected = vietnameseHonorific == key,
                            onClick = {
                                vietnameseHonorific = key
                                preferencesManager.saveVietnameseHonorific(key)
                            }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(desc, fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }
    }
}