package com.transime.translate.data

import android.content.Context
import android.content.SharedPreferences

data class Language(
    val code: String,
    val displayName: String,
    val flag: String,
    val ttsLocale: String = "en"
)

object SupportedLanguages {
    val ALL = listOf(
        Language("auto", "自动检测", "🌐", "zh"),
        Language("zh", "中文 (简体)", "🇨🇳", "zh"),
        Language("en", "英语 (English)", "🇺🇸", "en"),
        Language("vi", "越南语 (Tiếng Việt)", "🇻🇳", "vi"),
        Language("ja", "日语 (日本語)", "🇯🇵", "ja"),
        Language("ko", "韩语 (한국어)", "🇰🇷", "ko"),
        Language("fr", "法语 (Français)", "🇫🇷", "fr"),
        Language("es", "西班牙语 (Español)", "🇪🇸", "es"),
        Language("ru", "俄语 (Русский)", "🇷🇺", "ru"),
        Language("de", "德语 (Deutsch)", "🇩🇪", "de"),
        Language("th", "泰语 (ไทย)", "🇹🇭", "th")
    )

    fun getByCode(code: String): Language {
        return ALL.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: Language(code, code, "🌐", "en")
    }
}

data class TranslationHistoryItem(
    val id: Long = System.currentTimeMillis(),
    val sourceLang: String,
    val targetLang: String,
    val sourceText: String,
    val translatedText: String,
    val timestamp: Long = System.currentTimeMillis(),
    var isFavorite: Boolean = false
)

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("google_translate_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_BASE_URL = "custom_gemini_base_url"
        private const val KEY_SOURCE_LANG = "last_source_lang"
        private const val KEY_TARGET_LANG = "last_target_lang"
        private const val KEY_HISTORY_JSON = "translation_history_json"
    }

    fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""
    fun saveApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key.trim()).apply()

    fun getBaseUrl(): String {
        val url = prefs.getString(KEY_BASE_URL, "") ?: ""
        return if (url.isBlank()) "https://generativelanguage.googleapis.com" else url.trim().removeSuffix("/")
    }
    fun saveBaseUrl(url: String) = prefs.edit().putString(KEY_BASE_URL, url.trim().removeSuffix("/")).apply()

    fun getSourceLang(): String = prefs.getString(KEY_SOURCE_LANG, "auto") ?: "auto"
    fun saveSourceLang(code: String) = prefs.edit().putString(KEY_SOURCE_LANG, code).apply()

    fun getTargetLang(): String = prefs.getString(KEY_TARGET_LANG, "en") ?: "en"
    fun saveTargetLang(code: String) = prefs.edit().putString(KEY_TARGET_LANG, code).apply()

    // 历史记录
    fun getHistory(): List<TranslationHistoryItem> {
        val raw = prefs.getString(KEY_HISTORY_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val array = org.json.JSONArray(raw)
            val list = mutableListOf<TranslationHistoryItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    TranslationHistoryItem(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        sourceLang = obj.optString("sourceLang", "zh"),
                        targetLang = obj.optString("targetLang", "en"),
                        sourceText = obj.optString("sourceText", ""),
                        translatedText = obj.optString("translatedText", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        isFavorite = obj.optBoolean("isFavorite", false)
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(list: List<TranslationHistoryItem>) {
        try {
            val array = org.json.JSONArray()
            for (item in list.take(100)) { // 保留最近 100 条
                val obj = org.json.JSONObject().apply {
                    put("id", item.id)
                    put("sourceLang", item.sourceLang)
                    put("targetLang", item.targetLang)
                    put("sourceText", item.sourceText)
                    put("translatedText", item.translatedText)
                    put("timestamp", item.timestamp)
                    put("isFavorite", item.isFavorite)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY_JSON, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addHistoryItem(item: TranslationHistoryItem) {
        val current = getHistory().toMutableList()
        current.removeAll { it.sourceText == item.sourceText && it.targetLang == item.targetLang }
        current.add(0, item)
        saveHistory(current)
    }
}
