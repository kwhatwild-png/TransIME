package com.transime.translate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.transime.translate.data.*
import com.transime.translate.network.GeminiTranslateEngine
import com.transime.translate.ui.GoogleIcons
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * 谷歌翻译主题配色 (Google Material You 沉浸式设计)
 */
object GoogleTranslateTheme {
    val PageBg = Color(0xFFF8F9FA)            // 浅灰自然底色
    val CardBg = Color(0xFFFFFFFF)            // 纯白高雅卡片
    val PrimaryBlue = Color(0xFF1A73E8)       // 谷歌品牌蓝
    val PrimaryBlueDark = Color(0xFF1557B0)
    val PrimaryBlueLight = Color(0xFFE8F0FE)  // 谷歌浅蓝按键背景
    val TextPrimary = Color(0xFF202124)       // 标题深黑
    val TextSecondary = Color(0xFF5F6368)     // 辅助灰色
    val CardBorder = Color(0xFFDADCE0)        // 浅灰微边框
    val ActionRed = Color(0xFFEA4335)         // 录音中提示红
    val TipBg = Color(0xFFFEF7E0)             // 提示淡黄底色
    val TipText = Color(0xFFB06000)           // 提示深橙色
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var translateEngine: GeminiTranslateEngine
    private var textToSpeech: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. 开启真正的全面屏沉浸式状态栏 (Edge-to-Edge)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        preferencesManager = PreferencesManager(applicationContext)
        translateEngine = GeminiTranslateEngine(applicationContext, preferencesManager)

        // 初始化本地 TTS 语音朗读引擎
        textToSpeech = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.CHINESE
            }
        }

        setContent {
            MaterialTheme {
                GoogleTranslateMainScreen(
                    context = this,
                    preferencesManager = preferencesManager,
                    translateEngine = translateEngine,
                    onSpeak = { text, langCode -> speakText(text, langCode) }
                )
            }
        }
    }

    private fun speakText(text: String, langCode: String) {
        if (text.isBlank()) return
        try {
            val locale = when (langCode) {
                "zh" -> Locale.CHINESE
                "en" -> Locale.ENGLISH
                "vi" -> Locale("vi", "VN")
                "ja" -> Locale.JAPANESE
                "ko" -> Locale.KOREAN
                "fr" -> Locale.FRENCH
                "es" -> Locale("es", "ES")
                "ru" -> Locale.RUSSIAN
                "de" -> Locale.GERMAN
                else -> Locale.ENGLISH
            }
            textToSpeech?.language = locale
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "UTTERANCE_ID")
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "语音朗读不可用: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleTranslateMainScreen(
    context: Context,
    preferencesManager: PreferencesManager,
    translateEngine: GeminiTranslateEngine,
    onSpeak: (String, String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(0) } // 0: 翻译主页, 1: 历史记录, 2: 设置

    var sourceLangCode by remember { mutableStateOf(preferencesManager.getSourceLang()) }
    var targetLangCode by remember { mutableStateOf(preferencesManager.getTargetLang()) }
    var voiceMode by remember { mutableStateOf(preferencesManager.getVoiceMode()) }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLangCode by remember { mutableStateOf("") }
    var noteExplanation by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }

    // 录音状态
    var isRecording by remember { mutableStateOf(false) }
    var isSystemListening by remember { mutableStateOf(false) }
    var mediaRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var audioRecordFile by remember { mutableStateOf<File?>(null) }

    // 触发文本翻译
    val performTextTranslation: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isTranslating = true
            coroutineScope.launch {
                val res = translateEngine.translateText(query, sourceLangCode, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                noteExplanation = res.explanation
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = query,
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        }
    }

    // 动态录音权限请求 Launcher
    val recordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "已授予录音权限，请点击麦克风开始说话", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "需要录音权限才能使用语音输入功能", Toast.LENGTH_SHORT).show()
        }
    }

    // 系统原生语音引擎
    val speechRecognizer = remember {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                SpeechRecognizer.createSpeechRecognizer(context)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    DisposableEffect(speechRecognizer) {
        onDispose {
            try {
                speechRecognizer?.destroy()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // 模式一：本地原生系统语音组件
    val startSystemLocalSpeech: () -> Unit = {
        if (speechRecognizer == null) {
            Toast.makeText(context, "手机未安装 Google 语音引擎，已自动为您使用云端极速识别", Toast.LENGTH_SHORT).show()
        } else {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (sourceLangCode == "auto" || sourceLangCode == "zh") "zh-CN" else sourceLangCode)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "正在聆听，请说话...")
            }
            speechRecognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { isSystemListening = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { isSystemListening = false }
                override fun onError(error: Int) {
                    isSystemListening = false
                    Toast.makeText(context, "识别结束 (错误码 $error)", Toast.LENGTH_SHORT).show()
                }
                override fun onResults(results: Bundle?) {
                    isSystemListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val voiceText = matches[0]
                        inputText = voiceText
                        performTextTranslation(voiceText)
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer.startListening(intent)
        }
    }

    // 模式二：云端 API 录音直传识别 (免装任何本地组件)
    val stopRecordingAndProcess: () -> Unit = {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaRecorder = null
        isRecording = false

        val file = audioRecordFile
        if (file != null && file.exists() && file.length() > 0) {
            isTranslating = true
            inputText = "【🎙️ 正在上传录音并进行多语种识别...】"
            translatedText = ""
            coroutineScope.launch {
                val res = translateEngine.recognizeAndTranslateAudio(file, targetLangCode)
                if (res.recognizedText.isNotBlank()) {
                    inputText = res.recognizedText
                } else {
                    inputText = "【语音识别完成】"
                }
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                noteExplanation = res.explanation
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = if (res.recognizedText.isNotBlank()) res.recognizedText else "🎙️ 语音输入",
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        } else {
            Toast.makeText(context, "录音时间过短或未采集到声音", Toast.LENGTH_SHORT).show()
        }
    }

    val startAudioRecording: () -> Unit = {
        try {
            val file = File(context.cacheDir, "voice_input_${System.currentTimeMillis()}.m4a")
            audioRecordFile = file

            @Suppress("DEPRECATION")
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(96000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            isRecording = true
            Toast.makeText(context, "🎙️ 正在录音，请说话... (说完请再次点击停止)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            isRecording = false
            Toast.makeText(context, "启动录音失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    // 语音输入总调度
    val handleVoiceAction: () -> Unit = {
        val audioPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (audioPermission != PackageManager.PERMISSION_GRANTED) {
            recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            if (voiceMode == VoiceMode.SYSTEM_LOCAL && SpeechRecognizer.isRecognitionAvailable(context)) {
                startSystemLocalSpeech()
            } else {
                if (isRecording) {
                    stopRecordingAndProcess()
                } else {
                    startAudioRecording()
                }
            }
        }
    }

    // 全屏沉浸式 Scaffold（使用 WindowInsets.statusBars 自动贴合全面屏状态栏）
    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(GoogleTranslateTheme.CardBg).statusBarsPadding()) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(GoogleIcons.Translate, contentDescription = null, tint = GoogleTranslateTheme.PrimaryBlue)
                            Text("Google 翻译", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GoogleTranslateTheme.TextPrimary)
                        }
                    },
                    actions = {
                        IconButton(onClick = { currentTab = if (currentTab == 1) 0 else 1 }) {
                            Icon(GoogleIcons.History, contentDescription = "历史", tint = if (currentTab == 1) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                        IconButton(onClick = { currentTab = if (currentTab == 2) 0 else 2 }) {
                            Icon(GoogleIcons.Settings, contentDescription = "设置", tint = if (currentTab == 2) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleTranslateTheme.CardBg)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GoogleTranslateTheme.PageBg)
                .navigationBarsPadding()
        ) {
            when (currentTab) {
                0 -> {
                    TranslateHomeScreen(
                        sourceLangCode = sourceLangCode,
                        targetLangCode = targetLangCode,
                        onSourceLangChange = {
                            sourceLangCode = it
                            preferencesManager.saveSourceLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onTargetLangChange = {
                            targetLangCode = it
                            preferencesManager.saveTargetLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onSwapLanguages = {
                            if (sourceLangCode != "auto") {
                                val temp = sourceLangCode
                                sourceLangCode = targetLangCode
                                targetLangCode = temp
                                preferencesManager.saveSourceLang(sourceLangCode)
                                preferencesManager.saveTargetLang(targetLangCode)
                                if (translatedText.isNotBlank() && !translatedText.startsWith("【")) {
                                    val oldTrans = translatedText
                                    inputText = oldTrans
                                    performTextTranslation(oldTrans)
                                }
                            }
                        },
                        inputText = inputText,
                        onInputTextChange = { inputText = it },
                        translatedText = translatedText,
                        detectedLangCode = detectedLangCode,
                        noteExplanation = noteExplanation,
                        isTranslating = isTranslating,
                        isRecording = isRecording || isSystemListening,
                        onTranslateClick = { performTextTranslation(inputText) },
                        onVoiceClick = handleVoiceAction,
                        onSpeak = onSpeak,
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", text))
                            Toast.makeText(context, "已复制到剪切板", Toast.LENGTH_SHORT).show()
                        },
                        onClear = {
                            inputText = ""
                            translatedText = ""
                            detectedLangCode = ""
                            noteExplanation = ""
                        }
                    )
                }
                1 -> {
                    HistoryScreen(
                        preferencesManager = preferencesManager,
                        onSelectHistory = { item ->
                            sourceLangCode = item.sourceLang
                            targetLangCode = item.targetLang
                            inputText = item.sourceText
                            translatedText = item.translatedText
                            currentTab = 0
                        },
                        onClearAll = {
                            preferencesManager.saveHistory(emptyList())
                        }
                    )
                }
                2 -> {
                    SettingsScreen(
                        preferencesManager = preferencesManager,
                        voiceMode = voiceMode,
                        onVoiceModeChange = {
                            voiceMode = it
                            preferencesManager.saveVoiceMode(it)
                        },
                        onSaved = {
                            currentTab = 0
                            Toast.makeText(context, "配置已保存", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

/**
 * 翻译主页 (语言栏 + 原文输入与独立语音大按钮 + 译文卡片与纯中文提示)
 */
@Composable
fun TranslateHomeScreen(
    sourceLangCode: String,
    targetLangCode: String,
    onSourceLangChange: (String) -> Unit,
    onTargetLangChange: (String) -> Unit,
    onSwapLanguages: () -> Unit,
    inputText: String,
    onInputTextChange: (String) -> Unit,
    translatedText: String,
    detectedLangCode: String,
    noteExplanation: String,
    isTranslating: Boolean,
    isRecording: Boolean,
    onTranslateClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onSpeak: (String, String) -> Unit,
    onCopy: (String) -> Unit,
    onClear: () -> Unit
) {
    var showSourceLangDialog by remember { mutableStateOf(false) }
    var showTargetLangDialog by remember { mutableStateOf(false) }

    val sourceLang = SupportedLanguages.getByCode(sourceLangCode)
    val targetLang = SupportedLanguages.getByCode(targetLangCode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. 语言切换药丸条 (Google Material 胶囊 Bar)
        Card(
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = { showSourceLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${sourceLang.flag} ${sourceLang.displayName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }

                IconButton(onClick = onSwapLanguages, enabled = sourceLangCode != "auto") {
                    Icon(GoogleIcons.SwapHoriz, contentDescription = "对调语种", tint = if (sourceLangCode != "auto") GoogleTranslateTheme.PrimaryBlue else Color.LightGray)
                }

                TextButton(onClick = { showTargetLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${targetLang.flag} ${targetLang.displayName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }
            }
        }

        // 2. 原文输入卡片
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (detectedLangCode.isNotBlank() && sourceLangCode == "auto") "检测到语言: ${SupportedLanguages.getByCode(detectedLangCode).displayName}" else sourceLang.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GoogleTranslateTheme.TextSecondary
                    )
                    if (inputText.isNotBlank()) {
                        Text(
                            text = "清空",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoogleTranslateTheme.ActionRed,
                            modifier = Modifier.clickable { onClear() }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = { Text("在此输入要翻译的内容，或点击下方开始语音输入...", color = Color.Gray, fontSize = 15.sp) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 220.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    )
                )

                // 底部操作栏：朗读 + 翻译大按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inputText.isNotBlank()) {
                        IconButton(onClick = { onSpeak(inputText, if (detectedLangCode.isNotBlank()) detectedLangCode else sourceLangCode) }) {
                            Icon(GoogleIcons.VolumeUp, contentDescription = "朗读原文", tint = GoogleTranslateTheme.TextSecondary)
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    Button(
                        onClick = onTranslateClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                        shape = RoundedCornerShape(20.dp),
                        enabled = !isTranslating && inputText.isNotBlank()
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("立即翻译", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // 3. 专属单人语音输入大卡片 (经典 Google 麦克风居中设计)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = if (isRecording) GoogleTranslateTheme.ActionRed.copy(alpha = 0.12f) else GoogleTranslateTheme.PrimaryBlueLight),
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
                .clickable { onVoiceClick() }
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlue, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        GoogleIcons.Mic,
                        contentDescription = "语音输入",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        if (isRecording) "正在聆听，请说话... (点击完成)" else "单人语音输入",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlueDark
                    )
                    Text(
                        if (isRecording) "说话结束后点击此栏立即出译文" else "支持中英越等多语种自动转写与互译",
                        fontSize = 11.sp,
                        color = if (isRecording) GoogleTranslateTheme.ActionRed.copy(alpha = 0.8f) else GoogleTranslateTheme.TextSecondary
                    )
                }
            }
        }

        // 4. 译文展示卡片 (Google 原生蓝底卡片 + 纯中文用法与语境提示)
        if (translatedText.isNotBlank() || isTranslating) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = targetLang.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Row {
                            IconButton(onClick = { onSpeak(translatedText, targetLangCode) }) {
                                Icon(GoogleIcons.VolumeUp, contentDescription = "朗读译文", tint = Color.White)
                            }
                            IconButton(onClick = { onCopy(translatedText) }) {
                                Icon(GoogleIcons.ContentCopy, contentDescription = "复制译文", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (isTranslating) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text("Gemini 正在进行地道翻译...", color = Color.White, fontSize = 15.sp)
                        }
                    } else {
                        Text(
                            text = translatedText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            lineHeight = 25.sp
                        )
                    }

                    // 纯中文提示卡片 (Chinese Explanation Box)
                    if (noteExplanation.isNotBlank() && !isTranslating) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "💡 语法与地道用法中文解析：",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFD54F) // 明亮护眼淡金黄
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = noteExplanation,
                                    fontSize = 13.sp,
                                    color = Color.White,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSourceLangDialog) {
        LanguageSelectDialog(
            title = "选择源语言",
            selectedCode = sourceLangCode,
            languages = SupportedLanguages.ALL,
            onSelect = {
                onSourceLangChange(it)
                showSourceLangDialog = false
            },
            onDismiss = { showSourceLangDialog = false }
        )
    }

    if (showTargetLangDialog) {
        LanguageSelectDialog(
            title = "选择翻译目标语言",
            selectedCode = targetLangCode,
            languages = SupportedLanguages.ALL.filter { it.code != "auto" },
            onSelect = {
                onTargetLangChange(it)
                showTargetLangDialog = false
            },
            onDismiss = { showTargetLangDialog = false }
        )
    }
}

/**
 * 语言列表选择弹窗
 */
@Composable
fun LanguageSelectDialog(
    title: String,
    selectedCode: String,
    languages: List<Language>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                items(languages) { lang ->
                    val isSelected = lang.code == selectedCode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoogleTranslateTheme.PrimaryBlueLight else Color.Transparent)
                            .clickable { onSelect(lang.code) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            lang.displayName,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

/**
 * 历史记录页面
 */
@Composable
fun HistoryScreen(
    preferencesManager: PreferencesManager,
    onSelectHistory: (TranslationHistoryItem) -> Unit,
    onClearAll: () -> Unit
) {
    var historyList by remember { mutableStateOf(preferencesManager.getHistory()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("翻译历史记录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
            if (historyList.isNotEmpty()) {
                TextButton(onClick = {
                    onClearAll()
                    historyList = emptyList()
                }) {
                    Text("清空历史", color = GoogleTranslateTheme.ActionRed)
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("暂无翻译历史记录", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(historyList) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
                        modifier = Modifier.fillMaxWidth().clickable { onSelectHistory(item) }
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${SupportedLanguages.getByCode(item.sourceLang).displayName} ➔ ${SupportedLanguages.getByCode(item.targetLang).displayName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleTranslateTheme.PrimaryBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.sourceText, fontSize = 14.sp, color = GoogleTranslateTheme.TextPrimary, maxLines = 2)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.translatedText, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = GoogleTranslateTheme.PrimaryBlueDark, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 设置页面
 */
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    voiceMode: VoiceMode,
    onVoiceModeChange: (VoiceMode) -> Unit,
    onSaved: () -> Unit
) {
    var apiKey by remember { mutableStateOf(preferencesManager.getApiKey()) }
    var baseUrl by remember { mutableStateOf(preferencesManager.getBaseUrl()) }
    var currentVoiceMode by remember { mutableStateOf(voiceMode) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Google 翻译设置", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)

        // 语音识别模式选择
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("语音识别引擎选择", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { currentVoiceMode = VoiceMode.SYSTEM_LOCAL }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = currentVoiceMode == VoiceMode.SYSTEM_LOCAL,
                        onClick = { currentVoiceMode = VoiceMode.SYSTEM_LOCAL }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("本地/系统原生语音组件 (Speech Services)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("调用手机系统自带 Google/小爱引擎，毫秒级本地转文字", fontSize = 12.sp, color = GoogleTranslateTheme.TextSecondary)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { currentVoiceMode = VoiceMode.CLOUD_API }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = currentVoiceMode == VoiceMode.CLOUD_API,
                        onClick = { currentVoiceMode = VoiceMode.CLOUD_API }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text("云端直连录音识别 (Gemini Audio API)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("无需手机安装任何语音组件，麦克风录音直传 API 识别", fontSize = 12.sp, color = GoogleTranslateTheme.TextSecondary)
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Gemini API Key", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "用于文字互译、语音识别及纯中文语法/词义用法解析。",
                    fontSize = 12.sp,
                    color = GoogleTranslateTheme.TextSecondary
                )
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("API 代理 Base URL", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = { Text("https://generativelanguage.googleapis.com") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }

        Button(
            onClick = {
                preferencesManager.saveApiKey(apiKey)
                preferencesManager.saveBaseUrl(baseUrl)
                onVoiceModeChange(currentVoiceMode)
                onSaved()
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("保存设置", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
