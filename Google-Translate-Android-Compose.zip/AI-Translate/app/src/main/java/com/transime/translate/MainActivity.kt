package com.transime.translate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.transime.translate.data.*
import com.transime.translate.network.GeminiTranslateEngine
import com.transime.translate.ui.GoogleIcons
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * 谷歌翻译主题配色 (Google Material You 经典设计)
 */
object GoogleTranslateTheme {
    val PageBg = Color(0xFFF8F9FA)            // 浅灰底色
    val CardBg = Color(0xFFFFFFFF)            // 纯白卡片
    val PrimaryBlue = Color(0xFF1A73E8)       // 谷歌蓝
    val PrimaryBlueDark = Color(0xFF1557B0)
    val PrimaryBlueLight = Color(0xFFE8F0FE)  // 谷歌浅蓝按键背景
    val TextPrimary = Color(0xFF202124)       // 标题文字黑
    val TextSecondary = Color(0xFF5F6368)     // 辅助灰色
    val CardBorder = Color(0xFFDADCE0)        // 浅灰边框
    val ActionRed = Color(0xFFEA4335)         // 录音中提示红
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var translateEngine: GeminiTranslateEngine
    private var textToSpeech: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesManager = PreferencesManager(applicationContext)
        translateEngine = GeminiTranslateEngine(applicationContext, preferencesManager)

        // 初始化本地 TTS 语音朗读引擎
        textToSpeech = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.CHINESE
            }
        }

        setContent {
            MaterialTheme {
                GoogleTranslateMainScreen(
                    context = this,
                    preferencesManager = preferencesManager,
                    translateEngine = translateEngine,
                    onSpeak = { text, langCode -> speakText(text, langCode) }
                )
            }
        }
    }

    private fun speakText(text: String, langCode: String) {
        if (text.isBlank()) return
        try {
            val locale = when (langCode) {
                "zh" -> Locale.CHINESE
                "en" -> Locale.ENGLISH
                "vi" -> Locale("vi", "VN")
                "ja" -> Locale.JAPANESE
                "ko" -> Locale.KOREAN
                "fr" -> Locale.FRENCH
                "es" -> Locale("es", "ES")
                "ru" -> Locale("ru", "RU")
                "de" -> Locale.GERMAN
                else -> Locale.ENGLISH
            }
            textToSpeech?.language = locale
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "UTTERANCE_ID")
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "语音朗读不可用: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleTranslateMainScreen(
    context: Context,
    preferencesManager: PreferencesManager,
    translateEngine: GeminiTranslateEngine,
    onSpeak: (String, String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(0) } // 0: 翻译主页, 1: 历史记录, 2: 设置

    var sourceLangCode by remember { mutableStateOf(preferencesManager.getSourceLang()) }
    var targetLangCode by remember { mutableStateOf(preferencesManager.getTargetLang()) }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLangCode by remember { mutableStateOf("") }
    var noteExplanation by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }

    // 录音监听状态
    var isRecording by remember { mutableStateOf(false) }

    // 相机拍照临时图片 URI
    var cameraTempUri by remember { mutableStateOf<Uri?>(null) }

    // 创建保存拍照图片的临时文件 URI
    fun createTempPictureUri(): Uri {
        val tempFile = File(context.cacheDir, "camera_trans_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(
            context,
            "com.google.android.apps.translate.fileprovider",
            tempFile
        )
    }

    // 触发翻译业务
    val performTextTranslation: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isTranslating = true
            coroutineScope.launch {
                val res = translateEngine.translateText(query, sourceLangCode, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                noteExplanation = res.explanation
                isTranslating = false

                // 保存到历史记录
                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = query,
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        }
    }

    // 拍照拍照完成回调
    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && cameraTempUri != null) {
            isTranslating = true
            inputText = "【📷 正在通过本地相机拍摄的图片提取文字...】"
            translatedText = ""
            coroutineScope.launch {
                val res = translateEngine.translateImage(cameraTempUri!!, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                noteExplanation = res.explanation
                isTranslating = false

                preferencesManager.addHistoryItem(
                    TranslationHistoryItem(
                        sourceLang = res.detectedLang,
                        targetLang = targetLangCode,
                        sourceText = "📷 拍照翻译",
                        translatedText = res.translatedText
                    )
                )
            }
        }
    }

    // 相册选取图片回调
    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isTranslating = true
            inputText = "【🖼️ 正在从相册图片中提取文字...】"
            translatedText = ""
            coroutineScope.launch {
                val res = translateEngine.translateImage(uri, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                noteExplanation = res.explanation
                isTranslating = false

                preferencesManager.addHistoryItem(
                    TranslationHistoryItem(
                        sourceLang = res.detectedLang,
                        targetLang = targetLangCode,
                        sourceText = "🖼️ 相册图片翻译",
                        translatedText = res.translatedText
                    )
                )
            }
        }
    }

    // 唤起本地原生相机拍照
    val requestCameraAndShoot: () -> Unit = {
        val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA)
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            val uri = createTempPictureUri()
            cameraTempUri = uri
            takePictureLauncher.launch(uri)
        } else {
            Toast.makeText(context, "请授予相机权限以唤起本地相机拍照", Toast.LENGTH_SHORT).show()
        }
    }

    // 单人语音识别监听器
    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(speechRecognizer) {
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    val startVoiceRecognition: () -> Unit = {
        if (speechRecognizer == null) {
            Toast.makeText(context, "当前设备不支持原生语音识别，请安装语音识别组件", Toast.LENGTH_SHORT).show()
        } else {
            val audioPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            if (audioPermission != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(context, "请先授予录音权限以进行语音输入", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (sourceLangCode == "auto" || sourceLangCode == "zh") "zh-CN" else sourceLangCode)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "请说话，正在聆听...")
                }
                speechRecognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { isRecording = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { isRecording = false }
                    override fun onError(error: Int) {
                        isRecording = false
                        Toast.makeText(context, "语音识别未检测到声音或出错 (Code: $error)", Toast.LENGTH_SHORT).show()
                    }
                    override fun onResults(results: Bundle?) {
                        isRecording = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val voiceText = matches[0]
                            inputText = voiceText
                            performTextTranslation(voiceText)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                speechRecognizer.startListening(intent)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(GoogleIcons.Translate, contentDescription = null, tint = GoogleTranslateTheme.PrimaryBlue)
                        Text("Google 翻译", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GoogleTranslateTheme.TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = { currentTab = if (currentTab == 1) 0 else 1 }) {
                        Icon(GoogleIcons.History, contentDescription = "历史", tint = if (currentTab == 1) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                    }
                    IconButton(onClick = { currentTab = if (currentTab == 2) 0 else 2 }) {
                        Icon(GoogleIcons.Settings, contentDescription = "设置", tint = if (currentTab == 2) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleTranslateTheme.CardBg)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GoogleTranslateTheme.PageBg)
        ) {
            when (currentTab) {
                0 -> {
                    // 核心翻译页面
                    TranslateHomeScreen(
                        sourceLangCode = sourceLangCode,
                        targetLangCode = targetLangCode,
                        onSourceLangChange = {
                            sourceLangCode = it
                            preferencesManager.saveSourceLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onTargetLangChange = {
                            targetLangCode = it
                            preferencesManager.saveTargetLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onSwapLanguages = {
                            if (sourceLangCode != "auto") {
                                val temp = sourceLangCode
                                sourceLangCode = targetLangCode
                                targetLangCode = temp
                                preferencesManager.saveSourceLang(sourceLangCode)
                                preferencesManager.saveTargetLang(targetLangCode)
                                if (translatedText.isNotBlank() && !translatedText.startsWith("【")) {
                                    val oldTrans = translatedText
                                    inputText = oldTrans
                                    performTextTranslation(oldTrans)
                                }
                            }
                        },
                        inputText = inputText,
                        onInputTextChange = { inputText = it },
                        translatedText = translatedText,
                        detectedLangCode = detectedLangCode,
                        noteExplanation = noteExplanation,
                        isTranslating = isTranslating,
                        isRecording = isRecording,
                        onTranslateClick = { performTextTranslation(inputText) },
                        onVoiceClick = startVoiceRecognition,
                        onCameraClick = requestCameraAndShoot,
                        onGalleryClick = { pickImageLauncher.launch("image/*") },
                        onSpeak = onSpeak,
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", text))
                            Toast.makeText(context, "已复制到剪切板", Toast.LENGTH_SHORT).show()
                        },
                        onClear = {
                            inputText = ""
                            translatedText = ""
                            detectedLangCode = ""
                            noteExplanation = ""
                        }
                    )
                }
                1 -> {
                    // 历史记录页面
                    HistoryScreen(
                        preferencesManager = preferencesManager,
                        onSelectHistory = { item ->
                            sourceLangCode = item.sourceLang
                            targetLangCode = item.targetLang
                            inputText = item.sourceText
                            translatedText = item.translatedText
                            currentTab = 0
                        },
                        onClearAll = {
                            preferencesManager.saveHistory(emptyList())
                        }
                    )
                }
                2 -> {
                    // API 设置页面
                    SettingsScreen(
                        preferencesManager = preferencesManager,
                        onSaved = {
                            currentTab = 0
                            Toast.makeText(context, "配置已保存", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

/**
 * 翻译主页 (语言栏 + 拍照/语音大按钮 + 双栏卡片)
 */
@Composable
fun TranslateHomeScreen(
    sourceLangCode: String,
    targetLangCode: String,
    onSourceLangChange: (String) -> Unit,
    onTargetLangChange: (String) -> Unit,
    onSwapLanguages: () -> Unit,
    inputText: String,
    onInputTextChange: (String) -> Unit,
    translatedText: String,
    detectedLangCode: String,
    noteExplanation: String,
    isTranslating: Boolean,
    isRecording: Boolean,
    onTranslateClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onCameraClick: () -> Unit,
    onGalleryClick: () -> Unit,
    onSpeak: (String, String) -> Unit,
    onCopy: (String) -> Unit,
    onClear: () -> Unit
) {
    var showSourceLangDialog by remember { mutableStateOf(false) }
    var showTargetLangDialog by remember { mutableStateOf(false) }

    val sourceLang = SupportedLanguages.getByCode(sourceLangCode)
    val targetLang = SupportedLanguages.getByCode(targetLangCode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. 语言切换药丸条 (Google Material 胶囊 Bar)
        Card(
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // 源语言选择
                TextButton(onClick = { showSourceLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${sourceLang.flag} ${sourceLang.displayName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }

                // 对调语言
                IconButton(onClick = onSwapLanguages, enabled = sourceLangCode != "auto") {
                    Icon(GoogleIcons.SwapHoriz, contentDescription = "对调语种", tint = if (sourceLangCode != "auto") GoogleTranslateTheme.PrimaryBlue else Color.LightGray)
                }

                // 目标语言选择
                TextButton(onClick = { showTargetLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${targetLang.flag} ${targetLang.displayName}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }
            }
        }

        // 2. 原文输入卡片
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (detectedLangCode.isNotBlank() && sourceLangCode == "auto") "检测到: ${SupportedLanguages.getByCode(detectedLangCode).displayName}" else sourceLang.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GoogleTranslateTheme.TextSecondary
                    )
                    if (inputText.isNotBlank()) {
                        Text(
                            text = "清空",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoogleTranslateTheme.ActionRed,
                            modifier = Modifier.clickable { onClear() }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = { Text("在此输入文字，或使用下方语音/本地相机...", color = Color.Gray, fontSize = 15.sp) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp, max = 220.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    )
                )

                // 翻译触发按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inputText.isNotBlank()) {
                        IconButton(onClick = { onSpeak(inputText, if (detectedLangCode.isNotBlank()) detectedLangCode else sourceLangCode) }) {
                            Icon(GoogleIcons.VolumeUp, contentDescription = "朗读", tint = GoogleTranslateTheme.TextSecondary)
                        }
                    }
                    Button(
                        onClick = onTranslateClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                        shape = RoundedCornerShape(20.dp),
                        enabled = !isTranslating && inputText.isNotBlank()
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("立即翻译", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 3. 核心功能快捷入口：单人语音 + 唤起本地相机拍照 + 相册选图
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 单人语音输入按钮
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = if (isRecording) GoogleTranslateTheme.ActionRed.copy(alpha = 0.1f) else GoogleTranslateTheme.PrimaryBlueLight),
                modifier = Modifier.weight(1f).height(68.dp).clickable { onVoiceClick() }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        GoogleIcons.Mic,
                        contentDescription = "语音输入",
                        tint = if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        if (isRecording) "正在聆听..." else "语音输入",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlueDark
                    )
                }
            }

            // 本地相机拍照翻译按钮
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlueLight),
                modifier = Modifier.weight(1f).height(68.dp).clickable { onCameraClick() }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(GoogleIcons.Camera, contentDescription = "相机拍照", tint = GoogleTranslateTheme.PrimaryBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("相机拍照", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = GoogleTranslateTheme.PrimaryBlueDark)
                }
            }

            // 相册选图翻译按钮
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlueLight),
                modifier = Modifier.weight(1f).height(68.dp).clickable { onGalleryClick() }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(GoogleIcons.PhotoLibrary, contentDescription = "相册导入", tint = GoogleTranslateTheme.PrimaryBlue, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("相册选图", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = GoogleTranslateTheme.PrimaryBlueDark)
                }
            }
        }

        // 4. 译文展示卡片 (Google 原生蓝底卡片)
        if (translatedText.isNotBlank() || isTranslating) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = targetLang.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Row {
                            IconButton(onClick = { onSpeak(translatedText, targetLangCode) }) {
                                Icon(GoogleIcons.VolumeUp, contentDescription = "朗读", tint = Color.White)
                            }
                            IconButton(onClick = { onCopy(translatedText) }) {
                                Icon(GoogleIcons.ContentCopy, contentDescription = "复制", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isTranslating) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            Text("Gemini 正在进行地道翻译...", color = Color.White, fontSize = 15.sp)
                        }
                    } else {
                        Text(
                            text = translatedText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            lineHeight = 24.sp
                        )
                    }

                    if (noteExplanation.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "💡 提示: $noteExplanation",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }
    }

    // 源语言选择对话框
    if (showSourceLangDialog) {
        LanguageSelectDialog(
            title = "选择源语言",
            selectedCode = sourceLangCode,
            languages = SupportedLanguages.ALL,
            onSelect = {
                onSourceLangChange(it)
                showSourceLangDialog = false
            },
            onDismiss = { showSourceLangDialog = false }
        )
    }

    // 目标语言选择对话框 (不包含“自动检测”)
    if (showTargetLangDialog) {
        LanguageSelectDialog(
            title = "选择翻译目标语言",
            selectedCode = targetLangCode,
            languages = SupportedLanguages.ALL.filter { it.code != "auto" },
            onSelect = {
                onTargetLangChange(it)
                showTargetLangDialog = false
            },
            onDismiss = { showTargetLangDialog = false }
        )
    }
}

/**
 * 语言列表选择弹窗
 */
@Composable
fun LanguageSelectDialog(
    title: String,
    selectedCode: String,
    languages: List<Language>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                items(languages) { lang ->
                    val isSelected = lang.code == selectedCode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoogleTranslateTheme.PrimaryBlueLight else Color.Transparent)
                            .clickable { onSelect(lang.code) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            lang.displayName,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

/**
 * 历史记录页面
 */
@Composable
fun HistoryScreen(
    preferencesManager: PreferencesManager,
    onSelectHistory: (TranslationHistoryItem) -> Unit,
    onClearAll: () -> Unit
) {
    var historyList by remember { mutableStateOf(preferencesManager.getHistory()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("翻译历史记录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
            if (historyList.isNotEmpty()) {
                TextButton(onClick = {
                    onClearAll()
                    historyList = emptyList()
                }) {
                    Text("清空历史", color = GoogleTranslateTheme.ActionRed)
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("暂无翻译历史记录", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(historyList) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
                        modifier = Modifier.fillMaxWidth().clickable { onSelectHistory(item) }
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${SupportedLanguages.getByCode(item.sourceLang).displayName} ➔ ${SupportedLanguages.getByCode(item.targetLang).displayName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleTranslateTheme.PrimaryBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.sourceText, fontSize = 14.sp, color = GoogleTranslateTheme.TextPrimary, maxLines = 2)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.translatedText, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = GoogleTranslateTheme.PrimaryBlueDark, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 设置页面 (配置 API Key 与中转地址)
 */
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    onSaved: () -> Unit
) {
    var apiKey by remember { mutableStateOf(preferencesManager.getApiKey()) }
    var baseUrl by remember { mutableStateOf(preferencesManager.getBaseUrl()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Google 翻译引擎设置", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Gemini API Key", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "支持 Google AI Studio 免费申请的 Gemini API Key，自动启用超快速的 gemini-3.5-flash-lite 文本互译与视觉拍照 OCR 翻译能力。",
                    fontSize = 12.sp,
                    color = GoogleTranslateTheme.TextSecondary
                )
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("API 代理 Base URL", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = { Text("https://generativelanguage.googleapis.com") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "默认官方直连；国内网络可填入中转反代域名或自定义 Gateway。",
                    fontSize = 12.sp,
                    color = GoogleTranslateTheme.TextSecondary
                )
            }
        }

        Button(
            onClick = {
                preferencesManager.saveApiKey(apiKey)
                preferencesManager.saveBaseUrl(baseUrl)
                onSaved()
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("保存设置", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
