package com.transime.translate.network

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.transime.translate.data.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

data class TranslationResult(
    val detectedLang: String,
    val targetLang: String,
    val translatedText: String,
    val explanation: String = ""
)

/**
 * 谷歌翻译核心引擎：调用 Google Gemini REST API (Flash 极速文本 + 多模态 Vision 视觉)
 */
class GeminiTranslateEngine(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return preferencesManager.getApiKey()
    }

    private fun getBaseUrl(): String {
        return preferencesManager.getBaseUrl()
    }

    /**
     * 1. 纯文本 / 语音转文字后翻译
     */
    suspend fun translateText(
        text: String,
        sourceLang: String,
        targetLang: String
    ): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                explanation = "未检测到 API Key"
            )
        }

        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val prompt = """
            You are a professional neural machine translation engine identical to Google Translate.
            Translate the following text:
            Source language: $sourceLang (if 'auto', detect language automatically)
            Target language: $targetLang
            Input text: "$text"

            Rules:
            1. Output fluent, idiomatic, culturally natural translation.
            2. Return STRICT JSON with this schema:
            {
               "detectedLang": "ISO code of detected source language (e.g. zh, en, vi, ja)",
               "targetLang": "$targetLang",
               "translatedText": "the pure translated text",
               "explanation": "brief pronunciation or nuance notes if any"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    return@withContext TranslationResult(
                        detectedLang = sourceLang,
                        targetLang = targetLang,
                        translatedText = "翻译接口请求失败 (HTTP ${response.code})",
                        explanation = errorBody.take(150)
                    )
                }

                val responseBody = response.body?.string() ?: ""
                val root = JSONObject(responseBody)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                TranslationResult(
                    detectedLang = parsed.optString("detectedLang", sourceLang),
                    targetLang = parsed.optString("targetLang", targetLang),
                    translatedText = parsed.optString("translatedText", text),
                    explanation = parsed.optString("explanation", "")
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "网络错误: ${e.localizedMessage ?: "连接超时"}",
                explanation = "请检查网络连接或 API Key 设置"
            )
        }
    }

    /**
     * 2. 本地相机拍照 / 相册图片 Gemini Vision 视觉识别翻译
     */
    suspend fun translateImage(
        imageUri: Uri,
        targetLang: String
    ): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext TranslationResult(
                detectedLang = "auto",
                targetLang = targetLang,
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                explanation = "未检测到 API Key"
            )
        }

        val base64Data = compressAndEncodeImage(imageUri) ?: return@withContext TranslationResult(
            detectedLang = "auto",
            targetLang = targetLang,
            translatedText = "读取或解析拍照图片失败，请重试",
            explanation = ""
        )

        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val systemPrompt = """
            You are Google Translate Camera Translation Engine (Gemini Vision OCR & Translation).
            Task:
            1. Extract all visible text from the provided image accurately (OCR).
            2. Translate the extracted text into target language: $targetLang.
            3. Maintain paragraph layout and context (signs, menus, documents, labels).
            4. Output STRICT JSON:
            {
               "detectedLang": "ISO code of detected source language in the photo (e.g. en, zh, vi)",
               "targetLang": "$targetLang",
               "originalOcrText": "full recognized original text",
               "translatedText": "full translated text formatted with clear readable linebreaks",
               "explanation": "brief overview of photo context (e.g. 包装说明 / 餐厅菜单 / 合同段落 / 街道路牌)"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemPrompt))
                    put(JSONObject().put("inlineData", JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    }))
                })
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: ""
                    return@withContext TranslationResult(
                        detectedLang = "auto",
                        targetLang = targetLang,
                        translatedText = "拍照识别翻译失败 (HTTP ${response.code})",
                        explanation = err.take(150)
                    )
                }

                val body = response.body?.string() ?: ""
                val root = JSONObject(body)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                val ocr = parsed.optString("originalOcrText", "")
                val trans = parsed.optString("translatedText", "")
                val exp = parsed.optString("explanation", "")

                val displayContent = if (ocr.isNotBlank()) {
                    "【图片提取原文】:\n$ocr\n\n【译文】:\n$trans"
                } else {
                    trans
                }

                TranslationResult(
                    detectedLang = parsed.optString("detectedLang", "auto"),
                    targetLang = targetLang,
                    translatedText = displayContent,
                    explanation = exp
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            TranslationResult(
                detectedLang = "auto",
                targetLang = targetLang,
                translatedText = "图片传输或识别异常: ${e.localizedMessage ?: "网络超时"}",
                explanation = "建议拍清文字或检查 API Key"
            )
        }
    }

    /**
     * 智能压缩图片 (避免超过 API 体积限制，保持 1280 像素并压缩至 JPEG 80% 质量)
     */
    private fun compressAndEncodeImage(uri: Uri): String? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) return null

            val maxDimension = 1280
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scale = if (width > maxDimension || height > maxDimension) {
                val ratio = maxDimension.toFloat() / maxOf(width, height)
                ratio
            } else 1f

            val scaledBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    originalBitmap,
                    (width * scale).toInt(),
                    (height * scale).toInt(),
                    true
                )
            } else originalBitmap

            val outStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outStream)
            val bytes = outStream.toByteArray()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
