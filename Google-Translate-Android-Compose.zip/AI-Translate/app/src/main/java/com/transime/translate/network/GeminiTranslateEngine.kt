package com.transime.translate.network

import android.content.Context
import android.util.Base64
import com.transime.translate.data.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class TranslationResult(
    val detectedLang: String,
    val targetLang: String,
    val translatedText: String,
    val explanation: String = "" // 纯中文语境与词义用法解释
)

data class AudioRecognitionResult(
    val recognizedText: String,
    val translatedText: String,
    val detectedLang: String,
    val explanation: String = ""
)

/**
 * 谷歌翻译核心引擎：调用 Google Gemini REST API (Flash 极速文本翻译 + 纯中文语境词义解析 + 多模态语音识别)
 */
class GeminiTranslateEngine(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return preferencesManager.getApiKey()
    }

    private fun getBaseUrl(): String {
        return preferencesManager.getBaseUrl()
    }

    /**
     * 1. 纯文本翻译与地道中文语法/词义提示
     */
    suspend fun translateText(
        text: String,
        sourceLang: String,
        targetLang: String
    ): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                explanation = "请先配置 API Key 即可开启智能互译"
            )
        }

        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val prompt = """
            你是一个专业地道的多语言神经机器翻译引擎（功能类似 Google 翻译）。
            任务：
            1. 源语言: $sourceLang (若为 'auto' 请自动识别语种)
            2. 目标语言: $targetLang
            3. 待翻译内容: "$text"
            
            重要规则：
            - translatedText 字段必须输出地道、流畅、现代自然的目标语言译文；
            - explanation 字段必须全部使用【纯中文】进行简要注释：包括发音技巧、词汇用法、语法亮点或跨文化语境差异（控制在 30-80 字左右，清晰易懂，不要输出英文说明）。
            
            返回严格的 JSON 格式：
            {
               "detectedLang": "识别出的源语言代码(如 zh, en, vi, ja)",
               "targetLang": "$targetLang",
               "translatedText": "纯净的地道译文",
               "explanation": "简短易懂的纯中文用法说明与词义语法解析"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    return@withContext TranslationResult(
                        detectedLang = sourceLang,
                        targetLang = targetLang,
                        translatedText = "翻译接口请求失败 (HTTP ${response.code})",
                        explanation = "接口返回错误，请检查网络或 API Key 状态"
                    )
                }

                val responseBody = response.body?.string() ?: ""
                val root = JSONObject(responseBody)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                TranslationResult(
                    detectedLang = parsed.optString("detectedLang", sourceLang),
                    targetLang = parsed.optString("targetLang", targetLang),
                    translatedText = parsed.optString("translatedText", text),
                    explanation = parsed.optString("explanation", "")
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "网络错误: ${e.localizedMessage ?: "连接超时"}",
                explanation = "连接失败，请检查手机网络设置或代理 Base URL"
            )
        }
    }

    /**
     * 2. 本地录音文件直传云端识别与地道翻译（支持纯中文说明）
     */
    suspend fun recognizeAndTranslateAudio(
        audioFile: File,
        targetLang: String
    ): AudioRecognitionResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext AudioRecognitionResult(
                recognizedText = "",
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                detectedLang = "auto",
                explanation = "请先配置 API Key"
            )
        }

        val bytes = try {
            audioFile.readBytes()
        } catch (e: Exception) {
            return@withContext AudioRecognitionResult("", "读取录音数据失败: ${e.message}", "auto", "")
        }

        val base64Audio = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val prompt = """
            你是一个专业的高精度语音识别与双语互译引擎。
            请聆听用户的音频内容：
            1. 精确将语音转写为文字 (recognizedText)；
            2. 自动检测说话语种 (detectedLang)；
            3. 将转写内容翻译为目标语言: $targetLang (translatedText)；
            4. explanation 字段请使用【纯中文】给出简短口语语境或表达贴士。
            
            输出严格 JSON 格式：
            {
              "recognizedText": "识别出的完整语音文字",
              "detectedLang": "源语种代号 (如 zh, en, vi)",
              "translatedText": "在目标语种中的自然流畅译文",
              "explanation": "纯中文口语用法或文化背景说明"
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().apply {
                    put(JSONObject().put("text", prompt))
                    put(JSONObject().put("inlineData", JSONObject().apply {
                        put("mimeType", "audio/mp4")
                        put("data", base64Audio)
                    }))
                })
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: ""
                    return@withContext AudioRecognitionResult("", "云端语音识别失败 (HTTP ${response.code})", "auto", "")
                }

                val body = response.body?.string() ?: ""
                val root = JSONObject(body)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                AudioRecognitionResult(
                    recognizedText = parsed.optString("recognizedText", ""),
                    translatedText = parsed.optString("translatedText", ""),
                    detectedLang = parsed.optString("detectedLang", "auto"),
                    explanation = parsed.optString("explanation", "")
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            AudioRecognitionResult("", "语音通信异常: ${e.localizedMessage ?: "连接超时"}", "auto", "")
        }
    }
}
