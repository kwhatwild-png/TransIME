rootProject.name = "GoogleTranslate"
include(":app")
