# Google 翻译 App (Android 原生 + Gemini 极速/视觉 API)

基于 **Kotlin + Jetpack Compose** 构建的独立翻译应用，包名设定为 `com.google.android.apps.translate`，1:1 复刻 Google 翻译经典原生界面与交互。

---

## 🌟 核心功能特色

1. **文字互译 (即打即译 + 语种自适应)**
   - 顶部 Material You 双向语言切换药丸条（支持中文、英语、越南语、日语、韩语、法语、德语、俄语、西班牙语等主流语种）。
   - 自动检测输入语言，一键语言对调。
   - 纯正 Google 经典蓝底译文卡片，附带地道语境提示。

2. **🎙 单人语音输入翻译 (Voice Recognition)**
   - 集成 Android 原生 `SpeechRecognizer` 语音识别服务。
   - 点击“语音输入”，边说边实时识别为文字，说完自动调用 API 翻译为目标语言。

3. **📷 唤起本地原生相机拍照翻译 (Camera OCR & Vision Translation)**
   - 点击“相机拍照”，通过系统 `FileProvider` **直接唤起手机自带的原生相机（小米/华为/OPPO/vivo 等手机相机）**。
   - 拍好照片确认后，系统自动原图返回，App 智能压缩后传递给 **Gemini 多模态视觉 API**。
   - 自动提取图片中所有的文字、包装说明、招牌路标或合同段落，并精准翻译。
   - 同时支持“相册选图”直接翻译已有的图片或截图。

4. **🔊 语音朗读 (TTS) 与一键复制**
   - 原文与译文均配有一键朗读按钮，调用本地 `TextToSpeech` 引擎进行发音。
   - 译文卡片支持一键复制到系统剪切板。

5. **🕒 历史记录与持久化**
   - 自动保存最近 100 条翻译记录，随时回查与一键带入。

6. **⚙️ 自定义 API 引擎**
   - 自由填入用户自己的 Gemini API Key。
   - 支持配置代理 Base URL，方便国内网络免翻墙直连。

---

## 🚀 如何打包生成 APK

工程根目录下已配置好标准的 Gradle 构建体系，支持以下方式一键编译：

### 方式一：Android Studio 一键打包 (耗时约 30 秒)
1. 打开 [Android Studio](https://developer.android.com/studio)；
2. 选择 `Open` 打开本工程目录 `D:\Antigravity\AI-Translate`；
3. 点击顶部菜单栏：`Build` -> `Build Bundle(s) / APK(s)` -> **`Build APK(s)`**；
4. 编译完成后点击右下角的 **`locate`** 即可获取生成的 `app-debug.apk` 发送到手机安装。

### 方式二：命令行编译
在工程根目录下执行：
```cmd
gradlew.bat assembleDebug
```
编译生成的安装包位于：`app/build/outputs/apk/debug/app-debug.apk`。

### 方式三：GitHub Actions 云端自动构建 (无需本地配置环境)
工程自带 `.github/workflows/build-apk.yml`，上传到 GitHub 仓库即可在 Actions 页面直接下载打包好的 APK。
