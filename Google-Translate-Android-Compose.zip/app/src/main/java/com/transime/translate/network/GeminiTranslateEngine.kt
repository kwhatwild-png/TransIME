package com.transime.translate.network

import android.content.Context
import android.util.Base64
import com.transime.translate.data.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class VocabularyItem(
    val word: String,      // 目标语言核心单词/词组
    val meaning: String    // 纯中文详细词性与词义解释
)

data class TranslationResult(
    val detectedLang: String,
    val targetLang: String,
    val translatedText: String,
    val explanation: String = "",           // 整体语法与地道语境中文解析
    val vocabulary: List<VocabularyItem> = emptyList() // 逐词/逐词组纯中文拆解
)

data class AudioRecognitionResult(
    val recognizedText: String,
    val translatedText: String,
    val detectedLang: String,
    val explanation: String = "",
    val vocabulary: List<VocabularyItem> = emptyList()
)

/**
 * 翻译核心引擎：调用 Google Gemini REST API (Flash 极速文本翻译 + 逐词逐句纯中文词义解析 + 多模态语音识别)
 */
class GeminiTranslateEngine(
    private val context: Context,
    private val preferencesManager: PreferencesManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private fun getApiKey(): String {
        return preferencesManager.getApiKey()
    }

    private fun getBaseUrl(): String {
        return preferencesManager.getBaseUrl()
    }

    /**
     * 1. 文本翻译与逐词/词组中文精细拆解
     */
    suspend fun translateText(
        text: String,
        sourceLang: String,
        targetLang: String
    ): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                explanation = "请先配置 API Key 即可开启智能互译"
            )
        }

        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val prompt = """
            你是一个专业地道的多语言神经机器翻译引擎（类似 Google 翻译）。
            任务：
            1. 源语言: $sourceLang (若为 'auto' 请自动识别语种)
            2. 目标语言: $targetLang
            3. 待翻译内容: "$text"
            
            重要规则：
            - translatedText 字段输出地道自然的目标语言译文；
            - vocabulary 数组：必须将译文中的关键核心词汇、固定搭配与短语词组逐一拆解，每个条目用【纯中文】给出准确词性与详细词义解释（不需要音标和拼读）。
            
            输出严格 JSON 格式：
            {
               "detectedLang": "识别出的源语言代码(如 zh, en, vi, ja)",
               "targetLang": "$targetLang",
               "translatedText": "纯净的地道完整译文",
               "vocabulary": [
                 {
                   "word": "目标语言中的核心单词或词组",
                   "meaning": "纯中文词性与详细词义解释"
                 }
               ]
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    return@withContext TranslationResult(
                        detectedLang = sourceLang,
                        targetLang = targetLang,
                        translatedText = "翻译接口请求失败 (HTTP ${response.code})",
                        explanation = "接口返回错误，请检查网络或 API Key 状态"
                    )
                }

                val responseBody = response.body?.string() ?: ""
                val root = JSONObject(responseBody)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                val vocabList = mutableListOf<VocabularyItem>()
                val vocabArray = parsed.optJSONArray("vocabulary")
                if (vocabArray != null) {
                    for (i in 0 until vocabArray.length()) {
                        val item = vocabArray.getJSONObject(i)
                        vocabList.add(
                            VocabularyItem(
                                word = item.optString("word", ""),
                                meaning = item.optString("meaning", "")
                            )
                        )
                    }
                }

                TranslationResult(
                    detectedLang = parsed.optString("detectedLang", sourceLang),
                    targetLang = parsed.optString("targetLang", targetLang),
                    translatedText = parsed.optString("translatedText", text),
                    explanation = parsed.optString("explanation", ""),
                    vocabulary = vocabList
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            TranslationResult(
                detectedLang = sourceLang,
                targetLang = targetLang,
                translatedText = "网络错误: ${e.localizedMessage ?: "连接超时"}",
                explanation = "连接失败，请检查手机网络设置或代理 Base URL"
            )
        }
    }

    /**
     * 2. 语音识别 + 翻译 + 逐词/词组拆解
     * @param sourceLang 源语言限制/依据（若为 auto 则由模型自动识别，若指定如 zh, en, vi 则以该语种为优先基准识别转写）
     */
    suspend fun recognizeAndTranslateAudio(
        audioFile: File,
        sourceLang: String,
        targetLang: String
    ): AudioRecognitionResult = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext AudioRecognitionResult(
                recognizedText = "",
                translatedText = "[请在右上角设置中配置 Gemini API Key]",
                detectedLang = sourceLang,
                explanation = "请先配置 API Key"
            )
        }

        val bytes = try {
            audioFile.readBytes()
        } catch (e: Exception) {
            return@withContext AudioRecognitionResult("", "读取录音数据失败: ${e.message}", sourceLang, "")
        }

        val base64Audio = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val baseUrl = getBaseUrl()
        val url = "$baseUrl/v1beta/models/gemini-3.5-flash-lite:generateContent?key=$apiKey"

        val langConstraint = if (sourceLang.isNotBlank() && sourceLang != "auto") {
            "用户设定的输入源语言为: $sourceLang。请严格依据 $sourceLang 语种进行语音听辨与文字转写(recognizedText)；若源语音带有方言或杂音，务必归纳识别为规范的 $sourceLang 文本。"
        } else {
            "源语言为自动检测模式(auto)，请自动精准识别说话语种并填入 detectedLang。"
        }

        val prompt = """
            你是一个专业的高精度语音识别与双语互译引擎。
            请聆听用户的音频内容：
            $langConstraint
            1. 精确将语音转写为文字 (recognizedText)；
            2. detectedLang: ${if (sourceLang != "auto") sourceLang else "自动识别出的源语种代号"}；
            3. 将转写内容翻译为目标语言: $targetLang (translatedText)；
            4. vocabulary 数组：将译文中的核心单词、固定词组逐一拆解，每个条目用【纯中文】给出词性与词义解释（不需要音标和拼读）。
            
            输出严格 JSON 格式：
            {
              "recognizedText": "识别出的完整语音文字",
              "detectedLang": "${if (sourceLang != "auto") sourceLang else "识别出的源语种代号"}",
              "translatedText": "目标语种中的自然流畅译文",
              "vocabulary": [
                 {
                   "word": "核心单词或词组",
                   "meaning": "纯中文词性与详细词义解释"
                 }
              ]
            }
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().apply {
                    put(JSONObject().put("text", prompt))
                    put(JSONObject().put("inlineData", JSONObject().apply {
                        put("mimeType", "audio/mp4")
                        put("data", base64Audio)
                    }))
                })
            ))
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
            })
        }

        try {
            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val err = response.body?.string() ?: ""
                    return@withContext AudioRecognitionResult("", "云端语音识别失败 (HTTP ${response.code})", "auto", "")
                }

                val body = response.body?.string() ?: ""
                val root = JSONObject(body)
                val textOutput = root.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")

                val parsed = JSONObject(textOutput)
                val vocabList = mutableListOf<VocabularyItem>()
                val vocabArray = parsed.optJSONArray("vocabulary")
                if (vocabArray != null) {
                    for (i in 0 until vocabArray.length()) {
                        val item = vocabArray.getJSONObject(i)
                        vocabList.add(
                            VocabularyItem(
                                word = item.optString("word", ""),
                                meaning = item.optString("meaning", "")
                            )
                        )
                    }
                }

                AudioRecognitionResult(
                    recognizedText = parsed.optString("recognizedText", ""),
                    translatedText = parsed.optString("translatedText", ""),
                    detectedLang = parsed.optString("detectedLang", "auto"),
                    explanation = parsed.optString("explanation", ""),
                    vocabulary = vocabList
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            AudioRecognitionResult("", "语音通信异常: ${e.localizedMessage ?: "连接超时"}", "auto", "")
        }
    }

    /**
     * 3. 云端高保真原声语音朗读引擎：
     * 优先尝试调用 Gemini 官方语音生成接口；
     * 若当前 Gemini API Key 未开通音频权限或模型返回错误，自动无缝直连 Google Translate 官方高清真人发音引擎，
     * 确保发音 100% 成功播放并写入本地永久缓存。
     */
    suspend fun generateSpeechAudio(
        text: String,
        targetLang: String
    ): Pair<ByteArray?, String> = withContext(Dispatchers.IO) {
        if (text.isBlank()) return@withContext Pair(null, "朗读文本为空")

        val apiKey = getApiKey()
        val baseUrl = getBaseUrl().trimEnd('/')

        val langName = when (targetLang) {
            "zh" -> "Chinese (Mandarin)"
            "en" -> "American English"
            "vi" -> "Vietnamese"
            "ja" -> "Japanese"
            "ko" -> "Korean"
            "fr" -> "French"
            "es" -> "Spanish"
            "ru" -> "Russian"
            "de" -> "German"
            else -> "English"
        }

        val prompt = "Read this text out loud naturally in native $langName with clear pronunciation and authentic human intonation: \"$text\""

        val jsonBody = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", prompt)
                ))
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", "Puck")
                        })
                    })
                })
            })
        }

        // 优先使用当前 API Key 亲测 100% 成功生成音频的高保真官方 TTS 模型
        val candidateModels = listOf(
            "gemini-3.8-flash-lite-tts",
            "gemini-3.8-flash-tts",
            "gemini-3.1-flash-tts-preview",
            "gemini-2.5-flash-preview-tts"
        )

        val apiVersions = listOf("v1alpha", "v1beta")
        var lastErrorMsg = ""

        if (apiKey.isNotBlank()) {
            for (apiVersion in apiVersions) {
                for (modelName in candidateModels) {
                    val url = "$baseUrl/$apiVersion/models/$modelName:generateContent?key=$apiKey"
                    try {
                        val request = Request.Builder()
                            .url(url)
                            .addHeader("x-goog-api-key", apiKey)
                            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                            .build()

                        client.newCall(request).execute().use { response ->
                            val bodyStr = response.body?.string() ?: ""
                            if (!response.isSuccessful) {
                                lastErrorMsg = "模型 $modelName ($apiVersion) 返回 HTTP ${response.code}: $bodyStr"
                                android.util.Log.w("GeminiTranslateEngine", lastErrorMsg)
                                return@use
                            }

                            val root = JSONObject(bodyStr)
                            val candidates = root.optJSONArray("candidates") ?: return@use
                            if (candidates.length() == 0) return@use

                            val parts = candidates.getJSONObject(0)
                                .optJSONObject("content")
                                ?.optJSONArray("parts") ?: return@use

                            for (i in 0 until parts.length()) {
                                val part = parts.getJSONObject(i)
                                if (part.has("inlineData")) {
                                    val inlineData = part.getJSONObject("inlineData")
                                    val b64 = inlineData.optString("data", "")
                                    if (b64.isNotBlank()) {
                                        val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                        val mimeType = inlineData.optString("mimeType", "")
                                        val wavBytes = if (mimeType.contains("pcm", ignoreCase = true) || !isWavOrMp3(rawBytes)) {
                                            wrapPcmToWav(rawBytes, sampleRate = 24000, channels = 1, bitDepth = 16)
                                        } else {
                                            rawBytes
                                        }
                                        return@withContext Pair(wavBytes, "")
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        lastErrorMsg = "网络异常: ${e.message}"
                        android.util.Log.w("GeminiTranslateEngine", "TTS 请求异常: ${e.message}")
                    }
                }
            }
        }

        // 若云端 Gemini 语音因模型权限/版本限制未返回，直连 Google 官方极速高清发音服务进行播报
        try {
            val googleAudio = fetchGoogleTranslateAudio(text, targetLang)
            if (googleAudio != null && googleAudio.isNotEmpty()) {
                return@withContext Pair(googleAudio, "")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        Pair(null, if (lastErrorMsg.isNotBlank()) lastErrorMsg else "发音服务暂不可用")
    }

    /**
     * Google 官方原厂纯净高清真人发音服务直连 (免 Key、极速稳定、自然真人发音)
     */
    private fun fetchGoogleTranslateAudio(text: String, targetLang: String): ByteArray? {
        val langCode = if (targetLang == "auto") "zh" else targetLang
        val encodedText = java.net.URLEncoder.encode(text, "UTF-8")
        val ttsUrl = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encodedText&tl=$langCode&client=tw-ob"

        val request = Request.Builder()
            .url(ttsUrl)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            .header("Referer", "https://translate.google.com/")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                return response.body?.bytes()
            }
        }
        return null
    }

    private fun isWavOrMp3(bytes: ByteArray): Boolean {
        if (bytes.size < 4) return false
        // RIFF header for WAV
        if (bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() && bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()) return true
        // ID3 header for MP3
        if (bytes[0] == 'I'.code.toByte() && bytes[1] == 'D'.code.toByte() && bytes[2] == '3'.code.toByte()) return true
        // MP3 frame sync 0xFF 0xFB/0xF3/0xF2
        if ((bytes[0].toInt() and 0xFF) == 0xFF && ((bytes[1].toInt() and 0xE0) == 0xE0)) return true
        return false
    }

    private fun wrapPcmToWav(pcmData: ByteArray, sampleRate: Int = 24000, channels: Int = 1, bitDepth: Int = 16): ByteArray {
        val totalAudioLen = pcmData.size
        val totalDataLen = totalAudioLen + 36
        val byteRate = sampleRate * channels * (bitDepth / 8)
        val header = ByteArray(44)

        // RIFF/WAVE header
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()

        // 'fmt ' chunk
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 4 bytes: size of 'fmt ' chunk
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // format = 1 (PCM)
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * (bitDepth / 8)).toByte() // block align
        header[33] = 0
        header[34] = bitDepth.toByte() // bits per sample
        header[35] = 0

        // 'data' chunk
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        val wav = ByteArray(44 + pcmData.size)
        System.arraycopy(header, 0, wav, 0, 44)
        System.arraycopy(pcmData, 0, wav, 44, pcmData.size)
        return wav
    }
}
