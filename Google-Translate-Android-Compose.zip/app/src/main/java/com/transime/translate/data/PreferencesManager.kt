package com.transime.translate.data

import android.content.Context
import android.content.SharedPreferences

data class Language(
    val code: String,
    val displayName: String,
    val flag: String,
    val ttsLocale: String = "en"
)

object SupportedLanguages {
    val ALL = listOf(
        Language("auto", "自动检测", "🌐", "zh"),
        Language("zh", "中文", "🇨🇳", "zh"),
        Language("en", "英语", "🇺🇸", "en"),
        Language("vi", "越南语", "🇻🇳", "vi"),
        Language("ja", "日语", "🇯🇵", "ja"),
        Language("ko", "韩语", "🇰🇷", "ko"),
        Language("fr", "法语", "🇫🇷", "fr"),
        Language("es", "西班牙语", "🇪🇸", "es"),
        Language("ru", "俄语", "🇷🇺", "ru"),
        Language("de", "德语", "🇩🇪", "de"),
        Language("th", "泰语", "🇹🇭", "th")
    )

    fun getByCode(code: String): Language {
        return ALL.firstOrNull { it.code.equals(code, ignoreCase = true) }
            ?: Language(code, code, "🌐", "en")
    }
}

data class TranslationHistoryItem(
    val id: Long = System.currentTimeMillis(),
    val sourceLang: String,
    val targetLang: String,
    val sourceText: String,
    val translatedText: String,
    val timestamp: Long = System.currentTimeMillis(),
    var isFavorite: Boolean = false,
    val sourceAudioPath: String = "", // 永久保存的原文整句发音音频
    val targetAudioPath: String = ""  // 永久保存的译文整句发音音频
)

enum class VoiceMode {
    SYSTEM_LOCAL, // 本地/系统原生语音引擎 (SpeechRecognizer)
    CLOUD_API     // 纯云端 API 直连录音识别 (Gemini Audio)
}

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("google_translate_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_BASE_URL = "custom_gemini_base_url"
        private const val KEY_SOURCE_LANG = "last_source_lang"
        private const val KEY_TARGET_LANG = "last_target_lang"
        private const val KEY_HISTORY_JSON = "translation_history_json"
        private const val KEY_VOICE_MODE = "preferred_voice_mode"
    }

    fun getApiKey(): String = prefs.getString(KEY_API_KEY, "") ?: ""
    fun saveApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key.trim()).apply()

    fun getBaseUrl(): String {
        val url = prefs.getString(KEY_BASE_URL, "") ?: ""
        return if (url.isBlank()) "https://generativelanguage.googleapis.com" else url.trim().removeSuffix("/")
    }
    fun saveBaseUrl(url: String) = prefs.edit().putString(KEY_BASE_URL, url.trim().removeSuffix("/")).apply()

    fun getSourceLang(): String = prefs.getString(KEY_SOURCE_LANG, "auto") ?: "auto"
    fun saveSourceLang(code: String) = prefs.edit().putString(KEY_SOURCE_LANG, code).apply()

    fun getTargetLang(): String = prefs.getString(KEY_TARGET_LANG, "en") ?: "en"
    fun saveTargetLang(code: String) = prefs.edit().putString(KEY_TARGET_LANG, code).apply()

    fun getVoiceMode(): VoiceMode {
        val name = prefs.getString(KEY_VOICE_MODE, VoiceMode.CLOUD_API.name) ?: VoiceMode.CLOUD_API.name
        return try {
            VoiceMode.valueOf(name)
        } catch (e: Exception) {
            VoiceMode.CLOUD_API
        }
    }
    fun saveVoiceMode(mode: VoiceMode) = prefs.edit().putString(KEY_VOICE_MODE, mode.name).apply()

    // 历史记录
    fun getHistory(): List<TranslationHistoryItem> {
        val raw = prefs.getString(KEY_HISTORY_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val array = org.json.JSONArray(raw)
            val list = mutableListOf<TranslationHistoryItem>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    TranslationHistoryItem(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        sourceLang = obj.optString("sourceLang", "zh"),
                        targetLang = obj.optString("targetLang", "en"),
                        sourceText = obj.optString("sourceText", ""),
                        translatedText = obj.optString("translatedText", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        sourceAudioPath = obj.optString("sourceAudioPath", ""),
                        targetAudioPath = obj.optString("targetAudioPath", obj.optString("audioPath", ""))
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveHistory(list: List<TranslationHistoryItem>) {
        try {
            val array = org.json.JSONArray()
            for (item in list.take(100)) {
                val obj = org.json.JSONObject().apply {
                    put("id", item.id)
                    put("sourceLang", item.sourceLang)
                    put("targetLang", item.targetLang)
                    put("sourceText", item.sourceText)
                    put("translatedText", item.translatedText)
                    put("timestamp", item.timestamp)
                    put("isFavorite", item.isFavorite)
                    put("sourceAudioPath", item.sourceAudioPath)
                    put("targetAudioPath", item.targetAudioPath)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY_JSON, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun addHistoryItem(item: TranslationHistoryItem) {
        val current = getHistory().toMutableList()
        val existingIndex = current.indexOfFirst { it.sourceText == item.sourceText && it.targetLang == item.targetLang }
        if (existingIndex >= 0) {
            val old = current[existingIndex]
            val finalSourceAudio = if (item.sourceAudioPath.isNotBlank()) item.sourceAudioPath else old.sourceAudioPath
            val finalTargetAudio = if (item.targetAudioPath.isNotBlank()) item.targetAudioPath else old.targetAudioPath
            current.removeAt(existingIndex)
            current.add(0, item.copy(sourceAudioPath = finalSourceAudio, targetAudioPath = finalTargetAudio))
        } else {
            current.add(0, item)
        }
        saveHistory(current)
    }

    fun updateHistorySourceAudio(sourceText: String, targetLang: String, audioPath: String) {
        val current = getHistory().toMutableList()
        val index = current.indexOfFirst { it.sourceText == sourceText && (targetLang.isBlank() || it.targetLang == targetLang) }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(sourceAudioPath = audioPath)
            saveHistory(current)
        }
    }

    fun updateHistoryTargetAudio(sourceText: String, targetLang: String, audioPath: String) {
        val current = getHistory().toMutableList()
        val index = current.indexOfFirst { (it.sourceText == sourceText || it.translatedText == sourceText) && (targetLang.isBlank() || it.targetLang == targetLang) }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(targetAudioPath = audioPath)
            saveHistory(current)
        }
    }
}
