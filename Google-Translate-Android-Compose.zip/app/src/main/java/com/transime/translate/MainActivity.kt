package com.transime.translate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.transime.translate.data.*
import com.transime.translate.network.GeminiTranslateEngine
import com.transime.translate.network.VocabularyItem
import com.transime.translate.ui.GoogleIcons
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * 翻译主题配色 (沉浸式精简设计)
 */
object GoogleTranslateTheme {
    val PageBg = Color(0xFFF8F9FA)            // 浅灰自然底色
    val CardBg = Color(0xFFFFFFFF)            // 纯白高雅卡片
    val PrimaryBlue = Color(0xFF1A73E8)       // 谷歌品牌蓝
    val PrimaryBlueDark = Color(0xFF1557B0)
    val PrimaryBlueLight = Color(0xFFE8F0FE)  // 浅蓝按键背景
    val TextPrimary = Color(0xFF202124)       // 标题深黑
    val TextSecondary = Color(0xFF5F6368)     // 辅助灰色
    val CardBorder = Color(0xFFDADCE0)        // 浅灰微边框
    val ActionRed = Color(0xFFEA4335)         // 录音提示红
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var translateEngine: GeminiTranslateEngine
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 全面屏沉浸式状态栏 (Edge-to-Edge)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        preferencesManager = PreferencesManager(applicationContext)
        translateEngine = GeminiTranslateEngine(applicationContext, preferencesManager)

        setContent {
            MaterialTheme {
                GoogleTranslateMainScreen(
                    context = this,
                    preferencesManager = preferencesManager,
                    translateEngine = translateEngine,
                    onSpeak = { text, langCode -> playGeminiAudio(text, langCode) }
                )
            }
        }
    }

    /**
     * 纯粹 Gemini 云端 AI 高保真发音（带本地高效持久缓存）：
     * 1. 根据文本和语言生成唯一哈希作为缓存文件名；
     * 2. 若本地已缓存该音频，直接秒播本地文件，无需重复消耗 API 与网络；
     * 3. 若未缓存，调用 Gemini API 请求音频并持久化保存到本地缓存目录。
     */
    private fun playGeminiAudio(text: String, langCode: String) {
        if (text.isBlank()) return
        val targetLang = if (langCode == "auto") "zh" else langCode

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // 计算唯一 MD5 缓存键
                val md5 = MessageDigest.getInstance("MD5")
                    .digest("${targetLang}_${text}".toByteArray(Charsets.UTF_8))
                    .joinToString("") { "%02x".format(it) }

                val audioCacheDir = File(cacheDir, "audio_cache").apply { if (!exists()) mkdirs() }
                val cachedAudioFile = File(audioCacheDir, "${md5}.wav")

                // 命中本地缓存，直接快速播放
                if (cachedAudioFile.exists() && cachedAudioFile.length() > 0) {
                    playAudioFile(cachedAudioFile)
                    return@launch
                }

                // 未命中缓存，请求 Gemini 官方音频 API
                val geminiAudioBytes = translateEngine.generateSpeechAudio(text, targetLang)
                if (geminiAudioBytes != null && geminiAudioBytes.isNotEmpty()) {
                    cachedAudioFile.writeBytes(geminiAudioBytes)
                    playAudioFile(cachedAudioFile)
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "Gemini 发音暂不可用", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun playAudioFile(audioFile: File) {
        withContext(Dispatchers.Main) {
            try {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    setDataSource(audioFile.absolutePath)
                    setOnPreparedListener { it.start() }
                    prepare()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleTranslateMainScreen(
    context: Context,
    preferencesManager: PreferencesManager,
    translateEngine: GeminiTranslateEngine,
    onSpeak: (String, String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(0) } // 0: 翻译主页, 1: 历史记录, 2: 设置

    var sourceLangCode by remember { mutableStateOf(preferencesManager.getSourceLang()) }
    var targetLangCode by remember { mutableStateOf(preferencesManager.getTargetLang()) }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLangCode by remember { mutableStateOf("") }
    var vocabularyList by remember { mutableStateOf<List<VocabularyItem>>(emptyList()) }
    var isTranslating by remember { mutableStateOf(false) }

    // 录音状态
    var isRecording by remember { mutableStateOf(false) }
    var mediaRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var audioRecordFile by remember { mutableStateOf<File?>(null) }

    // 触发文本翻译
    val performTextTranslation: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isTranslating = true
            coroutineScope.launch {
                val res = translateEngine.translateText(query, sourceLangCode, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                vocabularyList = res.vocabulary
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = query,
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        }
    }

    val recordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "已授予录音权限，请点击麦克风开始说话", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "需要录音权限才能使用语音输入功能", Toast.LENGTH_SHORT).show()
        }
    }

    val stopRecordingAndProcess: () -> Unit = {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaRecorder = null
        isRecording = false

        val file = audioRecordFile
        if (file != null && file.exists() && file.length() > 0) {
            isTranslating = true
            inputText = ""
            translatedText = ""
            vocabularyList = emptyList()
            coroutineScope.launch {
                val res = translateEngine.recognizeAndTranslateAudio(file, targetLangCode)
                if (res.recognizedText.isNotBlank()) {
                    inputText = res.recognizedText
                }
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                vocabularyList = res.vocabulary
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = if (res.recognizedText.isNotBlank()) res.recognizedText else "语音输入",
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        } else {
            Toast.makeText(context, "录音时间过短或未采集到声音", Toast.LENGTH_SHORT).show()
        }
    }

    val startAudioRecording: () -> Unit = {
        try {
            val file = File(context.cacheDir, "voice_input_${System.currentTimeMillis()}.m4a")
            audioRecordFile = file

            @Suppress("DEPRECATION")
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(96000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            isRecording = true
        } catch (e: Exception) {
            e.printStackTrace()
            isRecording = false
            Toast.makeText(context, "启动录音失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    val handleVoiceAction: () -> Unit = {
        val audioPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (audioPermission != PackageManager.PERMISSION_GRANTED) {
            recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            if (isRecording) {
                stopRecordingAndProcess()
            } else {
                startAudioRecording()
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(GoogleTranslateTheme.CardBg).statusBarsPadding()) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(GoogleIcons.Translate, contentDescription = null, tint = GoogleTranslateTheme.PrimaryBlue)
                            Text("翻译", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GoogleTranslateTheme.TextPrimary)
                        }
                    },
                    actions = {
                        IconButton(onClick = { currentTab = if (currentTab == 1) 0 else 1 }) {
                            Icon(GoogleIcons.History, contentDescription = "历史", tint = if (currentTab == 1) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                        IconButton(onClick = { currentTab = if (currentTab == 2) 0 else 2 }) {
                            Icon(GoogleIcons.Settings, contentDescription = "设置", tint = if (currentTab == 2) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleTranslateTheme.CardBg)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GoogleTranslateTheme.PageBg)
                .navigationBarsPadding()
        ) {
            when (currentTab) {
                0 -> {
                    TranslateHomeScreen(
                        sourceLangCode = sourceLangCode,
                        targetLangCode = targetLangCode,
                        onSourceLangChange = {
                            sourceLangCode = it
                            preferencesManager.saveSourceLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onTargetLangChange = {
                            targetLangCode = it
                            preferencesManager.saveTargetLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onSwapLanguages = {
                            if (sourceLangCode != "auto") {
                                val temp = sourceLangCode
                                sourceLangCode = targetLangCode
                                targetLangCode = temp
                                preferencesManager.saveSourceLang(sourceLangCode)
                                preferencesManager.saveTargetLang(targetLangCode)
                                if (translatedText.isNotBlank() && !translatedText.startsWith("【")) {
                                    val oldTrans = translatedText
                                    inputText = oldTrans
                                    performTextTranslation(oldTrans)
                                }
                            }
                        },
                        inputText = inputText,
                        onInputTextChange = { inputText = it },
                        translatedText = translatedText,
                        detectedLangCode = detectedLangCode,
                        vocabularyList = vocabularyList,
                        isTranslating = isTranslating,
                        isRecording = isRecording,
                        onTranslateClick = { performTextTranslation(inputText) },
                        onVoiceClick = handleVoiceAction,
                        onSpeak = onSpeak,
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", text))
                            Toast.makeText(context, "已复制到剪切板", Toast.LENGTH_SHORT).show()
                        },
                        onClear = {
                            inputText = ""
                            translatedText = ""
                            detectedLangCode = ""
                            vocabularyList = emptyList()
                        }
                    )
                }
                1 -> {
                    HistoryScreen(
                        preferencesManager = preferencesManager,
                        onSelectHistory = { item ->
                            sourceLangCode = item.sourceLang
                            targetLangCode = item.targetLang
                            inputText = item.sourceText
                            translatedText = item.translatedText
                            currentTab = 0
                        },
                        onClearAll = {
                            preferencesManager.saveHistory(emptyList())
                        }
                    )
                }
                2 -> {
                    SettingsScreen(
                        preferencesManager = preferencesManager,
                        onSaved = {
                            currentTab = 0
                            Toast.makeText(context, "配置已保存", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

/**
 * 翻译主页 (极简纯粹设计：纯中文逐词/词组拆解 + 谷歌官方发音)
 */
@Composable
fun TranslateHomeScreen(
    sourceLangCode: String,
    targetLangCode: String,
    onSourceLangChange: (String) -> Unit,
    onTargetLangChange: (String) -> Unit,
    onSwapLanguages: () -> Unit,
    inputText: String,
    onInputTextChange: (String) -> Unit,
    translatedText: String,
    detectedLangCode: String,
    vocabularyList: List<VocabularyItem>,
    isTranslating: Boolean,
    isRecording: Boolean,
    onTranslateClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onSpeak: (String, String) -> Unit,
    onCopy: (String) -> Unit,
    onClear: () -> Unit
) {
    var showSourceLangDialog by remember { mutableStateOf(false) }
    var showTargetLangDialog by remember { mutableStateOf(false) }

    val sourceLang = SupportedLanguages.getByCode(sourceLangCode)
    val targetLang = SupportedLanguages.getByCode(targetLangCode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. 语言切换药丸条
        Card(
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = { showSourceLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${sourceLang.flag} ${sourceLang.displayName}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }

                IconButton(onClick = onSwapLanguages, enabled = sourceLangCode != "auto") {
                    Icon(GoogleIcons.SwapHoriz, contentDescription = "对调语种", tint = if (sourceLangCode != "auto") GoogleTranslateTheme.PrimaryBlue else Color.LightGray)
                }

                TextButton(onClick = { showTargetLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${targetLang.flag} ${targetLang.displayName}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }
            }
        }

        // 2. 原文输入卡片
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (detectedLangCode.isNotBlank() && sourceLangCode == "auto") "检测到: ${SupportedLanguages.getByCode(detectedLangCode).displayName}" else sourceLang.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GoogleTranslateTheme.TextSecondary
                    )
                    if (inputText.isNotBlank()) {
                        Text(
                            text = "清空",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoogleTranslateTheme.ActionRed,
                            modifier = Modifier.clickable { onClear() }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = { Text("输入文字...", color = Color.Gray, fontSize = 16.sp) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 220.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inputText.isNotBlank()) {
                        IconButton(onClick = { onSpeak(inputText, if (detectedLangCode.isNotBlank()) detectedLangCode else sourceLangCode) }) {
                            Icon(GoogleIcons.VolumeUp, contentDescription = "朗读原文", tint = GoogleTranslateTheme.TextSecondary)
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    Button(
                        onClick = onTranslateClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                        shape = RoundedCornerShape(20.dp),
                        enabled = !isTranslating && inputText.isNotBlank()
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("翻译", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // 3. 语音输入圆形大按钮
        Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlue)
                    .clickable { onVoiceClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    GoogleIcons.Mic,
                    contentDescription = "语音输入",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // 4. 译文展示卡片 (Google 原生蓝底卡片)
        if (translatedText.isNotBlank() || isTranslating) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = targetLang.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Row {
                            IconButton(onClick = { onSpeak(translatedText, targetLangCode) }) {
                                Icon(GoogleIcons.VolumeUp, contentDescription = "朗读译文", tint = Color.White)
                            }
                            IconButton(onClick = { onCopy(translatedText) }) {
                                Icon(GoogleIcons.ContentCopy, contentDescription = "复制译文", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (isTranslating) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                        }
                    } else {
                        Text(
                            text = translatedText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            lineHeight = 25.sp
                        )
                    }

                    // 5. 逐词与词组纯中文拆解列表（自适应排版，紧凑优雅）
                    if (vocabularyList.isNotEmpty() && !isTranslating) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "📖 词汇与词组中文解析：",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFD54F) // 明亮金黄
                                )
                                vocabularyList.forEach { item ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "• ${item.word}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = item.meaning,
                                            fontSize = 13.sp,
                                            color = Color.White.copy(alpha = 0.92f),
                                            lineHeight = 18.sp,
                                            modifier = Modifier.padding(start = 10.dp, top = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSourceLangDialog) {
        LanguageSelectDialog(
            title = "选择源语言",
            selectedCode = sourceLangCode,
            languages = SupportedLanguages.ALL,
            onSelect = {
                onSourceLangChange(it)
                showSourceLangDialog = false
            },
            onDismiss = { showSourceLangDialog = false }
        )
    }

    if (showTargetLangDialog) {
        LanguageSelectDialog(
            title = "选择目标语言",
            selectedCode = targetLangCode,
            languages = SupportedLanguages.ALL.filter { it.code != "auto" },
            onSelect = {
                onTargetLangChange(it)
                showTargetLangDialog = false
            },
            onDismiss = { showTargetLangDialog = false }
        )
    }
}

/**
 * 语言列表选择弹窗
 */
@Composable
fun LanguageSelectDialog(
    title: String,
    selectedCode: String,
    languages: List<Language>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                items(languages) { lang ->
                    val isSelected = lang.code == selectedCode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoogleTranslateTheme.PrimaryBlueLight else Color.Transparent)
                            .clickable { onSelect(lang.code) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            lang.displayName,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

/**
 * 历史记录页面
 */
@Composable
fun HistoryScreen(
    preferencesManager: PreferencesManager,
    onSelectHistory: (TranslationHistoryItem) -> Unit,
    onClearAll: () -> Unit
) {
    var historyList by remember { mutableStateOf(preferencesManager.getHistory()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("翻译历史记录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
            if (historyList.isNotEmpty()) {
                TextButton(onClick = {
                    onClearAll()
                    historyList = emptyList()
                }) {
                    Text("清空历史", color = GoogleTranslateTheme.ActionRed)
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("暂无翻译历史记录", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(historyList) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
                        modifier = Modifier.fillMaxWidth().clickable { onSelectHistory(item) }
                    ) {
                        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${SupportedLanguages.getByCode(item.sourceLang).displayName} ➔ ${SupportedLanguages.getByCode(item.targetLang).displayName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoogleTranslateTheme.PrimaryBlue
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.sourceText, fontSize = 14.sp, color = GoogleTranslateTheme.TextPrimary, maxLines = 2)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.translatedText, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = GoogleTranslateTheme.PrimaryBlueDark, maxLines = 2)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 设置页面
 */
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    onSaved: () -> Unit
) {
    var apiKey by remember { mutableStateOf(preferencesManager.getApiKey()) }
    var baseUrl by remember { mutableStateOf(preferencesManager.getBaseUrl()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("翻译设置", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Gemini API Key", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "用于文字互译、语音识别及词汇词组解析。",
                    fontSize = 12.sp,
                    color = GoogleTranslateTheme.TextSecondary
                )
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("API 代理 Base URL", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = { Text("https://generativelanguage.googleapis.com") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }

        Button(
            onClick = {
                preferencesManager.saveApiKey(apiKey)
                preferencesManager.saveBaseUrl(baseUrl)
                onSaved()
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("保存设置", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
