package com.transime.translate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.transime.translate.data.*
import com.transime.translate.network.GeminiTranslateEngine
import com.transime.translate.network.VocabularyItem
import com.transime.translate.ui.GoogleIcons
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/**
 * 翻译主题配色 (沉浸式精简设计)
 */
object GoogleTranslateTheme {
    val PageBg = Color(0xFFF8F9FA)            // 浅灰自然底色
    val CardBg = Color(0xFFFFFFFF)            // 纯白高雅卡片
    val PrimaryBlue = Color(0xFF1A73E8)       // 谷歌品牌蓝
    val PrimaryBlueDark = Color(0xFF1557B0)
    val PrimaryBlueLight = Color(0xFFE8F0FE)  // 浅蓝按键背景
    val TextPrimary = Color(0xFF202124)       // 标题深黑
    val TextSecondary = Color(0xFF5F6368)     // 辅助灰色
    val CardBorder = Color(0xFFDADCE0)        // 浅灰微边框
    val ActionRed = Color(0xFFEA4335)         // 录音提示红
}

class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager
    private lateinit var translateEngine: GeminiTranslateEngine
    private var mediaPlayer: MediaPlayer? = null
    private var audioTrack: AudioTrack? = null
    private var currentlyPlayingKey: String? = null
    private val isAudioPlaying = mutableStateOf(false)
    private val activePlayingKey = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 全面屏沉浸式状态栏 (Edge-to-Edge)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        preferencesManager = PreferencesManager(applicationContext)
        translateEngine = GeminiTranslateEngine(applicationContext, preferencesManager)

        setContent {
            MaterialTheme {
                GoogleTranslateMainScreen(
                    context = this,
                    preferencesManager = preferencesManager,
                    translateEngine = translateEngine,
                    isPlaying = isAudioPlaying.value,
                    playingKey = activePlayingKey.value,
                    onToggleSpeak = { key, text, langCode, onAudioReady ->
                        toggleSpeechAudio(key, text, langCode, onAudioReady)
                    },
                    onSpeakWordSlice = { wordIndex, totalWords, fullSentence, langCode ->
                        playWordFromCachedSentenceAudio(wordIndex, totalWords, fullSentence, langCode)
                    }
                )
            }
        }
    }

    /**
     * 喇叭播放/暂停（停止）切换控制：
     * 若当前正在播放此条音频，点击直接暂停/停止；
     * 若未播放，则启动播放（支持云端拉取/本地缓存播放）。
     */
    private fun toggleSpeechAudio(
        key: String,
        text: String,
        langCode: String,
        onAudioReady: ((String) -> Unit)? = null
    ) {
        if (isAudioPlaying.value && currentlyPlayingKey == key) {
            stopAnyPlayingAudio()
            return
        }
        playGeminiAudio(key, text, langCode, onAudioReady)
    }

    private fun stopAnyPlayingAudio() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
        currentlyPlayingKey = null
        isAudioPlaying.value = false
        activePlayingKey.value = null
    }

    /**
     * 从已保存的整句发音中定位并播放指定单词的声音（纯本地0流量发音）：
     * 1. 严格检查整句音频是否已在本地永久保存；
     * 2. 若未从云端拉取过发音，绝不进行本地机械音合成，而是提示先点击整句发音；
     * 3. 若已从云端拉取并保存，提取并精确播放该单词对应的时间段声波。
     */
    private fun playWordFromCachedSentenceAudio(
        wordIndex: Int,
        totalWords: Int,
        fullSentence: String,
        langCode: String
    ) {
        val targetLang = if (langCode == "auto") "zh" else langCode
        val md5 = MessageDigest.getInstance("MD5")
            .digest("${targetLang}_${fullSentence}".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

        val audioStorageDir = File(filesDir, "history_audios")
        val cachedAudioFile = File(audioStorageDir, "${md5}.wav")

        if (!cachedAudioFile.exists() || cachedAudioFile.length() <= 44) {
            Toast.makeText(this, "请先点击右上角喇叭朗读并保存全句发音", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val wavBytes = cachedAudioFile.readBytes()
                val pcmDataOffset = 44 // 标准 WAV 头部大小
                val totalPcmBytes = wavBytes.size - pcmDataOffset
                if (totalPcmBytes <= 0 || totalWords <= 0) return@launch

                val safeTotal = totalWords.coerceAtLeast(1)
                val safeIndex = wordIndex.coerceIn(0, safeTotal - 1)

                val sliceSize = totalPcmBytes / safeTotal
                // 对齐到 2 字节（16-bit PCM）
                val startByte = pcmDataOffset + ((sliceSize * safeIndex) / 2) * 2
                val lengthToPlay = (sliceSize / 2) * 2

                playPcmChunk(wavBytes, startByte, lengthToPlay)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun playPcmChunk(pcmData: ByteArray, startOffset: Int, length: Int) {
        try {
            audioTrack?.stop()
            audioTrack?.release()

            val sampleRate = 24000
            val channelConfig = AudioFormat.CHANNEL_OUT_MONO
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT
            val minBuf = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufSize = Math.max(minBuf, length)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .build()
                )
                .setBufferSizeInBytes(bufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack = track
            track.play()
            track.write(pcmData, startOffset, length)
            track.stop()
            track.release()
            audioTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 纯粹 Gemini 云端 AI 高保真发音（带本地高效持久缓存）：
     * 1. 根据文本和语言生成唯一哈希作为缓存文件名；
     * 2. 若本地已缓存该音频，直接秒播本地文件，无需重复消耗 API 与网络；
     * 3. 若未缓存，调用 Gemini API 请求音频并持久化保存到本地存储目录。
     */
    private fun playGeminiAudio(
        key: String,
        text: String,
        langCode: String,
        onAudioReady: ((String) -> Unit)? = null
    ) {
        if (text.isBlank()) return
        val targetLang = if (langCode == "auto") "zh" else langCode

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // 计算唯一 MD5 缓存键
                val md5 = MessageDigest.getInstance("MD5")
                    .digest("${targetLang}_${text}".toByteArray(Charsets.UTF_8))
                    .joinToString("") { "%02x".format(it) }

                val audioStorageDir = File(filesDir, "history_audios").apply { if (!exists()) mkdirs() }
                val cachedAudioFile = File(audioStorageDir, "${md5}.wav")

                // 命中本地永久缓存，直接快速播放 (0 延迟)
                if (cachedAudioFile.exists() && cachedAudioFile.length() > 0) {
                    onAudioReady?.invoke(cachedAudioFile.absolutePath)
                    playAudioFile(key, cachedAudioFile)
                    return@launch
                }

                // 请求 Gemini 官方音频 API
                val (geminiAudioBytes, errorMsg) = translateEngine.generateSpeechAudio(text, targetLang)
                if (geminiAudioBytes != null && geminiAudioBytes.isNotEmpty()) {
                    cachedAudioFile.writeBytes(geminiAudioBytes)
                    onAudioReady?.invoke(cachedAudioFile.absolutePath)
                    playAudioFile(key, cachedAudioFile)
                } else {
                    withContext(Dispatchers.Main) {
                        val displayMsg = if (errorMsg.isNotBlank()) "Gemini 发音失败: $errorMsg" else "Gemini 发音暂不可用"
                        Toast.makeText(this@MainActivity, displayMsg, Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private suspend fun playAudioFile(key: String, audioFile: File) {
        withContext(Dispatchers.Main) {
            try {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    setDataSource(audioFile.absolutePath)
                    setOnPreparedListener {
                        it.start()
                        currentlyPlayingKey = key
                        isAudioPlaying.value = true
                        activePlayingKey.value = key
                    }
                    setOnCompletionListener {
                        currentlyPlayingKey = null
                        isAudioPlaying.value = false
                        activePlayingKey.value = null
                    }
                    prepare()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                currentlyPlayingKey = null
                isAudioPlaying.value = false
                activePlayingKey.value = null
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleTranslateMainScreen(
    context: Context,
    preferencesManager: PreferencesManager,
    translateEngine: GeminiTranslateEngine,
    isPlaying: Boolean,
    playingKey: String?,
    onToggleSpeak: (String, String, String, ((String) -> Unit)?) -> Unit,
    onSpeakWordSlice: (Int, Int, String, String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentTab by remember { mutableStateOf(0) } // 0: 翻译主页, 1: 历史记录, 2: 设置

    var sourceLangCode by remember { mutableStateOf(preferencesManager.getSourceLang()) }
    var targetLangCode by remember { mutableStateOf(preferencesManager.getTargetLang()) }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLangCode by remember { mutableStateOf("") }
    var vocabularyList by remember { mutableStateOf<List<VocabularyItem>>(emptyList()) }
    var isTranslating by remember { mutableStateOf(false) }

    // 录音状态
    var isRecording by remember { mutableStateOf(false) }
    var mediaRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var audioRecordFile by remember { mutableStateOf<File?>(null) }

    // 触发文本翻译
    val performTextTranslation: (String) -> Unit = { query ->
        if (query.isNotBlank()) {
            isTranslating = true
            coroutineScope.launch {
                val res = translateEngine.translateText(query, sourceLangCode, targetLangCode)
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                vocabularyList = res.vocabulary
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = query,
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        }
    }

    val recordPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "已授予录音权限，请点击麦克风开始说话", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "需要录音权限才能使用语音输入功能", Toast.LENGTH_SHORT).show()
        }
    }

    val stopRecordingAndProcess: () -> Unit = {
        try {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaRecorder = null
        isRecording = false

        val file = audioRecordFile
        if (file != null && file.exists() && file.length() > 0) {
            isTranslating = true
            inputText = ""
            translatedText = ""
            vocabularyList = emptyList()
            coroutineScope.launch {
                // 严格以当前选定的源语言 (sourceLangCode) 为依据进行语音识别与转写
                val res = translateEngine.recognizeAndTranslateAudio(
                    audioFile = file,
                    sourceLang = sourceLangCode,
                    targetLang = targetLangCode
                )
                if (res.recognizedText.isNotBlank()) {
                    inputText = res.recognizedText
                }
                translatedText = res.translatedText
                detectedLangCode = res.detectedLang
                vocabularyList = res.vocabulary
                isTranslating = false

                if (res.translatedText.isNotBlank() && !res.translatedText.startsWith("[")) {
                    preferencesManager.addHistoryItem(
                        TranslationHistoryItem(
                            sourceLang = res.detectedLang,
                            targetLang = targetLangCode,
                            sourceText = if (res.recognizedText.isNotBlank()) res.recognizedText else "语音输入",
                            translatedText = res.translatedText
                        )
                    )
                }
            }
        } else {
            Toast.makeText(context, "录音时间过短或未采集到声音", Toast.LENGTH_SHORT).show()
        }
    }

    val startAudioRecording: () -> Unit = {
        try {
            val file = File(context.cacheDir, "voice_input_${System.currentTimeMillis()}.m4a")
            audioRecordFile = file

            @Suppress("DEPRECATION")
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(96000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            isRecording = true
        } catch (e: Exception) {
            e.printStackTrace()
            isRecording = false
            Toast.makeText(context, "启动录音失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    val handleVoiceAction: () -> Unit = {
        val audioPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (audioPermission != PackageManager.PERMISSION_GRANTED) {
            recordPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            if (isRecording) {
                stopRecordingAndProcess()
            } else {
                startAudioRecording()
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(GoogleTranslateTheme.CardBg).statusBarsPadding()) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(GoogleIcons.Translate, contentDescription = null, tint = GoogleTranslateTheme.PrimaryBlue)
                            Text("翻译", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = GoogleTranslateTheme.TextPrimary)
                        }
                    },
                    actions = {
                        IconButton(onClick = { currentTab = if (currentTab == 1) 0 else 1 }) {
                            Icon(GoogleIcons.History, contentDescription = "历史", tint = if (currentTab == 1) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                        IconButton(onClick = { currentTab = if (currentTab == 2) 0 else 2 }) {
                            Icon(GoogleIcons.Settings, contentDescription = "设置", tint = if (currentTab == 2) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = GoogleTranslateTheme.CardBg)
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GoogleTranslateTheme.PageBg)
                .navigationBarsPadding()
        ) {
            when (currentTab) {
                0 -> {
                    TranslateHomeScreen(
                        sourceLangCode = sourceLangCode,
                        targetLangCode = targetLangCode,
                        onSourceLangChange = {
                            sourceLangCode = it
                            preferencesManager.saveSourceLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onTargetLangChange = {
                            targetLangCode = it
                            preferencesManager.saveTargetLang(it)
                            if (inputText.isNotBlank()) performTextTranslation(inputText)
                        },
                        onSwapLanguages = {
                            if (sourceLangCode != "auto") {
                                val temp = sourceLangCode
                                sourceLangCode = targetLangCode
                                targetLangCode = temp
                                preferencesManager.saveSourceLang(sourceLangCode)
                                preferencesManager.saveTargetLang(targetLangCode)
                                if (translatedText.isNotBlank() && !translatedText.startsWith("【")) {
                                    val oldTrans = translatedText
                                    inputText = oldTrans
                                    performTextTranslation(oldTrans)
                                }
                            }
                        },
                        inputText = inputText,
                        onInputTextChange = { inputText = it },
                        translatedText = translatedText,
                        detectedLangCode = detectedLangCode,
                        vocabularyList = vocabularyList,
                        isTranslating = isTranslating,
                        isRecording = isRecording,
                        isPlaying = isPlaying,
                        playingKey = playingKey,
                        onTranslateClick = { performTextTranslation(inputText) },
                        onVoiceClick = handleVoiceAction,
                        onToggleSpeak = { key, text, lang ->
                            onToggleSpeak(key, text, lang) { savedPath ->
                                // 原文/译文朗读成功后，将音频持久化路径分别存入该翻译历史记录中
                                val isSource = (text == inputText)
                                if (isSource) {
                                    preferencesManager.updateHistorySourceAudio(
                                        sourceText = inputText,
                                        targetLang = targetLangCode,
                                        audioPath = savedPath
                                    )
                                } else {
                                    preferencesManager.updateHistoryTargetAudio(
                                        sourceText = inputText,
                                        targetLang = targetLangCode,
                                        audioPath = savedPath
                                    )
                                }
                            }
                        },
                        onSpeakWordSlice = onSpeakWordSlice,
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", text))
                            Toast.makeText(context, "已复制到剪切板", Toast.LENGTH_SHORT).show()
                        },
                        onClear = {
                            inputText = ""
                            translatedText = ""
                            detectedLangCode = ""
                            vocabularyList = emptyList()
                        }
                    )
                }
                1 -> {
                    HistoryScreen(
                        preferencesManager = preferencesManager,
                        isPlaying = isPlaying,
                        playingKey = playingKey,
                        onSelectHistory = { item ->
                            sourceLangCode = item.sourceLang
                            targetLangCode = item.targetLang
                            inputText = item.sourceText
                            translatedText = item.translatedText
                            currentTab = 0
                        },
                        onTogglePlayAudio = { key, audioPath, text, langCode, isTarget ->
                            onToggleSpeak(key, text, langCode) { newPath ->
                                if (isTarget) {
                                    preferencesManager.updateHistoryTargetAudio(sourceText = text, targetLang = langCode, audioPath = newPath)
                                } else {
                                    preferencesManager.updateHistorySourceAudio(sourceText = text, targetLang = langCode, audioPath = newPath)
                                }
                            }
                        }
                    )
                }
                2 -> {
                    SettingsScreen(
                        preferencesManager = preferencesManager,
                        onSaved = {
                            currentTab = 0
                            Toast.makeText(context, "配置已保存", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

/**
 * 翻译主页 (极简纯粹设计：纯中文逐词/词组拆解 + 谷歌官方发音)
 */
/**
 * 智能分词切片辅助函数：
 * 对于中文、日文等不以空格分词的东亚语言，使用正则表达式或单个字符/词段切分；
 * 对于英文、越南语、法语等拉丁语系语言，按空格分词。
 */
fun segmentTextToWords(text: String, langCode: String): List<String> {
    val trimmed = text.trim()
    if (trimmed.isBlank()) return emptyList()

    val isCjk = langCode.equals("zh", ignoreCase = true) ||
            langCode.equals("ja", ignoreCase = true) ||
            langCode.equals("ko", ignoreCase = true) ||
            trimmed.any { it.code in 0x4E00..0x9FFF }

    return if (isCjk) {
        // 过滤掉中英文标点符号，按有效单字或短词拆解
        trimmed.map { it.toString() }
            .filter { it.isNotBlank() && !it.matches(Regex("[，。！？、；：“”‘’（）《》\\s,;.!?'\"()<\\[\\]]")) }
    } else {
        trimmed.split(Regex("\\s+")).filter { it.isNotBlank() }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TranslateHomeScreen(
    sourceLangCode: String,
    targetLangCode: String,
    onSourceLangChange: (String) -> Unit,
    onTargetLangChange: (String) -> Unit,
    onSwapLanguages: () -> Unit,
    inputText: String,
    onInputTextChange: (String) -> Unit,
    translatedText: String,
    detectedLangCode: String,
    vocabularyList: List<VocabularyItem>,
    isTranslating: Boolean,
    isRecording: Boolean,
    isPlaying: Boolean,
    playingKey: String?,
    onTranslateClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onToggleSpeak: (String, String, String) -> Unit,
    onSpeakWordSlice: (Int, Int, String, String) -> Unit,
    onCopy: (String) -> Unit,
    onClear: () -> Unit
) {
    var showSourceLangDialog by remember { mutableStateOf(false) }
    var showTargetLangDialog by remember { mutableStateOf(false) }

    val sourceLang = SupportedLanguages.getByCode(sourceLangCode)
    val targetLang = SupportedLanguages.getByCode(targetLangCode)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. 语言切换药丸条
        Card(
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TextButton(onClick = { showSourceLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${sourceLang.flag} ${sourceLang.displayName}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }

                IconButton(onClick = onSwapLanguages, enabled = sourceLangCode != "auto") {
                    Icon(GoogleIcons.SwapHoriz, contentDescription = "对调语种", tint = if (sourceLangCode != "auto") GoogleTranslateTheme.PrimaryBlue else Color.LightGray)
                }

                TextButton(onClick = { showTargetLangDialog = true }, modifier = Modifier.weight(1f)) {
                    Text(
                        "${targetLang.flag} ${targetLang.displayName}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.PrimaryBlue
                    )
                }
            }
        }

        // 2. 原文输入卡片
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (detectedLangCode.isNotBlank() && sourceLangCode == "auto") "检测到: ${SupportedLanguages.getByCode(detectedLangCode).displayName}" else sourceLang.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GoogleTranslateTheme.TextSecondary
                    )
                    if (inputText.isNotBlank()) {
                        Text(
                            text = "清空",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoogleTranslateTheme.ActionRed,
                            modifier = Modifier.clickable { onClear() }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = { Text("输入文字...", color = Color.Gray, fontSize = 16.sp) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp, max = 180.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    )
                )

                // 原文拆解到单个单词/字/词组的点击发音条（朗读保存后即点即发音）
                if (inputText.isNotBlank() && !isTranslating) {
                    val activeSourceLang = if (detectedLangCode.isNotBlank() && sourceLangCode == "auto") detectedLangCode else sourceLangCode
                    val rawWords = remember(inputText, activeSourceLang) {
                        segmentTextToWords(inputText, activeSourceLang)
                    }
                    if (rawWords.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🔊 点击单词/单字发音:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoogleTranslateTheme.TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rawWords.forEachIndexed { index, word ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(GoogleTranslateTheme.PrimaryBlueLight)
                                        .clickable { onSpeakWordSlice(index, rawWords.size, inputText, activeSourceLang) }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = word,
                                        fontSize = 13.sp,
                                        color = GoogleTranslateTheme.PrimaryBlue,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (inputText.isNotBlank()) {
                        val isSourcePlaying = isPlaying && playingKey == "source"
                        IconButton(onClick = { onToggleSpeak("source", inputText, if (detectedLangCode.isNotBlank()) detectedLangCode else sourceLangCode) }) {
                            Icon(
                                if (isSourcePlaying) GoogleIcons.Stop else GoogleIcons.VolumeUp,
                                contentDescription = if (isSourcePlaying) "暂停朗读" else "朗读原文",
                                tint = if (isSourcePlaying) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.TextSecondary
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    Button(
                        onClick = onTranslateClick,
                        colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                        shape = RoundedCornerShape(20.dp),
                        enabled = !isTranslating && inputText.isNotBlank()
                    ) {
                        if (isTranslating) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text("翻译", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // 3. 语音输入圆形大按钮
        Box(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) GoogleTranslateTheme.ActionRed else GoogleTranslateTheme.PrimaryBlue)
                    .clickable { onVoiceClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    GoogleIcons.Mic,
                    contentDescription = "语音输入",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }

        // 4. 译文展示卡片 (Google 原生蓝底卡片)
        if (translatedText.isNotBlank() || isTranslating) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = targetLang.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        Row {
                            val isTargetPlaying = isPlaying && playingKey == "target"
                            IconButton(onClick = { onToggleSpeak("target", translatedText, targetLangCode) }) {
                                Icon(
                                    if (isTargetPlaying) GoogleIcons.Stop else GoogleIcons.VolumeUp,
                                    contentDescription = if (isTargetPlaying) "暂停朗读" else "朗读译文",
                                    tint = if (isTargetPlaying) Color(0xFFFFCC80) else Color.White
                                )
                            }
                            IconButton(onClick = { onCopy(translatedText) }) {
                                Icon(GoogleIcons.ContentCopy, contentDescription = "复制译文", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (isTranslating) {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                        }
                    } else {
                        Text(
                            text = translatedText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            lineHeight = 25.sp
                        )

                        // 译文逐词拆解点击发音（整句发音保存后，点词即可本地0流量发音）
                        val targetWords = remember(translatedText, targetLangCode) {
                            segmentTextToWords(translatedText, targetLangCode)
                        }
                        if (targetWords.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                targetWords.forEachIndexed { index, word ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.White.copy(alpha = 0.22f))
                                            .clickable { onSpeakWordSlice(index, targetWords.size, translatedText, targetLangCode) }
                                            .padding(horizontal = 7.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = word,
                                            fontSize = 13.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 5. 逐词与词组纯中文拆解列表（自适应排版，紧凑优雅，点击也可本地0流量发音）
                    if (vocabularyList.isNotEmpty() && !isTranslating) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "📖 词汇与词组中文解析：",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFD54F) // 明亮金黄
                                )
                                vocabularyList.forEachIndexed { vIndex, item ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                onSpeakWordSlice(vIndex, vocabularyList.size, translatedText, targetLangCode)
                                            }
                                            .padding(vertical = 3.dp, horizontal = 4.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "• ${item.word}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                GoogleIcons.VolumeUp,
                                                contentDescription = "朗读该词",
                                                tint = Color.White.copy(alpha = 0.7f),
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        Text(
                                            text = item.meaning,
                                            fontSize = 13.sp,
                                            color = Color.White.copy(alpha = 0.92f),
                                            lineHeight = 18.sp,
                                            modifier = Modifier.padding(start = 10.dp, top = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSourceLangDialog) {
        LanguageSelectDialog(
            title = "选择源语言",
            selectedCode = sourceLangCode,
            languages = SupportedLanguages.ALL,
            onSelect = {
                onSourceLangChange(it)
                showSourceLangDialog = false
            },
            onDismiss = { showSourceLangDialog = false }
        )
    }

    if (showTargetLangDialog) {
        LanguageSelectDialog(
            title = "选择目标语言",
            selectedCode = targetLangCode,
            languages = SupportedLanguages.ALL.filter { it.code != "auto" },
            onSelect = {
                onTargetLangChange(it)
                showTargetLangDialog = false
            },
            onDismiss = { showTargetLangDialog = false }
        )
    }
}

/**
 * 语言列表选择弹窗
 */
@Composable
fun LanguageSelectDialog(
    title: String,
    selectedCode: String,
    languages: List<Language>,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                items(languages) { lang ->
                    val isSelected = lang.code == selectedCode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoogleTranslateTheme.PrimaryBlueLight else Color.Transparent)
                            .clickable { onSelect(lang.code) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(lang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            lang.displayName,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextPrimary
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

/**
 * 历史记录页面 (支持选择单个/多选/全选/批量删除，以及原文与译文独立永久发音播放)
 */
@Composable
fun HistoryScreen(
    preferencesManager: PreferencesManager,
    isPlaying: Boolean,
    playingKey: String?,
    onSelectHistory: (TranslationHistoryItem) -> Unit,
    onTogglePlayAudio: (String, String, String, String, Boolean) -> Unit
) {
    var historyList by remember { mutableStateOf(preferencesManager.getHistory()) }
    var isSelectMode by remember { mutableStateOf(false) }
    var selectedIds by remember { mutableStateOf(setOf<Long>()) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // 顶部操作栏
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSelectMode) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = historyList.isNotEmpty() && selectedIds.size == historyList.size,
                        onCheckedChange = { checked ->
                            selectedIds = if (checked) historyList.map { it.id }.toSet() else emptySet()
                        }
                    )
                    Text(
                        text = "已选 ${selectedIds.size} 项",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoogleTranslateTheme.TextPrimary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (selectedIds.isNotEmpty()) {
                        IconButton(onClick = {
                            val remaining = historyList.filter { it.id !in selectedIds }
                            preferencesManager.saveHistory(remaining)
                            historyList = remaining
                            selectedIds = emptySet()
                            isSelectMode = false
                        }) {
                            Icon(GoogleIcons.Delete, contentDescription = "删除选中", tint = GoogleTranslateTheme.ActionRed)
                        }
                    }
                    TextButton(onClick = {
                        isSelectMode = false
                        selectedIds = emptySet()
                    }) {
                        Text("取消", color = GoogleTranslateTheme.TextSecondary)
                    }
                }
            } else {
                Text("翻译历史记录", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                if (historyList.isNotEmpty()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            isSelectMode = true
                            selectedIds = emptySet()
                        }) {
                            Text("多选", color = GoogleTranslateTheme.PrimaryBlue)
                        }
                        TextButton(onClick = {
                            preferencesManager.saveHistory(emptyList())
                            historyList = emptyList()
                        }) {
                            Text("清空", color = GoogleTranslateTheme.ActionRed)
                        }
                    }
                }
            }
        }

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("暂无翻译历史记录", color = Color.Gray, fontSize = 14.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(historyList, key = { it.id }) { item ->
                    val isChecked = item.id in selectedIds
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isChecked) GoogleTranslateTheme.PrimaryBlueLight else GoogleTranslateTheme.CardBg
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isSelectMode) {
                                    selectedIds = if (isChecked) selectedIds - item.id else selectedIds + item.id
                                } else {
                                    onSelectHistory(item)
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelectMode) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedIds = if (checked) selectedIds + item.id else selectedIds - item.id
                                    }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "${SupportedLanguages.getByCode(item.sourceLang).displayName} ➔ ${SupportedLanguages.getByCode(item.targetLang).displayName}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GoogleTranslateTheme.PrimaryBlue
                                    )
                                    val hasSource = item.sourceAudioPath.isNotBlank()
                                    val hasTarget = item.targetAudioPath.isNotBlank()
                                    if (hasSource || hasTarget) {
                                        Text(
                                            if (hasSource && hasTarget) "🔊 双语就绪" else if (hasTarget) "🔊 译文就绪" else "🔊 原文就绪",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color(0xFF2E7D32)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.sourceText, fontSize = 14.sp, color = GoogleTranslateTheme.TextPrimary, maxLines = 2, modifier = Modifier.weight(1f))
                                    if (!isSelectMode) {
                                        val sourceKey = "hist_source_${item.id}"
                                        val isSourcePlaying = isPlaying && playingKey == sourceKey
                                        IconButton(
                                            onClick = { onTogglePlayAudio(sourceKey, item.sourceAudioPath, item.sourceText, item.sourceLang, false) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                if (isSourcePlaying) GoogleIcons.Stop else GoogleIcons.VolumeUp,
                                                contentDescription = if (isSourcePlaying) "暂停朗读原文" else "朗读原文",
                                                tint = if (isSourcePlaying) GoogleTranslateTheme.ActionRed else if (item.sourceAudioPath.isNotBlank()) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.translatedText, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = GoogleTranslateTheme.PrimaryBlueDark, maxLines = 2, modifier = Modifier.weight(1f))
                                    if (!isSelectMode) {
                                        val targetKey = "hist_target_${item.id}"
                                        val isTargetPlaying = isPlaying && playingKey == targetKey
                                        IconButton(
                                            onClick = { onTogglePlayAudio(targetKey, item.targetAudioPath, item.translatedText, item.targetLang, true) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                if (isTargetPlaying) GoogleIcons.Stop else GoogleIcons.VolumeUp,
                                                contentDescription = if (isTargetPlaying) "暂停朗读译文" else "朗读译文",
                                                tint = if (isTargetPlaying) GoogleTranslateTheme.ActionRed else if (item.targetAudioPath.isNotBlank()) GoogleTranslateTheme.PrimaryBlue else GoogleTranslateTheme.TextSecondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            if (!isSelectMode) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        val remaining = historyList.filter { it.id != item.id }
                                        preferencesManager.saveHistory(remaining)
                                        historyList = remaining
                                    }) {
                                        Icon(
                                            GoogleIcons.Delete,
                                            contentDescription = "删除此项",
                                            tint = Color.Gray.copy(alpha = 0.6f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 设置页面
 */
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    onSaved: () -> Unit
) {
    var apiKey by remember { mutableStateOf(preferencesManager.getApiKey()) }
    var baseUrl by remember { mutableStateOf(preferencesManager.getBaseUrl()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("翻译设置", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Gemini API Key", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text(
                    "用于文字互译、语音识别及词汇词组解析。",
                    fontSize = 12.sp,
                    color = GoogleTranslateTheme.TextSecondary
                )
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = GoogleTranslateTheme.CardBg),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("API 代理 Base URL", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GoogleTranslateTheme.TextPrimary)
                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    placeholder = { Text("https://generativelanguage.googleapis.com") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        }

        Button(
            onClick = {
                preferencesManager.saveApiKey(apiKey)
                preferencesManager.saveBaseUrl(baseUrl)
                onSaved()
            },
            colors = ButtonDefaults.buttonColors(containerColor = GoogleTranslateTheme.PrimaryBlue),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text("保存设置", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
