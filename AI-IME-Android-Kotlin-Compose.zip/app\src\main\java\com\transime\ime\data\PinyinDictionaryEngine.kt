package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 离线中文拼音与九宫格 T9 智能词库引擎
 * 包含了常用单字 (8105规范汉字高频字) + 现代汉语日常高频词汇 (3.5万+ 词组)
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private val pinyinMap = HashMap<String, List<String>>()
    private val t9Map = HashMap<String, List<String>>()
    private var isLoaded = false

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            context.assets.open("pinyin_dict.json").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    val content = reader.readText()
                    val root = JSONObject(content)

                    val pinyinObj = root.optJSONObject("pinyin")
                    if (pinyinObj != null) {
                        val keys = pinyinObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = pinyinObj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                list.add(arr.getString(i))
                            }
                            pinyinMap[key] = list
                        }
                    }

                    val t9Obj = root.optJSONObject("t9")
                    if (t9Obj != null) {
                        val keys = t9Obj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = t9Obj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                list.add(arr.getString(i))
                            }
                            t9Map[key] = list
                        }
                    }
                }
            }
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 26键拼音查询候选词
     */
    fun searchByPinyin(query: String): List<String> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()

        val exactMatches = pinyinMap[q]
        if (!exactMatches.isNullOrEmpty()) {
            return exactMatches
        }

        // 前缀匹配（当用户输入尚未完整时）
        val prefixMatches = mutableListOf<String>()
        var count = 0
        for ((key, words) in pinyinMap) {
            if (key.startsWith(q)) {
                for (w in words) {
                    if (w !in prefixMatches) {
                        prefixMatches.add(w)
                        count++
                        if (count >= 12) break
                    }
                }
            }
            if (count >= 12) break
        }

        return if (prefixMatches.isNotEmpty()) prefixMatches else listOf(q)
    }

    /**
     * 九宫格 T9 数字键查询候选词
     */
    fun searchByT9(digits: String): List<String> {
        val d = digits.trim()
        if (d.isEmpty()) return emptyList()

        val exactMatches = t9Map[d]
        if (!exactMatches.isNullOrEmpty()) {
            return exactMatches
        }

        // 前缀匹配
        val prefixMatches = mutableListOf<String>()
        var count = 0
        for ((key, words) in t9Map) {
            if (key.startsWith(d)) {
                for (w in words) {
                    if (w !in prefixMatches) {
                        prefixMatches.add(w)
                        count++
                        if (count >= 12) break
                    }
                }
            }
            if (count >= 12) break
        }

        return if (prefixMatches.isNotEmpty()) prefixMatches else listOf(d)
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
