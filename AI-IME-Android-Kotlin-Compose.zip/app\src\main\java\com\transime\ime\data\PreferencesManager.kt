package com.transime.ime.data

import android.content.Context
import android.content.SharedPreferences

enum class TranslationMode {
    ZH_EN,
    ZH_VI
}

/**
 * 管理输入法的本地配置持久化
 */
class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("trans_ime_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
        private const val KEY_CUSTOM_BASE_URL = "custom_gemini_base_url"
        private const val KEY_DEFAULT_MODE = "default_translation_mode"
        private const val KEY_TONE_PREF = "tone_preference"
        private const val KEY_VIETNAMESE_HONORIFIC = "vietnamese_honorific"
    }

    fun getCustomApiKey(): String = prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""

    fun saveCustomApiKey(key: String) {
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
    }

    fun getCustomBaseUrl(): String = prefs.getString(KEY_CUSTOM_BASE_URL, "https://generativelanguage.googleapis.com") ?: "https://generativelanguage.googleapis.com"

    fun saveCustomBaseUrl(url: String) {
        var cleanUrl = url.trim().removeSuffix("/")
        if (cleanUrl.isBlank()) cleanUrl = "https://generativelanguage.googleapis.com"
        prefs.edit().putString(KEY_CUSTOM_BASE_URL, cleanUrl).apply()
    }

    fun getDefaultServerApiKey(): String {
        // 内置默认备选 Key (生产环境建议通过后端反向代理或 BuildConfig 注入)
        return ""
    }

    fun getDefaultMode(): TranslationMode {
        val modeStr = prefs.getString(KEY_DEFAULT_MODE, TranslationMode.ZH_EN.name)
        return try {
            TranslationMode.valueOf(modeStr ?: TranslationMode.ZH_EN.name)
        } catch (e: Exception) {
            TranslationMode.ZH_EN
        }
    }

    fun saveDefaultMode(mode: TranslationMode) {
        prefs.edit().putString(KEY_DEFAULT_MODE, mode.name).apply()
    }

    fun getTonePreference(): String = prefs.getString(KEY_TONE_PREF, "colloquial") ?: "colloquial"

    fun getVietnameseHonorific(): String =
        prefs.getString(KEY_VIETNAMESE_HONORIFIC, "anh_em") ?: "anh_em"

    fun saveVietnameseHonorific(honorific: String) {
        prefs.edit().putString(KEY_VIETNAMESE_HONORIFIC, honorific).apply()
    }
}