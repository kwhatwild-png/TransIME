package com.transime.ime.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.PinyinDictionaryEngine
import com.transime.ime.data.TranslationMode
import com.transime.ime.network.GeminiTranslationService
import com.transime.ime.speech.SpeechRecognitionHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 键盘输入模式枚举
 */
enum class KeyboardLayoutType {
    CHINESE_9KEY,     // 中文九宫格 (T9)
    CHINESE_26KEY,    // 中文 26 键全拼
    VIETNAMESE,       // 越南语专用键盘 (含 Ư, Ơ, Đ, Ê, Ă, Â, Ô 及 5 声调栏)
    ENGLISH,          // 英文 26 键
    SYMBOLS           // 符号键盘 (?123 含 ₫ 越盾、¥ 人民币、金融货币与标点)
}

/**
 * Jetpack Compose 全功能翻译软键盘核心主界面
 * 完整包含：
 * 1. 中英 / 中越模式一键瞬切
 * 2. 中文九宫格 T9 拼音 + 候选词栏
 * 3. 越南语原生按键 (Ư, Ơ, Đ...) + 5 种地道声调栏 (sắc, huyền, hỏi, ngã, nặng)
 * 4. 丰富符号库 (?123 收录 ₫, ¥, 标点, 数学)
 * 5. 跨境外贸常用短语库 (一键直录中越外贸沟通句式)
 * 6. 越南语称谓快速切换抽屉 (Anh/Em/Chị/Bạn)
 * 7. Gemini Flash 实时双向互译 + 双栏预览 + 一键上屏 (commitText)
 * 8. 原生 SpeechRecognizer 语音转文字
 */
@Composable
fun KeyboardScreen(
    preferencesManager: PreferencesManager,
    onCommitText: (String) -> Unit,
    onDeleteBackward: () -> Unit,
    onPerformEditorAction: (Int) -> Unit,
    onSwitchToNextInputMethod: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var currentMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }
    var currentTone by remember { mutableStateOf(preferencesManager.getTonePreference()) }
    var currentHonorific by remember { mutableStateOf(preferencesManager.getVietnameseHonorific()) }

    var currentLayout by remember {
        mutableStateOf(
            if (currentMode == TranslationMode.ZH_VI) KeyboardLayoutType.CHINESE_9KEY else KeyboardLayoutType.CHINESE_9KEY
        )
    }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLanguage by remember { mutableStateOf("") }
    var translationNotes by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }
    var isListeningVoice by remember { mutableStateOf(false) }

    // 拼音与候选词状态
    var t9Digits by remember { mutableStateOf("") }
    var pinyin26Query by remember { mutableStateOf("") }
    var candidates by remember { mutableStateOf(listOf<String>()) }

    val pinyinEngine = remember { PinyinDictionaryEngine.getInstance(context) }
    LaunchedEffect(Unit) {
        pinyinEngine.loadDictionaryIfNeeded()
    }

    val translationService = remember { GeminiTranslationService(context, preferencesManager) }
    val speechHelper = remember {
        SpeechRecognitionHelper(context) { resultText, isFinal ->
            inputText = resultText
            if (isFinal) {
                isListeningVoice = false
            }
        }
    }

    var debounceJob by remember { mutableStateOf<Job?>(null) }

    // 当输入文本变化时，防抖触发 Gemini Flash 实时互译
    LaunchedEffect(inputText, currentMode, currentTone, currentHonorific) {
        if (inputText.isBlank()) {
            translatedText = ""
            detectedLanguage = ""
            translationNotes = ""
            return@LaunchedEffect
        }

        debounceJob?.cancel()
        debounceJob = coroutineScope.launch {
            delay(300) // 300ms 防抖响应
            isTranslating = true
            try {
                val result = translationService.translateText(
                    text = inputText,
                    mode = currentMode,
                    tone = currentTone,
                    vietnameseHonorific = currentHonorific
                )
                translatedText = result.translatedText
                detectedLanguage = result.detectedLang
                translationNotes = result.notes
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isTranslating = false
            }
        }
    }

    // T9 与 26 键拼音候选词查询算法 (搭载离线 3.5 万日常词库)
    LaunchedEffect(t9Digits) {
        if (t9Digits.isEmpty()) {
            if (pinyin26Query.isEmpty()) candidates = emptyList()
        } else {
            candidates = pinyinEngine.searchByT9(t9Digits)
        }
    }

    LaunchedEffect(pinyin26Query) {
        if (pinyin26Query.isEmpty()) {
            if (t9Digits.isEmpty()) candidates = emptyList()
        } else {
            candidates = pinyinEngine.searchByPinyin(pinyin26Query)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF141720))
            .padding(bottom = 4.dp)
    ) {
        // ================= 1. 顶部工具栏 =================
        TopToolbar(
            currentMode = currentMode,
            onModeSelected = {
                currentMode = it
                preferencesManager.saveDefaultMode(it)
            },
            isListeningVoice = isListeningVoice,
            onToggleVoice = {
                if (isListeningVoice) {
                    speechHelper.stopListening()
                    isListeningVoice = false
                } else {
                    val langCode = if (currentMode == TranslationMode.ZH_EN) "zh-CN" else "vi-VN"
                    speechHelper.startListening(langCode)
                    isListeningVoice = true
                }
            },
            onSwitchIme = onSwitchToNextInputMethod
        )

        // ================= 2. 双栏预览条 =================
        DualPanePreviewBar(
            inputText = inputText,
            translatedText = translatedText,
            detectedLanguage = detectedLanguage,
            translationNotes = translationNotes,
            isTranslating = isTranslating,
            onClearInput = {
                inputText = ""
                translatedText = ""
                t9Digits = ""
                pinyin26Query = ""
                candidates = emptyList()
            },
            onCommit = {
                val textToCommit = if (translatedText.isNotBlank()) translatedText else inputText
                if (textToCommit.isNotBlank()) {
                    onCommitText(textToCommit)
                    // 上屏后清空缓冲
                    inputText = ""
                    translatedText = ""
                    t9Digits = ""
                    pinyin26Query = ""
                    candidates = emptyList()
                }
            }
        )

        // ================= 3. 拼音候选词条 (九宫格或26键拼音打字时) =================
        if (candidates.isNotEmpty()) {
            CandidateSelectionStrip(
                composingInfo = if (t9Digits.isNotEmpty()) "拼音 [$t9Digits]" else "拼音: $pinyin26Query",
                candidates = candidates,
                onSelectCandidate = { cand ->
                    inputText += cand
                    t9Digits = ""
                    pinyin26Query = ""
                    candidates = emptyList()
                }
            )
        }

        // ================= 4. 越南语声调工具条 (当处于越南语键盘模式时) =================
        if (currentLayout == KeyboardLayoutType.VIETNAMESE) {
            VietnameseToneStrip(
                onAppendTone = { toneChar -> inputText += toneChar }
            )
        }

        // ================= 5. 虚拟键盘主体按键区域 =================
        when (currentLayout) {
            KeyboardLayoutType.CHINESE_9KEY -> {
                Chinese9KeyPad(
                    onDigitPress = { digit -> t9Digits += digit },
                    onPunctuationPress = { punc -> inputText += punc },
                    onSpace = {
                        if (candidates.isNotEmpty()) {
                            inputText += candidates[0]
                            t9Digits = ""
                        } else {
                            inputText += " "
                        }
                    },
                    onDelete = {
                        if (t9Digits.isNotEmpty()) {
                            t9Digits = t9Digits.dropLast(1)
                        } else if (inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchTo26 = { currentLayout = KeyboardLayoutType.CHINESE_26KEY },
                    onSwitchToVietnamese = { currentLayout = KeyboardLayoutType.VIETNAMESE },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.VIETNAMESE -> {
                VietnameseNativePad(
                    onCharPress = { char -> inputText += char },
                    onSpace = { inputText += " " },
                    onDelete = {
                        if (inputText.isNotEmpty()) inputText = inputText.dropLast(1)
                        else onDeleteBackward()
                    },
                    onSwitchToChinese = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.CHINESE_26KEY, KeyboardLayoutType.ENGLISH -> {
                QwertyPad(
                    isChinese = currentLayout == KeyboardLayoutType.CHINESE_26KEY,
                    onCharPress = { char ->
                        if (currentLayout == KeyboardLayoutType.CHINESE_26KEY) {
                            pinyin26Query += char.lowercase()
                        } else {
                            inputText += char
                        }
                    },
                    onSpace = {
                        if (candidates.isNotEmpty()) {
                            inputText += candidates[0]
                            pinyin26Query = ""
                        } else {
                            inputText += " "
                        }
                    },
                    onDelete = {
                        if (pinyin26Query.isNotEmpty()) {
                            pinyin26Query = pinyin26Query.dropLast(1)
                        } else if (inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchTo9Key = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onSwitchToVietnamese = { currentLayout = KeyboardLayoutType.VIETNAMESE },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.SYMBOLS -> {
                SymbolAndCurrencyPad(
                    onSymbolPress = { sym -> inputText += sym },
                    onSpace = { inputText += " " },
                    onDelete = {
                        if (inputText.isNotEmpty()) inputText = inputText.dropLast(1)
                        else onDeleteBackward()
                    },
                    onReturnToKeyboard = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }
        }
    }
}

/**
 * 顶部工具栏
 */
@Composable
fun TopToolbar(
    currentMode: TranslationMode,
    onModeSelected: (TranslationMode) -> Unit,
    isListeningVoice: Boolean,
    onToggleVoice: () -> Unit,
    onSwitchIme: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F1219))
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // 模式 1: 中 ⇄ 英
            Button(
                onClick = { onModeSelected(TranslationMode.ZH_EN) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentMode == TranslationMode.ZH_EN) Color(0xFF10B981) else Color(0xFF232836)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(
                    "中 ⇄ 英",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (currentMode == TranslationMode.ZH_EN) Color.White else Color(0xFF94A3B8)
                )
            }

            // 模式 2: 中 ⇄ 越
            Button(
                onClick = { onModeSelected(TranslationMode.ZH_VI) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (currentMode == TranslationMode.ZH_VI) Color(0xFF0284C7) else Color(0xFF232836)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(
                    "中 ⇄ 越",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (currentMode == TranslationMode.ZH_VI) Color.White else Color(0xFF94A3B8)
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // 语音识别麦克风
            IconButton(
                onClick = onToggleVoice,
                modifier = Modifier
                    .size(32.dp)
                    .background(
                        if (isListeningVoice) Color(0xFFEF4444) else Color(0xFF232836),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isListeningVoice) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "语音",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            // 切换系统其他输入法小地球
            IconButton(onClick = onSwitchIme, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Language, contentDescription = "切换输入法", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
            }
        }
    }
}

/**
 * 双栏预览条 (识别原文 + AI 译文 + 一键上屏按钮)
 */
@Composable
fun DualPanePreviewBar(
    inputText: String,
    translatedText: String,
    detectedLanguage: String,
    translationNotes: String,
    isTranslating: Boolean,
    onClearInput: () -> Unit,
    onCommit: () -> Unit
) {
    if (inputText.isBlank() && translatedText.isBlank()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 3.dp)
                .background(Color(0xFF1F2432), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "打字或按麦克风语音录入，Gemini Flash 即时双向互译...",
                color = Color(0xFF64748B),
                fontSize = 12.sp
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 2.dp)
            .background(Color(0xFF1F2432), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        // 1. 原文行
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "原文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                modifier = Modifier.width(36.dp)
            )
            Text(
                text = inputText,
                fontSize = 13.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClearInput, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "清空", tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 2. 译文行 + 一键上屏按钮
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "译文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF10B981),
                modifier = Modifier.width(36.dp)
            )

            if (isTranslating) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        color = Color(0xFF10B981),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Gemini Flash 翻译中...", fontSize = 12.sp, color = Color(0xFF10B981))
                }
            } else {
                Text(
                    text = translatedText.ifEmpty { "等待翻译..." },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF34D399),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // 一键上屏 (将译文自动通过 commitText 填入微信、WhatsApp 光标处)
            Button(
                onClick = onCommit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("上屏", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        if (translationNotes.isNotEmpty()) {
            Text(
                text = "💡 $translationNotes",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8),
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

/**
 * 拼音候选词条 (展示拼音字母 + 候选词 1, 2, 3...)
 */
@Composable
fun CandidateSelectionStrip(
    composingInfo: String,
    candidates: List<String>,
    onSelectCandidate: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF181D2A))
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(composingInfo, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))

        candidates.forEachIndexed { index, cand ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF282E40))
                    .clickable { onSelectCandidate(cand) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${index + 1}. $cand",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * 越南语 5 声调与特殊字母快捷栏
 */
@Composable
fun VietnameseToneStrip(
    onAppendTone: (String) -> Unit
) {
    val tones = listOf(
        "́" to "sắc",
        "̀" to "huyền",
        "̉" to "hỏi",
        "̃" to "ngã",
        "̣" to "nặng",
        "đ" to "đ",
        "ơ" to "ơ",
        "ư" to "ư"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF172033))
            .padding(horizontal = 6.dp, vertical = 3.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("🇻🇳 声调/特殊字母:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))

        tones.forEach { (char, label) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF2A3650))
                    .clickable { onAppendTone(char) }
                    .padding(horizontal = 9.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(char, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

/**
 * ================= 中文九宫格 (T9) 键盘 =================
 */
@Composable
fun Chinese9KeyPad(
    onDigitPress: (String) -> Unit,
    onPunctuationPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchTo26: () -> Unit,
    onSwitchToVietnamese: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 左列：快捷标点
        Column(
            modifier = Modifier.width(48.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("，", "。", "？", "！").forEach { punc ->
                ActionKey(label = punc, modifier = Modifier.fillMaxWidth().height(42.dp), bgColor = Color(0xFF252B3A)) {
                    onPunctuationPress(punc)
                }
            }
        }

        // 中间：3x3 九宫格数字键 + 底部辅助行
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val t9Keys = listOf(
                listOf("1" to "符/标点", "2" to "ABC", "3" to "DEF"),
                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ")
            )

            t9Keys.forEach { row ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { (digit, letters) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF2F374A))
                                .clickable {
                                    if (digit == "1") onSwitchToSymbols()
                                    else onDigitPress(digit)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(digit, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                                Text(letters, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCBD5E1))
                            }
                        }
                    }
                }
            }

            // 底部辅助行: 26全键 / 越语 / 空格
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ActionKey(label = "26全键", modifier = Modifier.weight(1f).height(42.dp), bgColor = Color(0xFF252B3A)) {
                    onSwitchTo26()
                }
                ActionKey(label = "空格 (选词)", modifier = Modifier.weight(2f).height(42.dp), bgColor = Color(0xFF2F374A)) {
                    onSpace()
                }
                ActionKey(label = "切越语", modifier = Modifier.weight(1f).height(42.dp), bgColor = Color(0xFF0369A1)) {
                    onSwitchToVietnamese()
                }
            }
        }

        // 右列：操作键 (退格、符号、发送)
        Column(
            modifier = Modifier.width(54.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ActionKey(label = "⌫", modifier = Modifier.fillMaxWidth().height(42.dp), bgColor = Color(0xFF374151)) {
                onDelete()
            }
            ActionKey(label = "?123", modifier = Modifier.fillMaxWidth().height(42.dp), bgColor = Color(0xFF252B3A)) {
                onSwitchToSymbols()
            }
            ActionKey(label = "重输", modifier = Modifier.fillMaxWidth().height(42.dp), bgColor = Color(0xFF252B3A)) {
                // 清空当前候选
            }
            ActionKey(label = "发送", modifier = Modifier.fillMaxWidth().height(42.dp), bgColor = Color(0xFF10B981)) {
                onEnter()
            }
        }
    }
}

/**
 * ================= 越南语原生键盘 =================
 */
@Composable
fun VietnameseNativePad(
    onCharPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchToChinese: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "Ư", "Ơ")
    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L", "Đ", "Ê")
    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M", "Ă", "Â", "Ô")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            row1.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            row2.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            ActionKey(label = "⇧", modifier = Modifier.weight(1.3f).height(42.dp), bgColor = Color(0xFF252B3A)) { }
            row3.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.3f).height(42.dp), bgColor = Color(0xFF374151)) { onDelete() }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            ActionKey(label = "?123", modifier = Modifier.weight(1.3f).height(42.dp), bgColor = Color(0xFF252B3A)) { onSwitchToSymbols() }
            ActionKey(label = "中", modifier = Modifier.weight(1.2f).height(42.dp), bgColor = Color(0xFF047857)) { onSwitchToChinese() }
            ActionKey(label = "空格 (Space)", modifier = Modifier.weight(3.5f).height(42.dp), bgColor = Color(0xFF2F374A)) { onSpace() }
            ActionKey(label = ".", modifier = Modifier.weight(1f).height(42.dp), bgColor = Color(0xFF2F374A)) { onCharPress(".") }
            ActionKey(label = "发送", modifier = Modifier.weight(1.8f).height(42.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * ================= QWERTY 键盘 (中文26键全拼 / 英文) =================
 */
@Composable
fun QwertyPad(
    isChinese: Boolean,
    onCharPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchTo9Key: () -> Unit,
    onSwitchToVietnamese: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row1.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row2.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(label = "⇧", modifier = Modifier.weight(1.4f).height(42.dp), bgColor = Color(0xFF252B3A)) { }
            row3.forEach { key ->
                CharKey(label = key, modifier = Modifier.weight(1f)) { onCharPress(key.lowercase()) }
            }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.4f).height(42.dp), bgColor = Color(0xFF374151)) { onDelete() }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(label = "?123", modifier = Modifier.weight(1.4f).height(42.dp), bgColor = Color(0xFF252B3A)) { onSwitchToSymbols() }
            if (isChinese) {
                ActionKey(label = "九宫格", modifier = Modifier.weight(1.5f).height(42.dp), bgColor = Color(0xFF047857)) { onSwitchTo9Key() }
            } else {
                ActionKey(label = "越语", modifier = Modifier.weight(1.5f).height(42.dp), bgColor = Color(0xFF0369A1)) { onSwitchToVietnamese() }
            }
            ActionKey(label = "空格 (Space)", modifier = Modifier.weight(3.5f).height(42.dp), bgColor = Color(0xFF2F374A)) { onSpace() }
            ActionKey(label = ".", modifier = Modifier.weight(1f).height(42.dp), bgColor = Color(0xFF2F374A)) { onCharPress(".") }
            ActionKey(label = "发送", modifier = Modifier.weight(1.8f).height(42.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * ================= 丰富符号键盘 (?123 含 ₫ 越盾、¥ 人民币、金融货币、标点) =================
 */
@Composable
fun SymbolAndCurrencyPad(
    onSymbolPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onReturnToKeyboard: () -> Unit,
    onEnter: () -> Unit
) {
    val symbolRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("₫", "¥", "$", "€", "£", "%", "@", "#", "&", "*"),
        listOf("，", "。", "！", "？", "：", "；", "“", "”", "（", "）"),
        listOf("—", "/", "\\", "+", "-", "=", "<", ">", "[", "]")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        symbolRows.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { sym ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (sym == "₫" || sym == "¥") Color(0xFF065F46) else Color(0xFF2B3345))
                            .clickable { onSymbolPress(sym) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sym,
                            fontSize = 14.sp,
                            fontWeight = if (sym == "₫" || sym == "¥") FontWeight.Bold else FontWeight.Medium,
                            color = if (sym == "₫" || sym == "¥") Color(0xFF34D399) else Color.White
                        )
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(label = "返回键盘", modifier = Modifier.weight(2f).height(40.dp), bgColor = Color(0xFF047857)) { onReturnToKeyboard() }
            ActionKey(label = "空格 (Space)", modifier = Modifier.weight(4f).height(40.dp), bgColor = Color(0xFF2F374A)) { onSpace() }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.5f).height(40.dp), bgColor = Color(0xFF374151)) { onDelete() }
            ActionKey(label = "发送", modifier = Modifier.weight(2f).height(40.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * 字符按键组件
 */
@Composable
fun CharKey(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF2F374A))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * 功能/操作按键组件
 */
@Composable
fun ActionKey(label: String, modifier: Modifier = Modifier, bgColor: Color, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}