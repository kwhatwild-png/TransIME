package com.transime.ime

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import com.transime.ime.ui.AppIcons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.TranslationMode

/**
 * 主应用配置页 Activity (搜狗输入法小米版专属配色风格管理面板)
 */
class MainActivity : ComponentActivity() {

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferencesManager = PreferencesManager(applicationContext)

        setContent {
            MaterialTheme {
                SettingsScreen(
                    preferencesManager = preferencesManager,
                    onOpenSystemImeSettings = {
                        try {
                            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    },
                    onOpenImePicker = {
                        try {
                            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                            imm?.showInputMethodPicker()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                )
            }
        }
    }
}

private object SogouThemeColors {
    val PageBg = Color(0xFFF2F4F7)             // 搜狗浅灰底色
    val CardBg = Color(0xFFFFFFFF)             // 白色卡片底色
    val TextPrimary = Color(0xFF1E293B)        // 主标题深色
    val TextSecondary = Color(0xFF64748B)      // 次级提示色
    val BrandOrange = Color(0xFFF56400)        // 搜狗经典活力橙
    val BrandBlue = Color(0xFF0284C7)          // 科技蓝
    val DividerColor = Color(0xFFF1F5F9)       // 分割线
    val KeyBg = Color(0xFFE5E7EB)              // 按钮微灰底色
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    preferencesManager: PreferencesManager,
    onOpenSystemImeSettings: () -> Unit,
    onOpenImePicker: () -> Unit
) {
    var apiKey by remember { mutableStateOf(preferencesManager.getCustomApiKey()) }
    var baseUrl by remember { mutableStateOf(preferencesManager.getCustomBaseUrl()) }
    var defaultMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }
    var isFuzzyEnabled by remember { mutableStateOf(preferencesManager.isFuzzyPinyinEnabled()) }
    var savedMessageVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SogouThemeColors.PageBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // 顶部品牌标题
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(SogouThemeColors.BrandOrange),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    AppIcons.Translate,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    "AI 输入法设置",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Text(
                    "搜狗键盘小米版 1:1 体验 · Gemini 极速互译",
                    fontSize = 12.sp,
                    color = SogouThemeColors.TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 步骤 1: 启用输入法服务
        Card(
            colors = CardDefaults.cardColors(containerColor = SogouThemeColors.CardBg),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "第一步：在系统设置中启用",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "在小米/澎湃OS或Android系统输入法列表中开启【AI输入法】。",
                    fontSize = 12.sp,
                    color = SogouThemeColors.TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onOpenSystemImeSettings,
                    colors = ButtonDefaults.buttonColors(containerColor = SogouThemeColors.BrandOrange),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                ) {
                    Icon(AppIcons.Settings, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("前往系统设置启用输入法", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 步骤 2: 切换当前输入法
        Card(
            colors = CardDefaults.cardColors(containerColor = SogouThemeColors.CardBg),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "第二步：选择当前默认输入法",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "弹出系统输入法列表勾选 AI 输入法；键盘左下角支持一键快捷呼出随时切换。",
                    fontSize = 12.sp,
                    color = SogouThemeColors.TextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onOpenImePicker,
                    colors = ButtonDefaults.buttonColors(containerColor = SogouThemeColors.BrandBlue),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                ) {
                    Icon(AppIcons.XiaomiImeSwitch, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("弹出输入法切换窗口", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 搜狗级：拼音与打字设置（模糊音开关固化）
        Card(
            colors = CardDefaults.cardColors(containerColor = SogouThemeColors.CardBg),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "拼音输入与纠错设置",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "搜狗级模糊拼音纠错",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = SogouThemeColors.TextPrimary
                        )
                        Text(
                            "自动纠正 z/zh, c/ch, s/sh 平翘舌与前后鼻音",
                            fontSize = 11.sp,
                            color = SogouThemeColors.TextSecondary
                        )
                    }
                    Switch(
                        checked = isFuzzyEnabled,
                        onCheckedChange = {
                            isFuzzyEnabled = it
                            preferencesManager.setFuzzyPinyinEnabled(it)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = SogouThemeColors.BrandOrange
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 默认翻译模式设置
        Card(
            colors = CardDefaults.cardColors(containerColor = SogouThemeColors.CardBg),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "默认翻译模式",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = defaultMode == TranslationMode.ZH_VI,
                        onClick = {
                            defaultMode = TranslationMode.ZH_VI
                            preferencesManager.saveDefaultMode(TranslationMode.ZH_VI)
                        },
                        label = { Text("🇻🇳 中 ⇄ 越 (默认)") }
                    )
                    FilterChip(
                        selected = defaultMode == TranslationMode.ZH_EN,
                        onClick = {
                            defaultMode = TranslationMode.ZH_EN
                            preferencesManager.saveDefaultMode(TranslationMode.ZH_EN)
                        },
                        label = { Text("🇬🇧 中 ⇄ 英") }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Gemini Flash API 配置
        Card(
            colors = CardDefaults.cardColors(containerColor = SogouThemeColors.CardBg),
            shape = RoundedCornerShape(14.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "Gemini Flash API 配置",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = SogouThemeColors.TextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "采用 Google Gemini 极速模型进行自然语言高精度互译：",
                    fontSize = 12.sp,
                    color = SogouThemeColors.TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = SogouThemeColors.TextPrimary,
                        unfocusedTextColor = SogouThemeColors.TextPrimary,
                        cursorColor = SogouThemeColors.BrandOrange,
                        focusedBorderColor = SogouThemeColors.BrandOrange
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    label = { Text("API 基础地址 (支持中转反代)") },
                    placeholder = { Text("https://generativelanguage.googleapis.com") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = SogouThemeColors.TextPrimary,
                        unfocusedTextColor = SogouThemeColors.TextPrimary,
                        cursorColor = SogouThemeColors.BrandOrange,
                        focusedBorderColor = SogouThemeColors.BrandOrange
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        preferencesManager.saveCustomApiKey(apiKey)
                        preferencesManager.saveCustomBaseUrl(baseUrl)
                        savedMessageVisible = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SogouThemeColors.BrandOrange),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(42.dp)
                ) {
                    Text("保存 API 配置", color = Color.White, fontWeight = FontWeight.Bold)
                }

                if (savedMessageVisible) {
                    Text(
                        "已成功保存 API 配置！",
                        color = Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}
