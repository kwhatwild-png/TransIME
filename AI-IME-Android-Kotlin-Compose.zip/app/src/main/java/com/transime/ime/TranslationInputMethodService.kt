package com.transime.ime

import android.content.Context
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.transime.ime.data.PreferencesManager
import com.transime.ime.ui.KeyboardScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * 实时中英/中越翻译输入法服务
 * 继承自 Android InputMethodService，支持在微信、WhatsApp、浏览器等任意 App 调起
 */
class TranslationInputMethodService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performAttach()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        preferencesManager = PreferencesManager(applicationContext)
    }

    override fun onCreateInputView(): View {
        // 双重保障生命周期与状态树挂载到 Window DecorView
        window?.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }

        val composeView = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnLifecycleDestroyed(this@TranslationInputMethodService.lifecycle))
            setViewTreeLifecycleOwner(this@TranslationInputMethodService)
            setViewTreeViewModelStoreOwner(this@TranslationInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@TranslationInputMethodService)

            setContent {
                KeyboardScreen(
                    preferencesManager = preferencesManager,
                    onCommitText = { text -> commitTextToApp(text) },
                    onDeleteBackward = { deleteBackward() },
                    onDeleteAll = { deleteAllInputText() },
                    onMoveCursorLeft = { moveCursor(-1) },
                    onMoveCursorRight = { moveCursor(1) },
                    onCopyText = { copyText() },
                    onCutText = { cutText() },
                    onPasteText = { pasteText() },
                    onPerformEditorAction = { actionId -> performEditorAction(actionId) },
                    onSwitchToNextInputMethod = {
                        try {
                            currentInputConnection?.finishComposingText()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }

                        // 小米/MIUI/澎湃OS双轨切换：优先弹出系统全局输入法选择器 (无缝在百度/微信/搜狗与本输入法之间切换)
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        var pickerShown = false
                        try {
                            imm?.showInputMethodPicker()
                            pickerShown = true
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }

                        // 如果在特定系统版本或权限受限下弹窗未触发，则无缝 fallback 到直接链式切换
                        if (!pickerShown) {
                            try {
                                var switched = false
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                    switched = switchToPreviousInputMethod()
                                    if (!switched) {
                                        switched = switchToNextInputMethod(false)
                                    }
                                }
                                if (!switched) {
                                    switchToNextInputMethod(false)
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    },
                    onOpenSettings = {
                        try {
                            val intent = Intent(this@TranslationInputMethodService, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                )
            }
        }
        return composeView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // 确保生命周期状态流转按顺序推进
        if (lifecycleRegistry.currentState == Lifecycle.State.INITIALIZED) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        }
        if (lifecycleRegistry.currentState == Lifecycle.State.CREATED) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        }
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        // 在输入面板隐藏时回退状态，避免过度销毁导致无法再次启动
        if (lifecycleRegistry.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        }
    }

    /**
     * 一键上屏：通过 InputConnection.commitText 将译文填入当前宿主 App 光标位置
     */
    private fun commitTextToApp(text: String) {
        val ic: InputConnection? = currentInputConnection
        if (ic != null && text.isNotEmpty()) {
            ic.commitText(text, 1)
        }
    }

    /**
     * 单字退格删除
     */
    private fun deleteBackward() {
        val ic: InputConnection? = currentInputConnection
        ic?.deleteSurroundingText(1, 0)
    }

    /**
     * 清空删除当前行或所有已输文本 (长按删除键时调用)
     */
    private fun deleteAllInputText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText("", 0)
        ic.deleteSurroundingText(2000, 2000)
    }

    /**
     * 光标左移或右移定位
     */
    private fun moveCursor(offset: Int) {
        val ic: InputConnection = currentInputConnection ?: return
        try {
            val extracted = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
            if (extracted != null) {
                val currentSel = extracted.selectionStart
                val newSel = (currentSel + offset).coerceIn(0, extracted.text.length)
                ic.setSelection(newSel, newSel)
                return
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val keyCode = if (offset < 0) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
    }

    private fun copyText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.copy)
    }

    private fun cutText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.cut)
    }

    private fun pasteText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.paste)
    }

    private fun performEditorAction(actionId: Int) {
        val ic: InputConnection? = currentInputConnection
        ic?.performEditorAction(actionId)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        serviceScope.cancel()
    }
}
