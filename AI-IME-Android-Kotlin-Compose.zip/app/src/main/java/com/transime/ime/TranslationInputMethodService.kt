package com.transime.ime

import android.inputmethodservice.InputMethodService
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.transime.ime.data.PreferencesManager
import com.transime.ime.ui.KeyboardScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * 实时中英/中越翻译输入法服务
 * 继承自 Android InputMethodService，支持在微信、WhatsApp、浏览器等任意 App 调起
 */
class TranslationInputMethodService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        preferencesManager = PreferencesManager(applicationContext)
    }

    override fun onCreateInputView(): View {
        // 将输入法宿主生命周期和状态树挂载到 Window DecorView 与 ComposeView
        window?.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }

        val composeView = ComposeView(this).apply {
            // 装配 Jetpack Compose 在 Service 中的生命周期与状态树
            setViewTreeLifecycleOwner(this@TranslationInputMethodService)
            setViewTreeViewModelStoreOwner(this@TranslationInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@TranslationInputMethodService)

            setContent {
                KeyboardScreen(
                    preferencesManager = preferencesManager,
                    onCommitText = { text -> commitTextToApp(text) },
                    onDeleteBackward = { deleteBackward() },
                    onDeleteAll = { deleteAllInputText() },
                    onMoveCursorLeft = { moveCursor(-1) },
                    onMoveCursorRight = { moveCursor(1) },
                    onCopyText = { copyText() },
                    onCutText = { cutText() },
                    onPasteText = { pasteText() },
                    onPerformEditorAction = { actionId -> performEditorAction(actionId) },
                    onSwitchToNextInputMethod = {
                        // 自由切换输入法：优先 switchToNextInputMethod，失败则弹出系统选择框
                        var switched = false
                        try {
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                                switched = switchToNextInputMethod(false)
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }

                        if (!switched) {
                            try {
                                val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                                imm?.showInputMethodPicker()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                )
            }
        }
        return composeView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    /**
     * 一键上屏：通过 InputConnection.commitText 将译文填入当前宿主 App 光标位置
     */
    private fun commitTextToApp(text: String) {
        val ic: InputConnection? = currentInputConnection
        if (ic != null && text.isNotEmpty()) {
            ic.commitText(text, 1)
        }
    }

    /**
     * 单字退格删除
     */
    private fun deleteBackward() {
        val ic: InputConnection? = currentInputConnection
        ic?.deleteSurroundingText(1, 0)
    }

    /**
     * 清空删除当前行或所有已输文本 (长按删除键时调用)
     */
    private fun deleteAllInputText() {
        val ic: InputConnection = currentInputConnection ?: return
        // 1. 先尝试全选并清除
        ic.performContextMenuAction(android.R.id.selectAll)
        ic.commitText("", 0)
        // 2. 双保险：向左向右强力删除光标周围 2000 字符
        ic.deleteSurroundingText(2000, 2000)
    }

    /**
     * 光标左移或右移定位
     */
    private fun moveCursor(offset: Int) {
        val ic: InputConnection = currentInputConnection ?: return
        // 尝试通过 getExtractedText 移动光标选择，如果不可行则发送 DPAD 移动键
        try {
            val extracted = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
            if (extracted != null) {
                val currentSel = extracted.selectionStart
                val newSel = (currentSel + offset).coerceIn(0, extracted.text.length)
                ic.setSelection(newSel, newSel)
                return
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 备用方案：发送标准 DPAD 方向键
        val keyCode = if (offset < 0) android.view.KeyEvent.KEYCODE_DPAD_LEFT else android.view.KeyEvent.KEYCODE_DPAD_RIGHT
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode))
        ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode))
    }

    /**
     * 复制文本
     */
    private fun copyText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.copy)
    }

    /**
     * 剪切文本
     */
    private fun cutText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.cut)
    }

    /**
     * 粘贴文本
     */
    private fun pasteText() {
        val ic: InputConnection = currentInputConnection ?: return
        ic.performContextMenuAction(android.R.id.paste)
    }

    /**
     * 执行回车或发送 Action (如微信发送、搜索、换行等)
     */
    private fun performEditorAction(actionId: Int) {
        val ic: InputConnection? = currentInputConnection
        ic?.performEditorAction(actionId)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()
    }
}