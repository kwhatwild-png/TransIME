package com.transime.ime.data



import android.content.Context

import android.content.SharedPreferences



enum class TranslationMode {

    ZH_EN,

    ZH_VI

}



/**

 * 管理输入法的本地配置持久化

 */

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =

        context.getSharedPreferences("trans_ime_prefs", Context.MODE_PRIVATE)



    companion object {

        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"

        private const val KEY_CUSTOM_BASE_URL = "custom_gemini_base_url"

        private const val KEY_DEFAULT_MODE = "default_translation_mode"

        private const val KEY_TRANSLATE_ENABLED = "translate_enabled"

        private const val KEY_TONE_PREF = "tone_preference"

        private const val KEY_VIETNAMESE_HONORIFIC = "vietnamese_honorific"

        private const val KEY_FUZZY_PINYIN_ENABLED = "fuzzy_pinyin_enabled"

        private const val KEY_LAST_KEYBOARD_LAYOUT = "last_keyboard_layout"

    }



    /**

     * 持久化当前键盘布局 (九宫格 / 26键拼音 / 英文 / 越语 / 符号)，退出或切应用不丢失

     */

    fun getLastKeyboardLayout(): String = prefs.getString(KEY_LAST_KEYBOARD_LAYOUT, "CHINESE_9KEY") ?: "CHINESE_9KEY"



    fun setLastKeyboardLayout(layoutName: String) {

        prefs.edit().putString(KEY_LAST_KEYBOARD_LAYOUT, layoutName).apply()

    }



    fun isTranslateEnabled(): Boolean = prefs.getBoolean(KEY_TRANSLATE_ENABLED, false)



    fun setTranslateEnabled(enabled: Boolean) {

        prefs.edit().putBoolean(KEY_TRANSLATE_ENABLED, enabled).apply()

    }



    /**

     * 搜狗级模糊拼音开关 (默认开启，平翘舌 z/zh、c/ch、s/sh、前后鼻音 an/ang、en/eng、in/ing、l/n、f/h 智能纠错)

     */

    fun isFuzzyPinyinEnabled(): Boolean = prefs.getBoolean(KEY_FUZZY_PINYIN_ENABLED, true)



    fun setFuzzyPinyinEnabled(enabled: Boolean) {

        prefs.edit().putBoolean(KEY_FUZZY_PINYIN_ENABLED, enabled).apply()

    }



    fun getCustomApiKey(): String = prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""



    fun saveCustomApiKey(key: String) {

        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()

    }



    fun getCustomBaseUrl(): String = prefs.getString(KEY_CUSTOM_BASE_URL, "https://generativelanguage.googleapis.com") ?: "https://generativelanguage.googleapis.com"



    fun saveCustomBaseUrl(url: String) {

        var cleanUrl = url.trim().removeSuffix("/")

        if (cleanUrl.isBlank()) cleanUrl = "https://generativelanguage.googleapis.com"

        prefs.edit().putString(KEY_CUSTOM_BASE_URL, cleanUrl).apply()

    }



    fun getDefaultServerApiKey(): String {

        return ""

    }



    fun getDefaultMode(): TranslationMode {

        val modeStr = prefs.getString(KEY_DEFAULT_MODE, TranslationMode.ZH_VI.name)

        return try {

            TranslationMode.valueOf(modeStr ?: TranslationMode.ZH_VI.name)

        } catch (e: Exception) {

            TranslationMode.ZH_VI

        }

    }



    fun saveDefaultMode(mode: TranslationMode) {

        prefs.edit().putString(KEY_DEFAULT_MODE, mode.name).apply()

    }



    fun getTonePreference(): String = prefs.getString(KEY_TONE_PREF, "colloquial") ?: "colloquial"



    fun getVietnameseHonorific(): String =

        prefs.getString(KEY_VIETNAMESE_HONORIFIC, "anh_em") ?: "anh_em"



    fun saveVietnameseHonorific(honorific: String) {

        prefs.edit().putString(KEY_VIETNAMESE_HONORIFIC, honorific).apply()

    }

}

