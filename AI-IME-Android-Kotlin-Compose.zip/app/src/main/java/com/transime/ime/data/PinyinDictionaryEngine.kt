package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 离线中文拼音与九宫格 T9 智能词库引擎
 * 支持长拼音连打分词、常用单字、高频词汇组合
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private val pinyinMap = HashMap<String, List<String>>()
    private val t9Map = HashMap<String, List<String>>()
    private var isLoaded = false

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            context.assets.open("pinyin_dict.json").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    val content = reader.readText()
                    val root = JSONObject(content)

                    val pinyinObj = root.optJSONObject("pinyin")
                    if (pinyinObj != null) {
                        val keys = pinyinObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = pinyinObj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                // 过滤掉注释标记如 "法嗯 -> ǹg"
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            pinyinMap[key] = list
                        }
                    }

                    val t9Obj = root.optJSONObject("t9")
                    if (t9Obj != null) {
                        val keys = t9Obj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = t9Obj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            t9Map[key] = list
                        }
                    }
                }
            }
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 26键拼音连打候选词搜索 (支持任意长度长拼音分词切分组合)
     */
    fun searchByPinyin(query: String): List<String> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()

        val results = mutableListOf<String>()

        // 1. 完全精确匹配
        val exact = pinyinMap[q]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        // 2. 长拼音双词切分 (贪婪最长前缀优先)
        val n = q.length
        if (n >= 4) {
            for (i in (n - 1) downTo 2) {
                val w1 = pinyinMap[q.substring(0, i)]
                if (!w1.isNullOrEmpty()) {
                    val w2 = pinyinMap[q.substring(i)]
                    if (!w2.isNullOrEmpty()) {
                        for (a in w1.take(3)) {
                            for (b in w2.take(3)) {
                                val comb = a + b
                                if (comb !in results) {
                                    results.add(comb)
                                    if (results.size >= 16) return results
                                }
                            }
                        }
                    }
                }
            }

            // 3. 长拼音三词切分 (例如: womendou / jintianchifan / xiabanhuijia)
            if (n >= 6 && results.size < 10) {
                for (i in 2 until (n - 2)) {
                    val w1 = pinyinMap[q.substring(0, i)] ?: continue
                    for (j in (i + 2) until n) {
                        val w2 = pinyinMap[q.substring(i, j)] ?: continue
                        val w3 = pinyinMap[q.substring(j)] ?: continue
                        val comb = w1[0] + w2[0] + w3[0]
                        if (comb !in results) {
                            results.add(comb)
                            if (results.size >= 16) return results
                        }
                    }
                }
            }
        }

        // 4. 前缀联想匹配 (输入尚未完整时)
        if (results.size < 8) {
            for ((key, words) in pinyinMap) {
                if (key.startsWith(q)) {
                    for (w in words) {
                        if (w !in results) {
                            results.add(w)
                            if (results.size >= 16) break
                        }
                    }
                }
                if (results.size >= 16) break
            }
        }

        return if (results.isNotEmpty()) results else listOf(q)
    }

    /**
     * 九宫格 T9 数字键连打候选词搜索
     */
    fun searchByT9(digits: String): List<String> {
        val d = digits.trim()
        if (d.isEmpty()) return emptyList()

        val results = mutableListOf<String>()

        // 1. 完全匹配
        val exact = t9Map[d]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        // 2. T9 长数字串双词连打分词
        val n = d.length
        if (n >= 4) {
            for (i in (n - 1) downTo 2) {
                val w1 = t9Map[d.substring(0, i)]
                if (!w1.isNullOrEmpty()) {
                    val w2 = t9Map[d.substring(i)]
                    if (!w2.isNullOrEmpty()) {
                        for (a in w1.take(3)) {
                            for (b in w2.take(3)) {
                                val comb = a + b
                                if (comb !in results) {
                                    results.add(comb)
                                    if (results.size >= 16) return results
                                }
                            }
                        }
                    }
                }
            }

            // 3. T9 三词连打
            if (n >= 6 && results.size < 10) {
                for (i in 2 until (n - 2)) {
                    val w1 = t9Map[d.substring(0, i)] ?: continue
                    for (j in (i + 2) until n) {
                        val w2 = t9Map[d.substring(i, j)] ?: continue
                        val w3 = t9Map[d.substring(j)] ?: continue
                        val comb = w1[0] + w2[0] + w3[0]
                        if (comb !in results) {
                            results.add(comb)
                            if (results.size >= 16) return results
                        }
                    }
                }
            }
        }

        // 4. 前缀模糊联想
        if (results.size < 8) {
            for ((key, words) in t9Map) {
                if (key.startsWith(d)) {
                    for (w in words) {
                        if (w !in results) {
                            results.add(w)
                            if (results.size >= 16) break
                        }
                    }
                }
                if (results.size >= 16) break
            }
        }

        return if (results.isNotEmpty()) results else listOf(d)
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
