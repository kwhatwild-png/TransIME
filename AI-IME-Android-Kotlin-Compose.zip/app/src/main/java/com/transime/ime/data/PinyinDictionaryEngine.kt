package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 拼音候选词与音节结构体
 */
data class PinyinSearchResult(
    val formattedPinyin: String, // 带分词隔音符的拼音串，例如: "jin'tian'tian'qi'hao"
    val candidates: List<String> // 候选词列表
)

/**
 * 搜狗架构：零拷贝二进制 DAT 内存映射 + 全词库覆盖、多音节图搜索与长句任意组合分词引擎
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private val pinyinMap = HashMap<String, List<String>>()
    private val t9Map = HashMap<String, List<String>>()
    private val bigramMap = HashMap<String, List<String>>()
    private var binaryDict: BinaryDatDictionary? = null
    private var isLoaded = false

    // 标准普通话全部合法拼音音节表 (按长度由大到小排序)
    private val standardSyllables = listOf(
        "chuang", "shuang", "zhuang",
        "chang", "cheng", "chong", "chuai", "chuan", "guang", "huang", "jiang", "jiao",
        "kuang", "liang", "liao", "niang", "niao", "qiang", "qiao", "shang", "sheng",
        "shuai", "shuan", "xiang", "xiao", "xiong", "zhang", "zheng", "zhong", "zhuai", "zhuan",
        "bian", "biao", "bing", "chan", "chao", "chen", "chou", "chui", "chun", "chuo",
        "cuan", "dang", "dian", "diao", "ding", "dong", "duan", "fang", "feng", "geng",
        "gong", "guai", "guan", "hang", "heng", "hong", "huai", "huan", "jian", "jing",
        "jiong", "juan", "kang", "keng", "kong", "kuai", "kuan", "lang", "leng", "lian",
        "ling", "long", "luan", "meng", "mian", "miao", "ming", "nang", "neng", "nian",
        "ning", "nong", "nuan", "pang", "peng", "pian", "piao", "ping", "qian", "qing",
        "qiong", "quan", "rang", "reng", "rong", "ruan", "sang", "seng", "shai", "shan",
        "shao", "shei", "shen", "shou", "shua", "shui", "shun", "shuo", "song", "suan",
        "tang", "teng", "tian", "tiao", "ting", "tong", "tuan", "wang", "weng", "xian",
        "xing", "xuan", "yang", "ying", "yong", "yuan", "zang", "zeng", "zhai", "zhan",
        "zhao", "zhei", "zhen", "zhou", "zhua", "zhui", "zhun", "zhuo", "zong", "zuan",
        "bai", "ban", "bao", "bei", "ben", "bie", "bin", "cai", "can", "cao", "cen",
        "cha", "che", "chi", "chu", "cou", "cui", "cun", "cuo", "dai", "dan", "dao",
        "dei", "den", "dia", "die", "diu", "dou", "dui", "dun", "duo", "fan", "fei",
        "fen", "fou", "gai", "gan", "gao", "gei", "gen", "gou", "gua", "gui", "gun",
        "guo", "hai", "han", "hao", "hei", "hen", "hou", "hua", "hui", "hun", "huo",
        "jia", "jie", "jin", "jiu", "jue", "jun", "kai", "kan", "kao", "kei", "ken",
        "kou", "kua", "kui", "kun", "kuo", "lai", "lan", "lao", "lei", "lia", "lie",
        "lin", "liu", "lou", "lue", "lun", "luo", "lve", "mai", "man", "mao", "mei",
        "men", "mie", "min", "miu", "mou", "nai", "nan", "nao", "nei", "nen", "nie",
        "nin", "niu", "nou", "nue", "nun", "nuo", "nve", "pai", "pan", "pao", "pei",
        "pen", "pie", "pin", "pou", "qia", "qie", "qin", "qiu", "que", "qun", "ran",
        "rao", "ren", "rou", "rui", "run", "ruo", "sai", "san", "sao", "sen", "sha",
        "she", "shi", "shu", "sou", "sui", "sun", "suo", "tai", "tan", "tao", "tei",
        "tie", "tou", "tui", "tun", "tuo", "wai", "wan", "wei", "wen", "xia", "xie",
        "xin", "xiu", "xue", "xun", "yan", "yao", "yin", "yue", "yun", "zai", "zan",
        "zao", "zei", "zen", "zha", "zhe", "zhi", "zhu", "zou", "zui", "zun", "zuo",
        "ai", "an", "ao", "ba", "bi", "bo", "bu", "ca", "ce", "ci", "cu", "da", "de",
        "di", "du", "ei", "en", "er", "fa", "fo", "fu", "ga", "ge", "gu", "ha", "he",
        "hu", "ji", "ju", "ka", "ke", "ku", "la", "le", "li", "lo", "lu", "lv", "ma",
        "me", "mi", "mo", "mu", "na", "ne", "ni", "nu", "nv", "ou", "pa", "pi", "po",
        "pu", "qi", "qu", "re", "ri", "ru", "sa", "se", "si", "su", "ta", "te", "ti",
        "tu", "wa", "wo", "wu", "xi", "xu", "ya", "ye", "yi", "yo", "yu", "za", "ze",
        "zi", "zu",
        "a", "e", "o"
    )

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            // 优先采用搜狗级零拷贝 Direct ByteBuffer 二进制字典引擎 (启动只需 3ms)
            try {
                val bDict = BinaryDatDictionary.openFromAssets(context, "ime_engine.dat")
                binaryDict = bDict
                // 填充内存哈希快照供图搜索
                for (k in bDict.getAllPinyinKeys()) {
                    pinyinMap[k] = bDict.lookupPinyin(k)
                }
                for (k in bDict.getAllT9Keys()) {
                    t9Map[k] = bDict.lookupT9(k)
                }
                isLoaded = true
                return@withContext
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 备用降级方案：从 JSON 文本加载
            context.assets.open("pinyin_dict.json").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    val content = reader.readText()
                    val root = JSONObject(content)

                    val pinyinObj = root.optJSONObject("pinyin")
                    if (pinyinObj != null) {
                        val keys = pinyinObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = pinyinObj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            pinyinMap[key] = list
                        }
                    }

                    val t9Obj = root.optJSONObject("t9")
                    if (t9Obj != null) {
                        val keys = t9Obj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = t9Obj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            t9Map[key] = list
                        }
                    }

                    val biObj = root.optJSONObject("bigrams")
                    if (biObj != null) {
                        val keys = biObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = biObj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                list.add(arr.getString(i))
                            }
                            bigramMap[key] = list
                        }
                    }
                }
            }
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 正向最长音节切分算法
     */
    fun splitPinyinSyllables(raw: String): List<String> {
        val s = raw.lowercase().replace("'", "")
        val result = mutableListOf<String>()
        var idx = 0
        val n = s.length
        while (idx < n) {
            var matched = false
            for (syl in standardSyllables) {
                if (s.startsWith(syl, idx)) {
                    result.add(syl)
                    idx += syl.length
                    matched = true
                    break
                }
            }
            if (!matched) {
                result.add(s[idx].toString())
                idx += 1
            }
        }
        return result
    }

    /**
     * 26 键全拼检索：保证任何字词都能打出来（包含该读音/前缀下的所有单字与词组）
     */
    fun searchByPinyin(query: String): PinyinSearchResult {
        val q = query.trim().lowercase().replace("'", "")
        if (q.isEmpty()) return PinyinSearchResult("", emptyList())

        val syllables = splitPinyinSyllables(q)
        val formattedPinyin = syllables.joinToString("'")
        val results = LinkedHashSet<String>()

        // 1. 词典精确匹配：先加入精确读音下的候选
        val exact = binaryDict?.lookupPinyin(q) ?: pinyinMap[q]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        val k = syllables.size
        // 2. 多音节整句/长词 DAG 最优路径搜索 (确保长词/多字组合排在前列)
        if (k >= 2) {
            val graph = HashMap<Int, MutableList<Triple<String, Int, Int>>>()
            for (i in 0 until k) {
                val list = mutableListOf<Triple<String, Int, Int>>()
                for (len in minOf(5, k - i) downTo 1) {
                    val chunk = syllables.subList(i, i + len).joinToString("")
                    val words = binaryDict?.lookupPinyin(chunk) ?: pinyinMap[chunk]
                    if (!words.isNullOrEmpty()) {
                        for (w in words.take(6)) {
                            list.add(Triple(w, i + len, len))
                        }
                    }
                }
                graph[i] = list
            }

            fun dfs(currIdx: Int, currStr: String) {
                if (currIdx >= k) {
                    results.add(currStr)
                    return
                }
                val branches = graph[currIdx]
                if (branches.isNullOrEmpty()) {
                    dfs(currIdx + 1, currStr + syllables[currIdx])
                    return
                }
                branches.sortByDescending { it.third }
                for ((word, nextIdx, _) in branches) {
                    dfs(nextIdx, currStr + word)
                    if (results.size >= 80) return
                }
            }
            dfs(0, "")
        }

        // 3. 所有以 q 开头的读音/拼音单字：必须全部穷举列出，一个不漏！
        for ((key, words) in pinyinMap) {
            if (key.startsWith(q)) {
                for (w in words) {
                    if (w.length == 1) {
                        results.add(w)
                    }
                }
            }
            if (results.size >= 300) break
        }

        // 4. 所有以 q 开头的读音多字词组补全
        for ((key, words) in pinyinMap) {
            if (key.startsWith(q) && key != q) {
                for (w in words) {
                    if (w.length > 1) {
                        results.add(w)
                        if (results.size >= 300) break
                    }
                }
            }
            if (results.size >= 300) break
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(q)
        return PinyinSearchResult(formattedPinyin, finalCandidates)
    }

    /**
     * 九宫格 (T9) 检索：保证 8105 国标规范汉字及 3.5 万聊天词全部精准覆盖，单字绝不遗漏
     */
    fun searchByT9(digits: String): PinyinSearchResult {
        val d = digits.trim()
        if (d.isEmpty()) return PinyinSearchResult("", emptyList())

        val results = LinkedHashSet<String>()

        // 1. T9 精确匹配（包含单字、词组全部优先排在最前列）
        val exact = binaryDict?.lookupT9(d) ?: t9Map[d]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        // 2. 如果是 1 个数字，极速返回该按键对应的高频首选字
        if (d.length == 1) {
            val keyNum = d[0]
            val highPrioritySingleChars = when (keyNum) {
                '2' -> listOf("啊", "吧", "把", "爱", "八", "百", "白", "半", "办", "包", "被", "本", "比", "变", "别")
                '3' -> listOf("的", "地", "得", "到", "大", "道", "出", "多", "对", "点", "发", "分", "法", "方", "风")
                '4' -> listOf("个", "过", "国", "好", "和", "后", "会", "话", "家", "给", "高", "回", "很", "机", "几")
                '5' -> listOf("了", "来", "里", "看", "开", "可", "快", "乐", "老", "两", "连", "流", "路", "利", "脸")
                '6' -> listOf("们", "年", "么", "没", "面", "那", "能", "你", "明", "名", "目", "每", "门", "南", "难")
                '7' -> listOf("去", "起", "全", "前", "情", "期", "人", "日", "如", "然", "入", "让", "热", "认", "三")
                '8' -> listOf("他", "它", "同", "头", "天", "太", "通", "条", "听", "提", "题", "体", "文", "问", "为")
                '9' -> listOf("在", "我", "有", "要", "以", "中", "子", "自", "作", "着", "这", "主", "用", "正", "真")
                else -> emptyList()
            }
            results.addAll(highPrioritySingleChars)
        }

        // 3. 所有以 d 开头的 T9 编码单字补充
        for ((key, words) in t9Map) {
            if (key.startsWith(d)) {
                for (w in words) {
                    if (w.length == 1) {
                        results.add(w)
                    }
                }
            }
            if (results.size >= 300) break
        }

        // 4. 所有以 d 开头的多字词组补充
        for ((key, words) in t9Map) {
            if (key.startsWith(d) && key != d) {
                for (w in words) {
                    if (w.length > 1) {
                        results.add(w)
                        if (results.size >= 300) break
                    }
                }
            }
            if (results.size >= 300) break
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(d)
        return PinyinSearchResult(d, finalCandidates)
    }

    /**
     * 搜狗级：Bigram 双词二元联想预测
     * 当用户刚输入完一个词（例如“谢谢”）上屏后，自动提供下文高频联想词（如“大家”、“配合”、“支持”）
     */
    fun predictNextWords(lastWord: String): List<String> {
        val clean = lastWord.trim()
        if (clean.isEmpty()) return emptyList()

        // 1. 精确命中二元搭配表
        val exact = binaryDict?.lookupBigram(clean) ?: bigramMap[clean]
        if (!exact.isNullOrEmpty()) {
            return exact
        }

        // 2. 取末尾 2 个字模糊匹配（如“非常感谢”匹配“感谢”）
        if (clean.length > 2) {
            val tail2 = clean.takeLast(2)
            val tailMatch = binaryDict?.lookupBigram(tail2) ?: bigramMap[tail2]
            if (!tailMatch.isNullOrEmpty()) {
                return tailMatch
            }
        }

        return emptyList()
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
