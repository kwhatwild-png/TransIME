package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * 拼音候选词与音节结构体
 */
data class PinyinSearchResult(
    val formattedPinyin: String, // 带分词隔音符的拼音串，例如: "jin'tian'tian'qi'hao"
    val candidates: List<String> // 候选词列表
)

/**
 * 搜狗架构：全词库覆盖、多音节图搜索与长句任意组合分词引擎
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private val pinyinMap = HashMap<String, List<String>>()
    private val t9Map = HashMap<String, List<String>>()
    private var isLoaded = false

    // 标准普通话全部合法拼音音节表 (按长度由大到小排序)
    private val standardSyllables = listOf(
        "chuang", "shuang", "zhuang",
        "chang", "cheng", "chong", "chuai", "chuan", "guang", "huang", "jiang", "jiao",
        "kuang", "liang", "liao", "niang", "niao", "qiang", "qiao", "shang", "sheng",
        "shuai", "shuan", "xiang", "xiao", "xiong", "zhang", "zheng", "zhong", "zhuai", "zhuan",
        "bian", "biao", "bing", "chan", "chao", "chen", "chou", "chui", "chun", "chuo",
        "cuan", "dang", "dian", "diao", "ding", "dong", "duan", "fang", "feng", "geng",
        "gong", "guai", "guan", "hang", "heng", "hong", "huai", "huan", "jian", "jing",
        "jiong", "juan", "kang", "keng", "kong", "kuai", "kuan", "lang", "leng", "lian",
        "ling", "long", "luan", "meng", "mian", "miao", "ming", "nang", "neng", "nian",
        "ning", "nong", "nuan", "pang", "peng", "pian", "piao", "ping", "qian", "qing",
        "qiong", "quan", "rang", "reng", "rong", "ruan", "sang", "seng", "shai", "shan",
        "shao", "shei", "shen", "shou", "shua", "shui", "shun", "shuo", "song", "suan",
        "tang", "teng", "tian", "tiao", "ting", "tong", "tuan", "wang", "weng", "xian",
        "xing", "xuan", "yang", "ying", "yong", "yuan", "zang", "zeng", "zhai", "zhan",
        "zhao", "zhei", "zhen", "zhou", "zhua", "zhui", "zhun", "zhuo", "zong", "zuan",
        "bai", "ban", "bao", "bei", "ben", "bie", "bin", "cai", "can", "cao", "cen",
        "cha", "che", "chi", "chu", "cou", "cui", "cun", "cuo", "dai", "dan", "dao",
        "dei", "den", "dia", "die", "diu", "dou", "dui", "dun", "duo", "fan", "fei",
        "fen", "fou", "gai", "gan", "gao", "gei", "gen", "gou", "gua", "gui", "gun",
        "guo", "hai", "han", "hao", "hei", "hen", "hou", "hua", "hui", "hun", "huo",
        "jia", "jie", "jin", "jiu", "jue", "jun", "kai", "kan", "kao", "kei", "ken",
        "kou", "kua", "kui", "kun", "kuo", "lai", "lan", "lao", "lei", "lia", "lie",
        "lin", "liu", "lou", "lue", "lun", "luo", "lve", "mai", "man", "mao", "mei",
        "men", "mie", "min", "miu", "mou", "nai", "nan", "nao", "nei", "nen", "nie",
        "nin", "niu", "nou", "nue", "nun", "nuo", "nve", "pai", "pan", "pao", "pei",
        "pen", "pie", "pin", "pou", "qia", "qie", "qin", "qiu", "que", "qun", "ran",
        "rao", "ren", "rou", "rui", "run", "ruo", "sai", "san", "sao", "sen", "sha",
        "she", "shi", "shu", "sou", "sui", "sun", "suo", "tai", "tan", "tao", "tei",
        "tie", "tou", "tui", "tun", "tuo", "wai", "wan", "wei", "wen", "xia", "xie",
        "xin", "xiu", "xue", "xun", "yan", "yao", "yin", "yue", "yun", "zai", "zan",
        "zao", "zei", "zen", "zha", "zhe", "zhi", "zhu", "zou", "zui", "zun", "zuo",
        "ai", "an", "ao", "ba", "bi", "bo", "bu", "ca", "ce", "ci", "cu", "da", "de",
        "di", "du", "ei", "en", "er", "fa", "fo", "fu", "ga", "ge", "gu", "ha", "he",
        "hu", "ji", "ju", "ka", "ke", "ku", "la", "le", "li", "lo", "lu", "lv", "ma",
        "me", "mi", "mo", "mu", "na", "ne", "ni", "nu", "nv", "ou", "pa", "pi", "po",
        "pu", "qi", "qu", "re", "ri", "ru", "sa", "se", "si", "su", "ta", "te", "ti",
        "tu", "wa", "wo", "wu", "xi", "xu", "ya", "ye", "yi", "yo", "yu", "za", "ze",
        "zi", "zu",
        "a", "e", "o"
    )

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            context.assets.open("pinyin_dict.json").use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    val content = reader.readText()
                    val root = JSONObject(content)

                    val pinyinObj = root.optJSONObject("pinyin")
                    if (pinyinObj != null) {
                        val keys = pinyinObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = pinyinObj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            pinyinMap[key] = list
                        }
                    }

                    val t9Obj = root.optJSONObject("t9")
                    if (t9Obj != null) {
                        val keys = t9Obj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            val arr = t9Obj.getJSONArray(key)
                            val list = ArrayList<String>(arr.length())
                            for (i in 0 until arr.length()) {
                                val item = arr.getString(i)
                                if (!item.contains("->")) {
                                    list.add(item)
                                }
                            }
                            t9Map[key] = list
                        }
                    }
                }
            }
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 正向最长音节切分算法
     */
    fun splitPinyinSyllables(raw: String): List<String> {
        val s = raw.lowercase().replace("'", "")
        val result = mutableListOf<String>()
        var idx = 0
        val n = s.length
        while (idx < n) {
            var matched = false
            for (syl in standardSyllables) {
                if (s.startsWith(syl, idx)) {
                    result.add(syl)
                    idx += syl.length
                    matched = true
                    break
                }
            }
            if (!matched) {
                result.add(s[idx].toString())
                idx += 1
            }
        }
        return result
    }

    /**
     * 26 键全拼检索：保证任何字词都能打出来（包含该读音/前缀下的所有单字与词组）
     */
    fun searchByPinyin(query: String): PinyinSearchResult {
        val q = query.trim().lowercase().replace("'", "")
        if (q.isEmpty()) return PinyinSearchResult("", emptyList())

        val syllables = splitPinyinSyllables(q)
        val formattedPinyin = syllables.joinToString("'")
        val results = LinkedHashSet<String>()

        // 1. 词典精确匹配：先加入精确读音下的候选（单字全部无遗漏加入）
        val exact = pinyinMap[q]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        val k = syllables.size
        // 2. 多音节整句/长词 DAG 最优路径搜索 (确保长词/多字组合排在前列)
        if (k >= 2) {
            val graph = HashMap<Int, MutableList<Triple<String, Int, Int>>>()
            for (i in 0 until k) {
                val list = mutableListOf<Triple<String, Int, Int>>()
                for (len in minOf(5, k - i) downTo 1) {
                    val chunk = syllables.subList(i, i + len).joinToString("")
                    val words = pinyinMap[chunk]
                    if (!words.isNullOrEmpty()) {
                        for (w in words.take(6)) {
                            list.add(Triple(w, i + len, len))
                        }
                    }
                }
                graph[i] = list
            }

            fun dfs(currIdx: Int, currStr: String) {
                if (currIdx >= k) {
                    results.add(currStr)
                    return
                }
                val branches = graph[currIdx]
                if (branches.isNullOrEmpty()) {
                    dfs(currIdx + 1, currStr + syllables[currIdx])
                    return
                }
                branches.sortByDescending { it.third }
                for ((word, nextIdx, _) in branches) {
                    dfs(nextIdx, currStr + word)
                    if (results.size >= 80) return
                }
            }
            dfs(0, "")
        }

        // 3. 所有以 q 开头的读音/拼音单字：必须全部穷举列出，一个不漏！
        for ((key, words) in pinyinMap) {
            if (key.startsWith(q)) {
                for (w in words) {
                    if (w.length == 1) {
                        results.add(w)
                    }
                }
            }
        }

        // 4. 所有以 q 开头的常用词组扩展候选
        for ((key, words) in pinyinMap) {
            if (key.startsWith(q)) {
                for (w in words) {
                    if (w.length > 1) {
                        results.add(w)
                        if (results.size >= 300) break
                    }
                }
            }
            if (results.size >= 300) break
        }

        // 5. 极端兜底：如果完全未录入，回退首选单字组合或原始音节
        if (results.isEmpty()) {
            val fallbackChars = syllables.map { syl ->
                pinyinMap[syl]?.firstOrNull() ?: syl
            }.joinToString("")
            results.add(fallbackChars)
            results.add(q)
        }

        return PinyinSearchResult(formattedPinyin, results.toList())
    }

    /**
     * 九宫格 T9 检索：包含精确词、长数字流分词与该按键前缀下的全部单字
     */
    fun searchByT9(digits: String): PinyinSearchResult {
        val d = digits.trim()
        if (d.isEmpty()) return PinyinSearchResult("", emptyList())

        val results = LinkedHashSet<String>()

        // 1. 精确匹配（包含该数字码对应的全部单字和词）
        val exact = t9Map[d]
        if (!exact.isNullOrEmpty()) {
            results.addAll(exact)
        }

        // 2. 长数字流分词组合
        val n = d.length
        if (n >= 4) {
            for (i in (n - 1) downTo 2) {
                val w1 = t9Map[d.substring(0, i)]
                if (!w1.isNullOrEmpty()) {
                    val w2 = t9Map[d.substring(i)]
                    if (!w2.isNullOrEmpty()) {
                        for (a in w1.take(3)) {
                            for (b in w2.take(3)) {
                                results.add(a + b)
                                if (results.size >= 50) break
                            }
                            if (results.size >= 50) break
                        }
                    }
                }
            }
        }

        // 3. 所有以 d 开头的单字候选：全部穷举列出，让用户翻页能找到每一个单字
        for ((key, words) in t9Map) {
            if (key.startsWith(d)) {
                for (w in words) {
                    if (w.length == 1) {
                        results.add(w)
                    }
                }
            }
        }

        // 4. 所有以 d 开头的多字词组候选
        for ((key, words) in t9Map) {
            if (key.startsWith(d)) {
                for (w in words) {
                    if (w.length > 1) {
                        results.add(w)
                        if (results.size >= 300) break
                    }
                }
            }
            if (results.size >= 300) break
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(d)
        return PinyinSearchResult(d, finalCandidates)
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
