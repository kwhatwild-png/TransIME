package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 拼音候选词与音节结构体
 */
data class PinyinSearchResult(
    val formattedPinyin: String, // 带分词隔音符的拼音串，例如: "jin'tian'tian'qi'hao"
    val candidates: List<String>, // 候选词列表
    val pinyinFilters: List<String> = emptyList() // 搜狗式拼音筛选器（如输入 534 时提供: "lei", "kei", "ke", "le", "j"）
)

/**
 * 搜狗架构：零拷贝二进制 DAT 内存映射 + 动态多音节有向无环图 (DAG) 搜索 + 全功能模糊音纠错引擎
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private var binaryDict: BinaryDatDictionary? = null
    @Volatile
    private var isLoaded = false

    // 标准普通话全部合法拼音音节表 (按长度由大到小排序)
    private val standardSyllables = listOf(
        "chuang", "shuang", "zhuang",
        "chang", "cheng", "chong", "chuai", "chuan", "guang", "huang", "jiang", "jiao",
        "kuang", "liang", "liao", "niang", "niao", "qiang", "qiao", "shang", "sheng",
        "shuai", "shuan", "xiang", "xiao", "xiong", "zhang", "zheng", "zhong", "zhuai", "zhuan",
        "bian", "biao", "bing", "chan", "chao", "chen", "chou", "chui", "chun", "chuo",
        "cuan", "dang", "dian", "diao", "ding", "dong", "duan", "fang", "feng", "geng",
        "gong", "guai", "guan", "hang", "heng", "hong", "huai", "huan", "jian", "jing",
        "jiong", "juan", "kang", "keng", "kong", "kuai", "kuan", "lang", "leng", "lian",
        "ling", "long", "luan", "meng", "mian", "miao", "ming", "nang", "neng", "nian",
        "ning", "nong", "nuan", "pang", "peng", "pian", "piao", "ping", "qian", "qing",
        "qiong", "quan", "rang", "reng", "rong", "ruan", "sang", "seng", "shai", "shan",
        "shao", "shei", "shen", "shou", "shua", "shui", "shun", "shuo", "song", "suan",
        "tang", "teng", "tian", "tiao", "ting", "tong", "tuan", "wang", "weng", "xian",
        "xing", "xuan", "yang", "ying", "yong", "yuan", "zang", "zeng", "zhai", "zhan",
        "zhao", "zhei", "zhen", "zhou", "zhua", "zhui", "zhun", "zhuo", "zong", "zuan",
        "bai", "ban", "bao", "bei", "ben", "bie", "bin", "cai", "can", "cao", "cen",
        "cha", "che", "chi", "chu", "cou", "cui", "cun", "cuo", "dai", "dan", "dao",
        "dei", "den", "dia", "die", "diu", "dou", "dui", "dun", "duo", "fan", "fei",
        "fen", "fou", "gai", "gan", "gao", "gei", "gen", "gou", "gua", "gui", "gun",
        "guo", "hai", "han", "hao", "hei", "hen", "hou", "hua", "hui", "hun", "huo",
        "jia", "jie", "jin", "jiu", "jue", "jun", "kai", "kan", "kao", "kei", "ken",
        "kou", "kua", "kui", "kun", "kuo", "lai", "lan", "lao", "lei", "lia", "lie",
        "lin", "liu", "lou", "lue", "lun", "luo", "lve", "mai", "man", "mao", "mei",
        "men", "mie", "min", "miu", "mou", "nai", "nan", "nao", "nei", "nen", "nie",
        "nin", "niu", "nou", "nue", "nun", "nuo", "nve", "pai", "pan", "pao", "pei",
        "pen", "pie", "pin", "pou", "qia", "qie", "qin", "qiu", "que", "qun", "ran",
        "rao", "ren", "rou", "rui", "run", "ruo", "sai", "san", "sao", "sen", "sha",
        "she", "shi", "shu", "sou", "sui", "sun", "suo", "tai", "tan", "tao", "tei",
        "tie", "tou", "tui", "tun", "tuo", "wai", "wan", "wei", "wen", "xia", "xie",
        "xin", "xiu", "xue", "xun", "yan", "yao", "yin", "yue", "yun", "zai", "zan",
        "zao", "zei", "zen", "zha", "zhe", "zhi", "zhu", "zou", "zui", "zun", "zuo",
        "ai", "an", "ao", "ba", "bi", "bo", "bu", "ca", "ce", "ci", "cu", "da", "de",
        "di", "du", "ei", "en", "er", "fa", "fo", "fu", "ga", "ge", "gu", "ha", "he",
        "hu", "ji", "ju", "ka", "ke", "ku", "la", "le", "li", "lo", "lu", "lv", "ma",
        "me", "mi", "mo", "mu", "na", "ne", "ni", "nu", "nv", "ou", "pa", "pi", "po",
        "pu", "qi", "qu", "re", "ri", "ru", "sa", "se", "si", "su", "ta", "te", "ti",
        "tu", "wa", "wo", "wu", "xi", "xu", "ya", "ye", "yi", "yo", "yu", "za", "ze",
        "zi", "zu",
        "a", "e", "o"
    )

    // T9 数字串到对应音节的映射表
    private val t9ToSyllables = HashMap<String, MutableList<String>>()

    init {
        for (syl in standardSyllables) {
            val d = StringBuilder(syl.length)
            for (c in syl) {
                val digit = when (c) {
                    'a', 'b', 'c' -> '2'
                    'd', 'e', 'f' -> '3'
                    'g', 'h', 'i' -> '4'
                    'j', 'k', 'l' -> '5'
                    'm', 'n', 'o' -> '6'
                    'p', 'q', 'r', 's' -> '7'
                    't', 'u', 'v' -> '8'
                    else -> '9'
                }
                d.append(digit)
            }
            val key = d.toString()
            val list = t9ToSyllables.getOrPut(key) { ArrayList(2) }
            list.add(syl)
        }
    }

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            binaryDict = BinaryDatDictionary.openFromAssets(context, "ime_engine.dat")
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 搜狗级模糊音音节扩展器 (平翘舌、前后鼻音、边鼻音、f/h)
     */
    fun getFuzzySyllables(syl: String): Set<String> {
        val s = syl.lowercase()
        val res = LinkedHashSet<String>()
        res.add(s)

        // 1. 声母模糊音互换
        if (s.startsWith("zh")) {
            res.add("z" + s.substring(2))
        } else if (s.startsWith("z")) {
            res.add("zh" + s.substring(1))
        } else if (s.startsWith("ch")) {
            res.add("c" + s.substring(2))
        } else if (s.startsWith("c")) {
            res.add("ch" + s.substring(1))
        } else if (s.startsWith("sh")) {
            res.add("s" + s.substring(2))
        } else if (s.startsWith("s")) {
            res.add("sh" + s.substring(1))
        } else if (s.startsWith("l")) {
            res.add("n" + s.substring(1))
        } else if (s.startsWith("n")) {
            res.add("l" + s.substring(1))
        } else if (s.startsWith("f")) {
            res.add("h" + s.substring(1))
        } else if (s.startsWith("h")) {
            res.add("f" + s.substring(1))
        } else if (s.startsWith("r")) {
            res.add("l" + s.substring(1))
        }

        // 2. 韵母前后鼻音互换
        val snapshot = ArrayList(res)
        for (item in snapshot) {
            if (item.endsWith("uang")) {
                res.add(item.removeSuffix("uang") + "uan")
            } else if (item.endsWith("uan")) {
                res.add(item.removeSuffix("uan") + "uang")
            } else if (item.endsWith("iang")) {
                res.add(item.removeSuffix("iang") + "ian")
            } else if (item.endsWith("ian")) {
                res.add(item.removeSuffix("ian") + "iang")
            } else if (item.endsWith("ang")) {
                res.add(item.removeSuffix("ang") + "an")
            } else if (item.endsWith("an")) {
                res.add(item.removeSuffix("an") + "ang")
            } else if (item.endsWith("eng")) {
                res.add(item.removeSuffix("eng") + "en")
            } else if (item.endsWith("en")) {
                res.add(item.removeSuffix("en") + "eng")
            } else if (item.endsWith("ing")) {
                res.add(item.removeSuffix("ing") + "in")
            } else if (item.endsWith("in")) {
                res.add(item.removeSuffix("in") + "ing")
            }
        }

        return res
    }

    /**
     * 正向最长音节切分算法
     */
    fun splitPinyinSyllables(raw: String): List<String> {
        val s = raw.lowercase().replace("'", "")
        val result = mutableListOf<String>()
        var idx = 0
        val n = s.length
        while (idx < n) {
            var matched = false
            for (syl in standardSyllables) {
                if (s.startsWith(syl, idx)) {
                    result.add(syl)
                    idx += syl.length
                    matched = true
                    break
                }
            }
            if (!matched) {
                result.add(s[idx].toString())
                idx += 1
            }
        }
        return result
    }

    /**
     * 26 键全拼检索：精确匹配 + 模糊拼音自动补齐
     */
    fun searchByPinyin(query: String, enableFuzzy: Boolean = true): PinyinSearchResult {
        val q = query.trim().lowercase().replace("'", "")
        if (q.isEmpty()) return PinyinSearchResult("", emptyList())

        val dict = binaryDict ?: return PinyinSearchResult(q, listOf(q))
        val syllables = splitPinyinSyllables(q)
        val formattedPinyin = syllables.joinToString("'")
        val results = LinkedHashSet<String>()

        // 1. 精确原词查找
        val exact = dict.lookupPinyin(q)
        if (exact.isNotEmpty()) {
            results.addAll(exact)
        }

        // 2. 搜狗核心：动态规划整句/长词智能装配 (DP Sentence Assembly Engine)
        // 例如 womenshishenme -> 优先装配出 ['我们', '是', '什么'] -> 成为顶级首选「我们是什么」
        val k = syllables.size
        if (k >= 2) {
            val sentenceCandidates = composeSentenceFromSyllables(syllables, dict)
            if (sentenceCandidates.isNotEmpty()) {
                results.addAll(sentenceCandidates)
            }
        }

        // 3. 搜狗级模糊拼音纠错：生成模糊变体音节 (如 si -> shi, lan -> nan, xin -> xing)
        if (enableFuzzy) {
            val fuzzySyllables = getFuzzySyllables(q)
            for (fSyl in fuzzySyllables) {
                if (fSyl != q) {
                    val fWords = dict.lookupPinyin(fSyl)
                    if (fWords.isNotEmpty()) {
                        results.addAll(fWords.take(15))
                    }
                }
            }
        }

        // 4. 多音节真实前缀词匹配（前缀词候补）
        if (k >= 2) {
            // 全局词库检索
            val fullChunk = syllables.joinToString("")
            val fullMatches = dict.lookupPinyin(fullChunk)
            results.addAll(fullMatches)

            // 前缀真实词匹配（2~4音节优先，再单字）
            for (prefixLen in minOf(4, k - 1) downTo 1) {
                val prefixChunk = syllables.subList(0, prefixLen).joinToString("")
                val prefixWords = dict.lookupPinyin(prefixChunk)
                if (prefixWords.isNotEmpty()) {
                    results.addAll(prefixWords.take(15))
                }
            }
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(q)
        return PinyinSearchResult(formattedPinyin, finalCandidates)
    }

    /**
     * 九宫格 (T9) 核心检索与搜狗式拼音分流筛选器
     */
    fun searchByT9(digits: String, enableFuzzy: Boolean = true): PinyinSearchResult {
        val d = digits.trim()
        if (d.isEmpty()) return PinyinSearchResult("", emptyList())

        val dict = binaryDict ?: return PinyinSearchResult(d, listOf(d))
        val results = LinkedHashSet<String>()
        var bestPinyinDisplay = d
        val pinyinFilters = LinkedHashSet<String>()

        // 1. T9 精确命中词库
        val exact = dict.lookupT9(d)
        if (exact.isNotEmpty()) {
            results.addAll(exact)
        }

        // 2. 单按键极速首选高频字
        if (d.length == 1) {
            val highPrioritySingleChars = when (d[0]) {
                '2' -> listOf("啊", "吧", "把", "爱", "八", "百", "白", "半", "办", "包", "被", "本", "比", "变", "别")
                '3' -> listOf("的", "地", "得", "到", "大", "道", "出", "多", "对", "点", "发", "分", "法", "方", "风")
                '4' -> listOf("个", "过", "国", "好", "和", "后", "会", "话", "家", "给", "高", "回", "很", "机", "几")
                '5' -> listOf("了", "来", "里", "看", "开", "可", "快", "乐", "老", "两", "连", "流", "路", "利", "脸")
                '6' -> listOf("们", "年", "么", "没", "面", "那", "能", "你", "明", "名", "目", "每", "门", "南", "难")
                '7' -> listOf("去", "起", "全", "前", "情", "期", "人", "日", "如", "然", "入", "让", "热", "认", "三")
                '8' -> listOf("他", "它", "同", "头", "天", "太", "通", "条", "听", "提", "题", "体", "文", "问", "为")
                '9' -> listOf("在", "我", "有", "要", "以", "中", "子", "自", "作", "着", "这", "主", "用", "正", "真")
                else -> emptyList()
            }
            results.addAll(highPrioritySingleChars)
            val filters = when (d[0]) {
                '2' -> listOf("a", "b", "c")
                '3' -> listOf("d", "e", "f")
                '4' -> listOf("g", "h", "i")
                '5' -> listOf("j", "k", "l")
                '6' -> listOf("m", "n", "o")
                '7' -> listOf("p", "q", "r", "s")
                '8' -> listOf("t", "u", "v")
                '9' -> listOf("w", "x", "y", "z")
                else -> emptyList()
            }
            return PinyinSearchResult(d, results.toList(), filters)
        }

        // 3. 搜狗核心：T9 动态规划音节分割 (DP Syllable Partitioning)
        val n = d.length
        val dp = HashMap<Int, MutableList<List<String>>>()
        dp[0] = mutableListOf(emptyList())

        for (i in 0 until n) {
            val prevPaths = dp[i] ?: continue
            val maxLen = minOf(6, n - i)
            for (len in 1..maxLen) {
                val sub = d.substring(i, i + len)
                val syls = t9ToSyllables[sub] ?: continue
                val nextList = dp.getOrPut(i + len) { ArrayList() }
                for (syl in syls) {
                    for (path in prevPaths) {
                        if (nextList.size < 12) {
                            val newPath = ArrayList<String>(path.size + 1)
                            newPath.addAll(path)
                            newPath.add(syl)
                            nextList.add(newPath)
                        }
                    }
                }
            }
        }

        // 收集所有与当前数字前缀匹配的候选拼音音节作为筛选器
        val fullSyllables = t9ToSyllables[d]
        if (!fullSyllables.isNullOrEmpty()) {
            pinyinFilters.addAll(fullSyllables)
            if (enableFuzzy) {
                for (s in fullSyllables) {
                    pinyinFilters.addAll(getFuzzySyllables(s))
                }
            }
        }
        for (subLen in (n - 1) downTo 1) {
            val sub = d.substring(0, subLen)
            val subSyls = t9ToSyllables[sub]
            if (!subSyls.isNullOrEmpty()) {
                pinyinFilters.addAll(subSyls)
            }
        }
        val firstDigitChar = when (d[0]) {
            '2' -> listOf("a", "b", "c")
            '3' -> listOf("d", "e", "f")
            '4' -> listOf("g", "h", "i")
            '5' -> listOf("j", "k", "l")
            '6' -> listOf("m", "n", "o")
            '7' -> listOf("p", "q", "r", "s")
            '8' -> listOf("t", "u", "v")
            else -> listOf("w", "x", "y", "z")
        }
        pinyinFilters.addAll(firstDigitChar)

        // 对成功切分到末尾的所有音节路径，进行整句智能装配与前缀贪心装配
        val fullPaths = dp[n]
        if (!fullPaths.isNullOrEmpty()) {
            for (sylList in fullPaths.take(5)) {
                if (bestPinyinDisplay == d) {
                    bestPinyinDisplay = sylList.joinToString("'")
                }
                val k = sylList.size
                if (k >= 2) {
                    // 1. 动态规划整句装配
                    val sentenceCandidates = composeSentenceFromSyllables(sylList, dict)
                    if (sentenceCandidates.isNotEmpty()) {
                        results.addAll(sentenceCandidates)
                    }

                    // 2. 完整拼音匹配真实词
                    val fullChunk = sylList.joinToString("")
                    val fullWords = dict.lookupPinyin(fullChunk)
                    results.addAll(fullWords)

                    // 3. 前缀真实词匹配（2~4音节优先，再单字）
                    for (prefixLen in minOf(4, k - 1) downTo 1) {
                        val prefixChunk = sylList.subList(0, prefixLen).joinToString("")
                        val prefixWords = dict.lookupPinyin(prefixChunk)
                        if (prefixWords.isNotEmpty()) {
                            results.addAll(prefixWords.take(10))
                        }
                    }
                }
            }
        }

        // 4. 若候选词过少且开启了模糊拼音，补足模糊音联想
        if (enableFuzzy && results.size < 10) {
            val fuzzyS = getFuzzySyllables(bestPinyinDisplay.replace("'", ""))
            for (fs in fuzzyS) {
                val fWords = dict.lookupPinyin(fs)
                for (fw in fWords) {
                    results.add(fw)
                    if (results.size >= 25) break
                }
            }
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(d)
        return PinyinSearchResult(bestPinyinDisplay, finalCandidates, pinyinFilters.toList())
    }

    /**
     * 单独按特定拼音过滤词汇（支持模糊音过滤）
     */
    fun getCandidatesForPinyin(pinyin: String, enableFuzzy: Boolean = true): List<String> {
        val dict = binaryDict ?: return emptyList()
        val exact = dict.lookupPinyin(pinyin.lowercase())
        if (!enableFuzzy) return exact

        val results = LinkedHashSet<String>(exact)
        val fSyls = getFuzzySyllables(pinyin)
        for (fs in fSyls) {
            if (fs != pinyin) {
                results.addAll(dict.lookupPinyin(fs).take(15))
            }
        }
        return results.toList()
    }

    /**
     * 搜狗级：Bigram 双词二元联想预测
     */
    fun predictNextWords(lastWord: String): List<String> {
        val clean = lastWord.trim()
        if (clean.isEmpty()) return emptyList()

        val dict = binaryDict ?: return emptyList()
        val exact = dict.lookupBigram(clean)
        if (exact.isNotEmpty()) {
            return exact
        }

        if (clean.length > 2) {
            val tail2 = clean.takeLast(2)
            val tailMatch = dict.lookupBigram(tail2)
            if (tailMatch.isNotEmpty()) {
                return tailMatch
            }
        }

        return emptyList()
    }

    /**
     * 搜狗级：动态规划音节整句/长短词链装配引擎 (DP Sentence Assembly Engine)
     * 例如输入 womenshishenme 时：
     * 自动智能发现 ['women' (我们), 'shi' (是), 'shenme' (什么)] 组合，并在首选位生成「我们是什么」
     */
    private fun composeSentenceFromSyllables(
        syllables: List<String>,
        dict: BinaryDatDictionary
    ): List<String> {
        val n = syllables.size
        if (n < 2) return emptyList()

        data class DpState(val text: String, val score: Int)

        val dp = Array(n + 1) { mutableListOf<DpState>() }
        dp[0].add(DpState("", 0))

        for (i in 0 until n) {
            val prevStates = dp[i]
            if (prevStates.isEmpty()) continue

            val maxL = minOf(4, n - i)
            for (l in maxL downTo 1) {
                val chunk = syllables.subList(i, i + l).joinToString("")
                val words = dict.lookupPinyin(chunk)
                if (words.isNotEmpty()) {
                    // 多字词给予大幅度平方权重奖励 (4字词 1600分, 3字词 900分, 2字词 400分, 1字词 15分)
                    val lenScore = if (l > 1) l * l * 100 else 15
                    for (rank in 0 until minOf(2, words.size)) {
                        val w = words[rank]
                        val wordScore = lenScore - rank * 20
                        val targetList = dp[i + l]
                        for (prev in prevStates) {
                            if (targetList.size < 12) {
                                targetList.add(DpState(prev.text + w, prev.score + wordScore))
                            }
                        }
                    }
                }
            }
        }

        val finalStates = dp[n]
        if (finalStates.isEmpty()) return emptyList()

        finalStates.sortByDescending { it.score }
        val res = LinkedHashSet<String>()
        for (st in finalStates) {
            res.add(st.text)
            if (res.size >= 8) break
        }
        return res.toList()
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
