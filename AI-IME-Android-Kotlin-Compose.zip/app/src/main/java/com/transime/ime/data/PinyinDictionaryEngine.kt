package com.transime.ime.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 拼音候选词与音节结构体
 */
data class PinyinSearchResult(
    val formattedPinyin: String, // 带分词隔音符的拼音串，例如: "jin'tian'tian'qi'hao"
    val candidates: List<String> // 候选词列表
)

/**
 * 搜狗架构：零拷贝二进制 DAT 内存映射 + 动态多音节有向无环图 (DAG) 搜索与整句切词引擎
 */
class PinyinDictionaryEngine private constructor(private val context: Context) {

    private var binaryDict: BinaryDatDictionary? = null
    @Volatile
    private var isLoaded = false

    // 标准普通话全部合法拼音音节表 (按长度由大到小排序)
    private val standardSyllables = listOf(
        "chuang", "shuang", "zhuang",
        "chang", "cheng", "chong", "chuai", "chuan", "guang", "huang", "jiang", "jiao",
        "kuang", "liang", "liao", "niang", "niao", "qiang", "qiao", "shang", "sheng",
        "shuai", "shuan", "xiang", "xiao", "xiong", "zhang", "zheng", "zhong", "zhuai", "zhuan",
        "bian", "biao", "bing", "chan", "chao", "chen", "chou", "chui", "chun", "chuo",
        "cuan", "dang", "dian", "diao", "ding", "dong", "duan", "fang", "feng", "geng",
        "gong", "guai", "guan", "hang", "heng", "hong", "huai", "huan", "jian", "jing",
        "jiong", "juan", "kang", "keng", "kong", "kuai", "kuan", "lang", "leng", "lian",
        "ling", "long", "luan", "meng", "mian", "miao", "ming", "nang", "neng", "nian",
        "ning", "nong", "nuan", "pang", "peng", "pian", "piao", "ping", "qian", "qing",
        "qiong", "quan", "rang", "reng", "rong", "ruan", "sang", "seng", "shai", "shan",
        "shao", "shei", "shen", "shou", "shua", "shui", "shun", "shuo", "song", "suan",
        "tang", "teng", "tian", "tiao", "ting", "tong", "tuan", "wang", "weng", "xian",
        "xing", "xuan", "yang", "ying", "yong", "yuan", "zang", "zeng", "zhai", "zhan",
        "zhao", "zhei", "zhen", "zhou", "zhua", "zhui", "zhun", "zhuo", "zong", "zuan",
        "bai", "ban", "bao", "bei", "ben", "bie", "bin", "cai", "can", "cao", "cen",
        "cha", "che", "chi", "chu", "cou", "cui", "cun", "cuo", "dai", "dan", "dao",
        "dei", "den", "dia", "die", "diu", "dou", "dui", "dun", "duo", "fan", "fei",
        "fen", "fou", "gai", "gan", "gao", "gei", "gen", "gou", "gua", "gui", "gun",
        "guo", "hai", "han", "hao", "hei", "hen", "hou", "hua", "hui", "hun", "huo",
        "jia", "jie", "jin", "jiu", "jue", "jun", "kai", "kan", "kao", "kei", "ken",
        "kou", "kua", "kui", "kun", "kuo", "lai", "lan", "lao", "lei", "lia", "lie",
        "lin", "liu", "lou", "lue", "lun", "luo", "lve", "mai", "man", "mao", "mei",
        "men", "mie", "min", "miu", "mou", "nai", "nan", "nao", "nei", "nen", "nie",
        "nin", "niu", "nou", "nue", "nun", "nuo", "nve", "pai", "pan", "pao", "pei",
        "pen", "pie", "pin", "pou", "qia", "qie", "qin", "qiu", "que", "qun", "ran",
        "rao", "ren", "rou", "rui", "run", "ruo", "sai", "san", "sao", "sen", "sha",
        "she", "shi", "shu", "sou", "sui", "sun", "suo", "tai", "tan", "tao", "tei",
        "tie", "tou", "tui", "tun", "tuo", "wai", "wan", "wei", "wen", "xia", "xie",
        "xin", "xiu", "xue", "xun", "yan", "yao", "yin", "yue", "yun", "zai", "zan",
        "zao", "zei", "zen", "zha", "zhe", "zhi", "zhu", "zou", "zui", "zun", "zuo",
        "ai", "an", "ao", "ba", "bi", "bo", "bu", "ca", "ce", "ci", "cu", "da", "de",
        "di", "du", "ei", "en", "er", "fa", "fo", "fu", "ga", "ge", "gu", "ha", "he",
        "hu", "ji", "ju", "ka", "ke", "ku", "la", "le", "li", "lo", "lu", "lv", "ma",
        "me", "mi", "mo", "mu", "na", "ne", "ni", "nu", "nv", "ou", "pa", "pi", "po",
        "pu", "qi", "qu", "re", "ri", "ru", "sa", "se", "si", "su", "ta", "te", "ti",
        "tu", "wa", "wo", "wu", "xi", "xu", "ya", "ye", "yi", "yo", "yu", "za", "ze",
        "zi", "zu",
        "a", "e", "o"
    )

    // T9 数字串到对应音节的映射表 (例如: "96" -> ["wo", "yo"], "424" -> ["hai", "gai"])
    private val t9ToSyllables = HashMap<String, MutableList<String>>()

    init {
        for (syl in standardSyllables) {
            val d = StringBuilder(syl.length)
            for (c in syl) {
                val digit = when (c) {
                    'a', 'b', 'c' -> '2'
                    'd', 'e', 'f' -> '3'
                    'g', 'h', 'i' -> '4'
                    'j', 'k', 'l' -> '5'
                    'm', 'n', 'o' -> '6'
                    'p', 'q', 'r', 's' -> '7'
                    't', 'u', 'v' -> '8'
                    else -> '9'
                }
                d.append(digit)
            }
            val key = d.toString()
            val list = t9ToSyllables.getOrPut(key) { ArrayList(2) }
            list.add(syl)
        }
    }

    suspend fun loadDictionaryIfNeeded() = withContext(Dispatchers.IO) {
        if (isLoaded) return@withContext
        try {
            binaryDict = BinaryDatDictionary.openFromAssets(context, "ime_engine.dat")
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * 正向最长音节切分算法
     */
    fun splitPinyinSyllables(raw: String): List<String> {
        val s = raw.lowercase().replace("'", "")
        val result = mutableListOf<String>()
        var idx = 0
        val n = s.length
        while (idx < n) {
            var matched = false
            for (syl in standardSyllables) {
                if (s.startsWith(syl, idx)) {
                    result.add(syl)
                    idx += syl.length
                    matched = true
                    break
                }
            }
            if (!matched) {
                result.add(s[idx].toString())
                idx += 1
            }
        }
        return result
    }

    /**
     * 26 键全拼检索：包含精确匹配、多音节整句 DAG 切词组合与前缀补全
     */
    fun searchByPinyin(query: String): PinyinSearchResult {
        val q = query.trim().lowercase().replace("'", "")
        if (q.isEmpty()) return PinyinSearchResult("", emptyList())

        val dict = binaryDict ?: return PinyinSearchResult(q, listOf(q))
        val syllables = splitPinyinSyllables(q)
        val formattedPinyin = syllables.joinToString("'")
        val results = LinkedHashSet<String>()

        // 1. 词典精确匹配
        val exact = dict.lookupPinyin(q)
        if (exact.isNotEmpty()) {
            results.addAll(exact)
        }

        // 2. 多音节整句/长词 DAG 最优路径搜索
        val k = syllables.size
        if (k >= 2) {
            fun combine(idx: Int): List<String> {
                if (idx >= k) return listOf("")
                val res = mutableListOf<String>()
                for (len in minOf(4, k - idx) downTo 1) {
                    val chunk = syllables.subList(idx, idx + len).joinToString("")
                    val words = dict.lookupPinyin(chunk)
                    if (words.isNotEmpty()) {
                        val tailRes = combine(idx + len)
                        for (w in words.take(4)) {
                            for (t in tailRes.take(4)) {
                                res.add(w + t)
                                if (res.size >= 30) break
                            }
                            if (res.size >= 30) break
                        }
                    }
                }
                return res
            }
            results.addAll(combine(0))
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(q)
        return PinyinSearchResult(formattedPinyin, finalCandidates)
    }

    /**
     * 九宫格 (T9) 核心检索：
     * 1. 精确匹配完整词库
     * 2. 搜狗级 T9 数字串音节切分 + 多字词/短语整句动态规划组合 (彻底解决 96424744 -> "我还是" 等长句空白问题)
     */
    fun searchByT9(digits: String): PinyinSearchResult {
        val d = digits.trim()
        if (d.isEmpty()) return PinyinSearchResult("", emptyList())

        val dict = binaryDict ?: return PinyinSearchResult(d, listOf(d))
        val results = LinkedHashSet<String>()
        var bestPinyinDisplay = d

        // 1. T9 精确命中词库
        val exact = dict.lookupT9(d)
        if (exact.isNotEmpty()) {
            results.addAll(exact)
        }

        // 2. 单按键极速首选高频字
        if (d.length == 1) {
            val highPrioritySingleChars = when (d[0]) {
                '2' -> listOf("啊", "吧", "把", "爱", "八", "百", "白", "半", "办", "包", "被", "本", "比", "变", "别")
                '3' -> listOf("的", "地", "得", "到", "大", "道", "出", "多", "对", "点", "发", "分", "法", "方", "风")
                '4' -> listOf("个", "过", "国", "好", "和", "后", "会", "话", "家", "给", "高", "回", "很", "机", "几")
                '5' -> listOf("了", "来", "里", "看", "开", "可", "快", "乐", "老", "两", "连", "流", "路", "利", "脸")
                '6' -> listOf("们", "年", "么", "没", "面", "那", "能", "你", "明", "名", "目", "每", "门", "南", "难")
                '7' -> listOf("去", "起", "全", "前", "情", "期", "人", "日", "如", "然", "入", "让", "热", "认", "三")
                '8' -> listOf("他", "它", "同", "头", "天", "太", "通", "条", "听", "提", "题", "体", "文", "问", "为")
                '9' -> listOf("在", "我", "有", "要", "以", "中", "子", "自", "作", "着", "这", "主", "用", "正", "真")
                else -> emptyList()
            }
            results.addAll(highPrioritySingleChars)
            return PinyinSearchResult(d, results.toList())
        }

        // 3. 搜狗核心：T9 动态规划音节分割 (DP Syllable Partitioning)
        val n = d.length
        val dp = HashMap<Int, MutableList<List<String>>>()
        dp[0] = mutableListOf(emptyList())

        for (i in 0 until n) {
            val prevPaths = dp[i] ?: continue
            val maxLen = minOf(6, n - i)
            for (len in 1..maxLen) {
                val sub = d.substring(i, i + len)
                val syls = t9ToSyllables[sub] ?: continue
                val nextList = dp.getOrPut(i + len) { ArrayList() }
                for (syl in syls) {
                    for (path in prevPaths) {
                        if (nextList.size < 12) {
                            val newPath = ArrayList<String>(path.size + 1)
                            newPath.addAll(path)
                            newPath.add(syl)
                            nextList.add(newPath)
                        }
                    }
                }
            }
        }

        // 对成功切分到末尾的所有音节路径，进行贪心词组拼接
        val fullPaths = dp[n]
        if (!fullPaths.isNullOrEmpty()) {
            for (sylList in fullPaths.take(5)) {
                if (bestPinyinDisplay == d) {
                    bestPinyinDisplay = sylList.joinToString("'")
                }
                val k = sylList.size
                fun combine(idx: Int): List<String> {
                    if (idx >= k) return listOf("")
                    val res = mutableListOf<String>()
                    // 优先尝试长词匹配 (例如 2 个音节 "hai" + "shi" -> "还是")
                    for (len in minOf(4, k - idx) downTo 1) {
                        val chunkSyl = sylList.subList(idx, idx + len).joinToString("")
                        val words = dict.lookupPinyin(chunkSyl)
                        if (words.isNotEmpty()) {
                            val tailRes = combine(idx + len)
                            for (w in words.take(4)) {
                                for (t in tailRes.take(4)) {
                                    res.add(w + t)
                                    if (res.size >= 25) break
                                }
                                if (res.size >= 25) break
                            }
                        }
                    }
                    return res
                }
                val combos = combine(0)
                // 高频词条优先排在前列
                for (c in combos) {
                    results.add(c)
                }
            }
        }

        val finalCandidates = if (results.isNotEmpty()) results.toList() else listOf(d)
        return PinyinSearchResult(bestPinyinDisplay, finalCandidates)
    }

    /**
     * 搜狗级：Bigram 双词二元联想预测
     */
    fun predictNextWords(lastWord: String): List<String> {
        val clean = lastWord.trim()
        if (clean.isEmpty()) return emptyList()

        val dict = binaryDict ?: return emptyList()
        val exact = dict.lookupBigram(clean)
        if (exact.isNotEmpty()) {
            return exact
        }

        if (clean.length > 2) {
            val tail2 = clean.takeLast(2)
            val tailMatch = dict.lookupBigram(tail2)
            if (tailMatch.isNotEmpty()) {
                return tailMatch
            }
        }

        return emptyList()
    }

    companion object {
        @Volatile
        private var instance: PinyinDictionaryEngine? = null

        fun getInstance(context: Context): PinyinDictionaryEngine {
            return instance ?: synchronized(this) {
                instance ?: PinyinDictionaryEngine(context.applicationContext).also { instance = it }
            }
        }
    }
}
