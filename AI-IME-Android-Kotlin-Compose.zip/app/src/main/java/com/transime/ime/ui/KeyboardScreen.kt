package com.transime.ime.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.transime.ime.data.PreferencesManager
import com.transime.ime.data.PinyinDictionaryEngine
import com.transime.ime.data.TranslationMode
import com.transime.ime.network.GeminiTranslationService
import com.transime.ime.speech.SpeechRecognitionHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 键盘布局模式枚举
 */
enum class KeyboardLayoutType {
    CHINESE_9KEY,     // 中文九宫格 (T9)
    CHINESE_26KEY,    // 中文 26 键全拼
    ENGLISH,          // 独立英文 26 键键盘 (直接输出英文字符)
    VIETNAMESE,       // 越南语专用键盘 (含 Ư, Ơ, Đ, Ê, Ă, Â, Ô 及 5 声调)
    SYMBOLS           // 符号键盘 (?123 含 ₫ 越盾、¥ 人民币、金融货币与标点)
}

/**
 * Jetpack Compose AI输入法核心主界面
 */
@Composable
fun KeyboardScreen(
    preferencesManager: PreferencesManager,
    onCommitText: (String) -> Unit,
    onDeleteBackward: () -> Unit,
    onPerformEditorAction: (Int) -> Unit,
    onSwitchToNextInputMethod: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isTranslateEnabled by remember { mutableStateOf(preferencesManager.isTranslateEnabled()) }
    var currentMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }

    var currentLayout by remember { mutableStateOf(KeyboardLayoutType.CHINESE_9KEY) }

    var inputText by remember { mutableStateOf("") }
    var translatedText by remember { mutableStateOf("") }
    var detectedLanguage by remember { mutableStateOf("") }
    var translationNotes by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }
    var isListeningVoice by remember { mutableStateOf(false) }

    // 拼音与候选词状态
    var t9Digits by remember { mutableStateOf("") }
    var pinyin26Query by remember { mutableStateOf("") }
    var candidates by remember { mutableStateOf(listOf<String>()) }

    val pinyinEngine = remember { PinyinDictionaryEngine.getInstance(context) }
    LaunchedEffect(Unit) {
        pinyinEngine.loadDictionaryIfNeeded()
    }

    val translationService = remember { GeminiTranslationService(context, preferencesManager) }
    val speechHelper = remember {
        SpeechRecognitionHelper(context) { resultText, isFinal ->
            if (isTranslateEnabled) {
                inputText = resultText
            } else {
                onCommitText(resultText)
            }
            if (isFinal) {
                isListeningVoice = false
            }
        }
    }

    var debounceJob by remember { mutableStateOf<Job?>(null) }

    // 仅当“翻译模式开启”时，防抖触发 Gemini Flash 实时互译
    LaunchedEffect(inputText, currentMode, isTranslateEnabled) {
        if (!isTranslateEnabled || inputText.isBlank()) {
            translatedText = ""
            detectedLanguage = ""
            translationNotes = ""
            return@LaunchedEffect
        }

        debounceJob?.cancel()
        debounceJob = coroutineScope.launch {
            delay(300) // 300ms 防抖响应
            isTranslating = true
            try {
                val result = translationService.translateText(
                    text = inputText,
                    mode = currentMode
                )
                translatedText = result.translatedText
                detectedLanguage = result.detectedLang
                translationNotes = result.notes
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isTranslating = false
            }
        }
    }

    // T9 与 26 键拼音候选词查询算法 (搭载长拼音分词切分连打算法)
    LaunchedEffect(t9Digits) {
        if (t9Digits.isEmpty()) {
            if (pinyin26Query.isEmpty()) candidates = emptyList()
        } else {
            candidates = pinyinEngine.searchByT9(t9Digits)
        }
    }

    LaunchedEffect(pinyin26Query) {
        if (pinyin26Query.isEmpty()) {
            if (t9Digits.isEmpty()) candidates = emptyList()
        } else {
            candidates = pinyinEngine.searchByPinyin(pinyin26Query)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF121622))
            .padding(bottom = 6.dp)
    ) {
        // ================= 1. 顶部工具栏 =================
        TopToolbar(
            isTranslateEnabled = isTranslateEnabled,
            onToggleTranslate = {
                isTranslateEnabled = it
                preferencesManager.setTranslateEnabled(it)
                if (!it) {
                    // 关闭翻译时，清空翻译缓存
                    inputText = ""
                    translatedText = ""
                }
            },
            currentMode = currentMode,
            onModeSelected = {
                currentMode = it
                preferencesManager.saveDefaultMode(it)
            },
            currentLayout = currentLayout,
            onSelectLayout = { currentLayout = it },
            isListeningVoice = isListeningVoice,
            onToggleVoice = {
                if (isListeningVoice) {
                    speechHelper.stopListening()
                    isListeningVoice = false
                } else {
                    val langCode = when (currentLayout) {
                        KeyboardLayoutType.VIETNAMESE -> "vi-VN"
                        KeyboardLayoutType.ENGLISH -> "en-US"
                        else -> "zh-CN"
                    }
                    speechHelper.startListening(langCode)
                    isListeningVoice = true
                }
            },
            onSwitchIme = onSwitchToNextInputMethod
        )

        // ================= 2. 翻译状态栏 (开启翻译模式时显示) =================
        if (isTranslateEnabled) {
            DualPanePreviewBar(
                inputText = inputText,
                translatedText = translatedText,
                detectedLanguage = detectedLanguage,
                translationNotes = translationNotes,
                isTranslating = isTranslating,
                onClearInput = {
                    inputText = ""
                    translatedText = ""
                    t9Digits = ""
                    pinyin26Query = ""
                    candidates = emptyList()
                },
                onCommit = {
                    val textToCommit = if (translatedText.isNotBlank()) translatedText else inputText
                    if (textToCommit.isNotBlank()) {
                        onCommitText(textToCommit)
                        inputText = ""
                        translatedText = ""
                        t9Digits = ""
                        pinyin26Query = ""
                        candidates = emptyList()
                    }
                }
            )
        }

        // ================= 3. 拼音候选词条 (打字时显示) =================
        if (candidates.isNotEmpty()) {
            CandidateSelectionStrip(
                composingInfo = if (t9Digits.isNotEmpty()) "[$t9Digits]" else "[$pinyin26Query]",
                candidates = candidates,
                onSelectCandidate = { cand ->
                    if (isTranslateEnabled) {
                        inputText += cand
                    } else {
                        onCommitText(cand)
                    }
                    t9Digits = ""
                    pinyin26Query = ""
                    candidates = emptyList()
                }
            )
        }

        // ================= 4. 越南语声调与特殊字母工具栏 =================
        if (currentLayout == KeyboardLayoutType.VIETNAMESE) {
            VietnameseToneStrip(
                onAppendTone = { toneChar ->
                    if (isTranslateEnabled) {
                        inputText += toneChar
                    } else {
                        onCommitText(toneChar)
                    }
                }
            )
        }

        // ================= 5. 虚拟键盘主体按键区域 (适度调高按键高度至 48~50dp) =================
        when (currentLayout) {
            KeyboardLayoutType.CHINESE_9KEY -> {
                Chinese9KeyPad(
                    onDigitPress = { digit -> t9Digits += digit },
                    onPunctuationPress = { punc ->
                        if (isTranslateEnabled) inputText += punc else onCommitText(punc)
                    },
                    onSpace = {
                        if (candidates.isNotEmpty()) {
                            val pick = candidates[0]
                            if (isTranslateEnabled) inputText += pick else onCommitText(pick)
                            t9Digits = ""
                        } else {
                            if (isTranslateEnabled) inputText += " " else onCommitText(" ")
                        }
                    },
                    onDelete = {
                        if (t9Digits.isNotEmpty()) {
                            t9Digits = t9Digits.dropLast(1)
                        } else if (isTranslateEnabled && inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchTo26 = { currentLayout = KeyboardLayoutType.CHINESE_26KEY },
                    onSwitchToEnglish = { currentLayout = KeyboardLayoutType.ENGLISH },
                    onSwitchToVietnamese = { currentLayout = KeyboardLayoutType.VIETNAMESE },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.CHINESE_26KEY -> {
                QwertyPad(
                    layoutType = KeyboardLayoutType.CHINESE_26KEY,
                    onCharPress = { char ->
                        pinyin26Query += char.lowercase()
                    },
                    onSpace = {
                        if (candidates.isNotEmpty()) {
                            val pick = candidates[0]
                            if (isTranslateEnabled) inputText += pick else onCommitText(pick)
                            pinyin26Query = ""
                        } else {
                            if (isTranslateEnabled) inputText += " " else onCommitText(" ")
                        }
                    },
                    onDelete = {
                        if (pinyin26Query.isNotEmpty()) {
                            pinyin26Query = pinyin26Query.dropLast(1)
                        } else if (isTranslateEnabled && inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchTo9Key = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onSwitchToEnglish = { currentLayout = KeyboardLayoutType.ENGLISH },
                    onSwitchToVietnamese = { currentLayout = KeyboardLayoutType.VIETNAMESE },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.ENGLISH -> {
                QwertyPad(
                    layoutType = KeyboardLayoutType.ENGLISH,
                    onCharPress = { char ->
                        if (isTranslateEnabled) inputText += char else onCommitText(char)
                    },
                    onSpace = {
                        if (isTranslateEnabled) inputText += " " else onCommitText(" ")
                    },
                    onDelete = {
                        if (isTranslateEnabled && inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchTo9Key = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onSwitchToEnglish = { currentLayout = KeyboardLayoutType.CHINESE_26KEY },
                    onSwitchToVietnamese = { currentLayout = KeyboardLayoutType.VIETNAMESE },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.VIETNAMESE -> {
                VietnameseNativePad(
                    onCharPress = { char ->
                        if (isTranslateEnabled) inputText += char else onCommitText(char)
                    },
                    onSpace = {
                        if (isTranslateEnabled) inputText += " " else onCommitText(" ")
                    },
                    onDelete = {
                        if (isTranslateEnabled && inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onSwitchToChinese = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onSwitchToEnglish = { currentLayout = KeyboardLayoutType.ENGLISH },
                    onSwitchToSymbols = { currentLayout = KeyboardLayoutType.SYMBOLS },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }

            KeyboardLayoutType.SYMBOLS -> {
                SymbolAndCurrencyPad(
                    onSymbolPress = { sym ->
                        if (isTranslateEnabled) inputText += sym else onCommitText(sym)
                    },
                    onSpace = {
                        if (isTranslateEnabled) inputText += " " else onCommitText(" ")
                    },
                    onDelete = {
                        if (isTranslateEnabled && inputText.isNotEmpty()) {
                            inputText = inputText.dropLast(1)
                        } else {
                            onDeleteBackward()
                        }
                    },
                    onReturnToKeyboard = { currentLayout = KeyboardLayoutType.CHINESE_9KEY },
                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }
                )
            }
        }
    }
}

/**
 * 顶部工具栏 (整合打字/翻译开关、键盘语种快切、语音、切换输入法)
 */
@Composable
fun TopToolbar(
    isTranslateEnabled: Boolean,
    onToggleTranslate: (Boolean) -> Unit,
    currentMode: TranslationMode,
    onModeSelected: (TranslationMode) -> Unit,
    currentLayout: KeyboardLayoutType,
    onSelectLayout: (KeyboardLayoutType) -> Unit,
    isListeningVoice: Boolean,
    onToggleVoice: () -> Unit,
    onSwitchIme: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0D111A))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // 打字 / 翻译 核心模式切换开关
            Button(
                onClick = { onToggleTranslate(!isTranslateEnabled) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isTranslateEnabled) Color(0xFF10B981) else Color(0xFF262D3D)
                ),
                contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(32.dp)
            ) {
                Icon(
                    Icons.Default.Translate,
                    contentDescription = null,
                    modifier = Modifier.size(13.dp),
                    tint = if (isTranslateEnabled) Color.White else Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    if (isTranslateEnabled) "AI翻译开" else "普通打字",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isTranslateEnabled) Color.White else Color(0xFFCBD5E1)
                )
            }

            // 翻译目标语切换 (仅在开启翻译时高亮)
            if (isTranslateEnabled) {
                Button(
                    onClick = {
                        val nextMode = if (currentMode == TranslationMode.ZH_EN) TranslationMode.ZH_VI else TranslationMode.ZH_EN
                        onModeSelected(nextMode)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        if (currentMode == TranslationMode.ZH_EN) "中 ⇄ 英" else "中 ⇄ 越",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF38BDF8)
                    )
                }
            } else {
                // 普通打字模式下的当前键盘标签指示
                val layoutLabel = when (currentLayout) {
                    KeyboardLayoutType.CHINESE_9KEY -> "拼音九键"
                    KeyboardLayoutType.CHINESE_26KEY -> "拼音26键"
                    KeyboardLayoutType.ENGLISH -> "英文键盘"
                    KeyboardLayoutType.VIETNAMESE -> "越南语"
                    KeyboardLayoutType.SYMBOLS -> "符号"
                }
                Box(
                    modifier = Modifier
                        .background(Color(0xFF1E293B), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(layoutLabel, fontSize = 11.sp, color = Color(0xFF94A3B8))
                }
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // 语音识别麦克风
            IconButton(
                onClick = onToggleVoice,
                modifier = Modifier
                    .size(34.dp)
                    .background(
                        if (isListeningVoice) Color(0xFFEF4444) else Color(0xFF262D3D),
                        CircleShape
                    )
            ) {
                Icon(
                    imageVector = if (isListeningVoice) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "语音",
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }

            // 切换系统其他输入法小地球 (点击弹出系统选择器，确保随时自由切回)
            IconButton(
                onClick = onSwitchIme,
                modifier = Modifier
                    .size(34.dp)
                    .background(Color(0xFF262D3D), CircleShape)
            ) {
                Icon(
                    Icons.Default.Language,
                    contentDescription = "切换输入法",
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}

/**
 * 双栏预览条 (识别原文 + AI 译文 + 一键上屏按钮)
 */
@Composable
fun DualPanePreviewBar(
    inputText: String,
    translatedText: String,
    detectedLanguage: String,
    translationNotes: String,
    isTranslating: Boolean,
    onClearInput: () -> Unit,
    onCommit: () -> Unit
) {
    if (inputText.isBlank() && translatedText.isBlank()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 2.dp)
                .background(Color(0xFF1B202E), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 7.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "打字或按麦克风语音录入，Gemini 实时双向互译...",
                color = Color(0xFF64748B),
                fontSize = 12.sp
            )
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 2.dp)
            .background(Color(0xFF1B202E), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        // 原文行
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "原文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                modifier = Modifier.width(36.dp)
            )
            Text(
                text = inputText,
                fontSize = 13.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClearInput, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "清空", tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 译文行 + 一键上屏按钮
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "译文:",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF10B981),
                modifier = Modifier.width(36.dp)
            )

            if (isTranslating) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        color = Color(0xFF10B981),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("AI 翻译中...", fontSize = 12.sp, color = Color(0xFF10B981))
                }
            } else {
                Text(
                    text = translatedText.ifEmpty { "等待输入..." },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF34D399),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Button(
                onClick = onCommit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("上屏", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

/**
 * 拼音候选词条
 */
@Composable
fun CandidateSelectionStrip(
    composingInfo: String,
    candidates: List<String>,
    onSelectCandidate: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161B26))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(composingInfo, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))

        candidates.forEachIndexed { index, cand ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF262E40))
                    .clickable { onSelectCandidate(cand) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "${index + 1}. $cand",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * 越南语 5 声调与特殊字母快捷栏 (清晰显示 sắc / huyền / hỏi / ngã / nặng 及 đ, ơ, ư)
 */
@Composable
fun VietnameseToneStrip(
    onAppendTone: (String) -> Unit
) {
    val tones = listOf(
        "sắc (´)" to "́",
        "huyền (`)" to "̀",
        "hỏi (?)" to "̉",
        "ngã (~)" to "̃",
        "nặng (.)" to "̣",
        "đ" to "đ",
        "ơ" to "ơ",
        "ư" to "ư",
        "ê" to "ê",
        "ô" to "ô",
        "â" to "â",
        "ă" to "ă"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161F2E))
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        tones.forEach { (label, value) ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF26354D))
                    .clickable { onAppendTone(value) }
                    .padding(horizontal = 9.dp, vertical = 5.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
            }
        }
    }
}

/**
 * ================= 中文九宫格 (T9) 键盘 =================
 */
@Composable
fun Chinese9KeyPad(
    onDigitPress: (String) -> Unit,
    onPunctuationPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchTo26: () -> Unit,
    onSwitchToEnglish: () -> Unit,
    onSwitchToVietnamese: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 左列：快捷标点
        Column(
            modifier = Modifier.width(48.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("，", "。", "？", "！").forEach { punc ->
                ActionKey(label = punc, modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = Color(0xFF232938)) {
                    onPunctuationPress(punc)
                }
            }
        }

        // 中间：3x3 九宫格数字键 + 底部辅助行
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            val t9Keys = listOf(
                listOf("1" to "符/标点", "2" to "ABC", "3" to "DEF"),
                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ")
            )

            t9Keys.forEach { row ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEach { (digit, letters) ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color(0xFF2C3446))
                                .clickable {
                                    if (digit == "1") onSwitchToSymbols()
                                    else onDigitPress(digit)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(digit, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                                Text(letters, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color(0xFFCBD5E1))
                            }
                        }
                    }
                }
            }

            // 底部辅助行: 26全拼 / 英文 / 越语 / 空格
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ActionKey(label = "全拼", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF232938)) {
                    onSwitchTo26()
                }
                ActionKey(label = "英文", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF1E3A5F)) {
                    onSwitchToEnglish()
                }
                ActionKey(label = "空格 (选词)", modifier = Modifier.weight(2.2f).height(48.dp), bgColor = Color(0xFF2C3446)) {
                    onSpace()
                }
                ActionKey(label = "越语", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF0369A1)) {
                    onSwitchToVietnamese()
                }
            }
        }

        // 右列：操作键 (退格、符号、发送)
        Column(
            modifier = Modifier.width(54.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ActionKey(label = "⌫", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = Color(0xFF374151)) {
                onDelete()
            }
            ActionKey(label = "?123", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = Color(0xFF232938)) {
                onSwitchToSymbols()
            }
            ActionKey(label = "换行", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = Color(0xFF232938)) {
                onPunctuationPress("\n")
            }
            ActionKey(label = "发送", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = Color(0xFF10B981)) {
                onEnter()
            }
        }
    }
}

/**
 * ================= QWERTY 键盘 (支持 中文26键全拼 与 纯英文键盘) =================
 */
@Composable
fun QwertyPad(
    layoutType: KeyboardLayoutType,
    onCharPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchTo9Key: () -> Unit,
    onSwitchToEnglish: () -> Unit,
    onSwitchToVietnamese: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    var isShifted by remember { mutableStateOf(false) }

    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P")
    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L")
    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row1.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row2.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(
                label = if (isShifted) "⇧ 大写" else "⇧",
                modifier = Modifier.weight(1.4f).height(48.dp),
                bgColor = if (isShifted) Color(0xFF38BDF8) else Color(0xFF232938)
            ) {
                isShifted = !isShifted
            }
            row3.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.4f).height(48.dp), bgColor = Color(0xFF374151)) { onDelete() }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(label = "?123", modifier = Modifier.weight(1.4f).height(48.dp), bgColor = Color(0xFF232938)) { onSwitchToSymbols() }
            if (layoutType == KeyboardLayoutType.CHINESE_26KEY) {
                ActionKey(label = "九宫", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = Color(0xFF047857)) { onSwitchTo9Key() }
                ActionKey(label = "英", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = Color(0xFF1E3A5F)) { onSwitchToEnglish() }
            } else {
                ActionKey(label = "中", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = Color(0xFF047857)) { onSwitchTo9Key() }
                ActionKey(label = "越", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = Color(0xFF0369A1)) { onSwitchToVietnamese() }
            }
            ActionKey(
                label = if (layoutType == KeyboardLayoutType.CHINESE_26KEY) "空格 (选词)" else "Space",
                modifier = Modifier.weight(3.5f).height(48.dp),
                bgColor = Color(0xFF2C3446)
            ) { onSpace() }
            ActionKey(label = ".", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF2C3446)) { onCharPress(".") }
            ActionKey(label = "发送", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * ================= 越南语原生键盘 =================
 */
@Composable
fun VietnameseNativePad(
    onCharPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onSwitchToChinese: () -> Unit,
    onSwitchToEnglish: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onEnter: () -> Unit
) {
    var isShifted by remember { mutableStateOf(false) }

    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "Ư", "Ơ")
    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L", "Đ", "Ê")
    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M", "Ă", "Â", "Ô")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            row1.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            row2.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            ActionKey(
                label = if (isShifted) "⇧ 大写" else "⇧",
                modifier = Modifier.weight(1.3f).height(48.dp),
                bgColor = if (isShifted) Color(0xFF38BDF8) else Color(0xFF232938)
            ) { isShifted = !isShifted }
            row3.forEach { key ->
                val display = if (isShifted) key else key.lowercase()
                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }
            }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = Color(0xFF374151)) { onDelete() }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            ActionKey(label = "?123", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = Color(0xFF232938)) { onSwitchToSymbols() }
            ActionKey(label = "中文", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = Color(0xFF047857)) { onSwitchToChinese() }
            ActionKey(label = "英文", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = Color(0xFF1E3A5F)) { onSwitchToEnglish() }
            ActionKey(label = "Space", modifier = Modifier.weight(3.5f).height(48.dp), bgColor = Color(0xFF2C3446)) { onSpace() }
            ActionKey(label = ".", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF2C3446)) { onCharPress(".") }
            ActionKey(label = "发送", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * ================= 符号键盘 (?123 含 ₫ 越盾、¥ 人民币、标点) =================
 */
@Composable
fun SymbolAndCurrencyPad(
    onSymbolPress: (String) -> Unit,
    onSpace: () -> Unit,
    onDelete: () -> Unit,
    onReturnToKeyboard: () -> Unit,
    onEnter: () -> Unit
) {
    val symbolRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("₫", "¥", "$", "€", "£", "%", "@", "#", "&", "*"),
        listOf("，", "。", "！", "？", "：", "；", "“", "”", "（", "）"),
        listOf("—", "/", "\\", "+", "-", "=", "<", ">", "[", "]")
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        symbolRows.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { sym ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sym == "₫" || sym == "¥") Color(0xFF065F46) else Color(0xFF2B3345))
                            .clickable { onSymbolPress(sym) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sym,
                            fontSize = 15.sp,
                            fontWeight = if (sym == "₫" || sym == "¥") FontWeight.Bold else FontWeight.Medium,
                            color = if (sym == "₫" || sym == "¥") Color(0xFF34D399) else Color.White
                        )
                    }
                }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            ActionKey(label = "返回", modifier = Modifier.weight(1.8f).height(48.dp), bgColor = Color(0xFF047857)) { onReturnToKeyboard() }
            ActionKey(label = "空格 (Space)", modifier = Modifier.weight(4f).height(48.dp), bgColor = Color(0xFF2C3446)) { onSpace() }
            ActionKey(label = "⌫", modifier = Modifier.weight(1.5f).height(48.dp), bgColor = Color(0xFF374151)) { onDelete() }
            ActionKey(label = "发送", modifier = Modifier.weight(1.8f).height(48.dp), bgColor = Color(0xFF10B981)) { onEnter() }
        }
    }
}

/**
 * 字符按键组件
 */
@Composable
fun CharKey(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0xFF2C3446))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * 功能/操作按键组件
 */
@Composable
fun ActionKey(label: String, modifier: Modifier = Modifier, bgColor: Color, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(7.dp))
            .background(bgColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
