package com.transime.ime.ui







import android.content.ClipData



import android.content.ClipboardManager



import android.content.Context



import androidx.compose.animation.*



import androidx.compose.foundation.ExperimentalFoundationApi



import androidx.compose.foundation.background



import androidx.compose.foundation.clickable



import androidx.compose.foundation.combinedClickable



import androidx.compose.foundation.gestures.detectDragGestures



import androidx.compose.foundation.gestures.detectTapGestures



import androidx.compose.foundation.horizontalScroll



import androidx.compose.foundation.layout.*



import androidx.compose.foundation.lazy.grid.GridCells



import androidx.compose.foundation.lazy.grid.LazyVerticalGrid



import androidx.compose.foundation.lazy.grid.items



import androidx.compose.foundation.rememberScrollState



import androidx.compose.foundation.verticalScroll



import androidx.compose.foundation.shape.CircleShape



import androidx.compose.foundation.shape.RoundedCornerShape



import androidx.compose.material.icons.Icons



import androidx.compose.material.icons.filled.*



import androidx.compose.material3.*



import androidx.compose.runtime.*



import androidx.compose.ui.Alignment



import androidx.compose.ui.Modifier



import androidx.compose.ui.draw.clip



import androidx.compose.ui.graphics.Color



import androidx.compose.ui.input.pointer.pointerInput



import androidx.compose.ui.platform.LocalContext



import androidx.compose.ui.text.font.FontWeight



import androidx.compose.ui.text.style.TextOverflow



import androidx.compose.ui.unit.dp



import androidx.compose.ui.unit.sp



import com.transime.ime.data.PreferencesManager



import com.transime.ime.data.PinyinDictionaryEngine



import com.transime.ime.data.TranslationMode



import com.transime.ime.network.GeminiTranslationService



import kotlinx.coroutines.launch







/**



 * 键盘布局模式枚举



 */



enum class KeyboardLayoutType {



    CHINESE_9KEY,     // 中文九宫格 (T9)



    CHINESE_26KEY,    // 中文 26 键全拼



    ENGLISH,          // 独立英文 26 键键盘 (直接输出英文字符)



    VIETNAMESE,       // 越南语专用键盘 (含 Ư, Ơ, Đ, Ê, Ă, Â, Ô 及 5 声调)



    SYMBOLS,          // 符号键盘 (?123 分类大符号库)



    EMOJI,            // Emoji 与表情符号面板 (搜狗级常用/手势/心情/物品分类)



    CLIPBOARD         // 剪切板管理面板



}







/**



 * Jetpack Compose AI输入法核心主界面



 */



// =========================================================================
// 搜狗输入法正统官方配色系统 (Sogou Classic Keyboard Theme Palette)
// =========================================================================
object SogouTheme {
    val KeyboardBg = Color(0xFFECEFF2)            // 搜狗标准浅冷灰键盘底色
    val ToolbarBg = Color(0xFFE4E8EC)             // 顶部工具栏底色
    val ToolbarBtnBg = Color(0xFFD6DBE2)          // 顶部工具栏按键底色
    val KeyCharBg = Color(0xFFFFFFFF)             // 字符/拼音/九键主按键纯白底色
    val KeyActionBg = Color(0xFFD5DCE4)           // 功能按键（切换、退格、符号）灰白底色
    val KeyOrange = Color(0xFFF56400)             // 搜狗标志性亮橙（发送/回车/高亮/主选）
    val KeyOrangeSoft = Color(0xFFFF7033)         // 搜狗活力橙次级渐变/强调色
    val TextPrimary = Color(0xFF1F2328)           // 搜狗主文字深灰/纯黑
    val TextSecondary = Color(0xFF81818E)         // 搜狗次级文字/九键字母索引灰色
    val TextLight = Color(0xFF9AA0A6)             // 浅灰说明文字
    val CandidateStripBg = Color(0xFFFFFFFF)      // 候选词条纯白背景
    val CandidateBorder = Color(0xFFE2E6EA)       // 候选词与面板微边框
    val ExpandedPanelBg = Color(0xFFECEFF2)       // 展开全屏候选面板底色
    val ComposingText = Color(0xFFF56400)         // 拼音Composing搜狗橙
}

@Composable
fun KeyboardScreen(



    preferencesManager: PreferencesManager,



    onCommitText: (String) -> Unit,



    onDeleteBackward: () -> Unit,



    onDeleteAll: () -> Unit,



    onMoveCursorLeft: () -> Unit,



    onMoveCursorRight: () -> Unit,



    onCopyText: () -> Unit,



    onCutText: () -> Unit,



    onPasteText: () -> Unit,



    onPerformEditorAction: (Int) -> Unit,



    onSwitchToNextInputMethod: () -> Unit



) {



    val context = LocalContext.current



    val coroutineScope = rememberCoroutineScope()



    val clipboardManager = remember {



        context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager



    }







    var isTranslateEnabled by remember { mutableStateOf(preferencesManager.isTranslateEnabled()) }



    var currentMode by remember { mutableStateOf(preferencesManager.getDefaultMode()) }



    var isFuzzyEnabled by remember { mutableStateOf(preferencesManager.isFuzzyPinyinEnabled()) }







    var currentLayout by remember {

        val savedLayout = try {

            KeyboardLayoutType.valueOf(preferencesManager.getLastKeyboardLayout())

        } catch (e: Exception) {

            KeyboardLayoutType.CHINESE_9KEY

        }

        mutableStateOf(savedLayout)

    }



    // 辅助切换并持久化键盘布局

    fun updateLayout(newLayout: KeyboardLayoutType) {

        currentLayout = newLayout

        // 不持久化临时状态（如剪贴板面板），其他键盘布局均持久化保存

        if (newLayout != KeyboardLayoutType.CLIPBOARD && newLayout != KeyboardLayoutType.EMOJI) {

            preferencesManager.setLastKeyboardLayout(newLayout.name)

        }

    }







    var inputText by remember { mutableStateOf("") }



    var translatedText by remember { mutableStateOf("") }



    var detectedLanguage by remember { mutableStateOf("") }



    var translationNotes by remember { mutableStateOf("") }



    var isTranslating by remember { mutableStateOf(false) }







    // 拼音与候选词状态



    var t9Digits by remember { mutableStateOf("") }



    var pinyin26Query by remember { mutableStateOf("") }



    var composingDisplay by remember { mutableStateOf("") }



    var candidates by remember { mutableStateOf(listOf<String>()) }



    var isCandidateExpanded by remember { mutableStateOf(false) }



    // 搜狗级：左侧拼音分流筛选器 (输入 534 时呈现: kei, lei, ke, le, j)



    var pinyinFilters by remember { mutableStateOf(listOf<String>()) }



    var activeFilter by remember { mutableStateOf<String?>(null) }







    // 历史剪切板列表



    var clipboardHistory by remember { mutableStateOf(listOf<String>()) }



    var lastCommittedWord by remember { mutableStateOf("") }



    var isPredictionMode by remember { mutableStateOf(false) }







    // 搜狗级：双击空格出句号时间戳追踪 (350ms 内双击空格触发)



    var lastSpacePressTime by remember { mutableLongStateOf(0L) }







    // 搜狗级：AI 划词/复制悬浮气泡胶囊 (检测到剪切板最新内容时推荐翻译)



    var latestCopiedSnippet by remember { mutableStateOf("") }



    var showCopyTranslateCapsule by remember { mutableStateOf(false) }







    fun refreshClipboard() {



        try {



            val primary = clipboardManager.primaryClip



            if (primary != null && primary.itemCount > 0) {



                val list = mutableListOf<String>()



                for (i in 0 until primary.itemCount) {



                    val text = primary.getItemAt(i).text?.toString()



                    if (!text.isNullOrBlank() && text !in list) {



                        list.add(text)



                    }



                }



                clipboardHistory = list



                val topItem = list.firstOrNull()?.trim()



                if (!topItem.isNullOrBlank() && topItem != latestCopiedSnippet) {



                    latestCopiedSnippet = topItem



                    showCopyTranslateCapsule = true



                }



            }



        } catch (e: Exception) {



            e.printStackTrace()



        }



    }







    // 定期与启动时轮询检测系统剪切板变更



    LaunchedEffect(Unit) {



        refreshClipboard()



    }







    // 搜狗级：智能成对标点符号映射与空格双击处理逻辑



    val handleSmartSymbolInput: (String) -> Unit = { sym ->



        val pairMap = mapOf(



            "(" to "()",



            "（" to "（）",



            "[" to "[]",



            "【" to "【】",



            "{" to "{}",



            "《" to "《》",



            "“" to "“”",



            "‘" to "‘’",



            "<" to "<>"



        )



        val textToInsert = pairMap[sym] ?: sym



        if (isTranslateEnabled) {



            inputText += textToInsert



        } else {



            onCommitText(textToInsert)



            if (pairMap.containsKey(sym)) {



                onMoveCursorLeft()



            }



        }



    }







    val handleSpaceKeyWithPeriodCheck: () -> Unit = {



        val now = System.currentTimeMillis()



        if (now - lastSpacePressTime < 350L) {



            // 双击空格转换为中文句号或英文句号



            onDeleteBackward()



            val period = if (currentLayout == KeyboardLayoutType.ENGLISH) ". " else "。"



            if (isTranslateEnabled) {



                if (inputText.endsWith(" ")) inputText = inputText.dropLast(1)



                inputText += period



            } else {



                onCommitText(period)



            }



            lastSpacePressTime = 0L



        } else {



            lastSpacePressTime = now



            if (isTranslateEnabled) {



                inputText += " "



            } else {



                onCommitText(" ")



            }



        }



    }







    val pinyinEngine = remember { PinyinDictionaryEngine.getInstance(context) }



    LaunchedEffect(Unit) {



        pinyinEngine.loadDictionaryIfNeeded()



    }







    val translationService = remember { GeminiTranslationService(context, preferencesManager) }







    // 主动触发翻译动作



    fun triggerTranslation() {



        if (inputText.isBlank()) return



        coroutineScope.launch {



            isTranslating = true



            try {



                val result = translationService.translateText(



                    text = inputText,



                    mode = currentMode



                )



                translatedText = result.translatedText



                detectedLanguage = result.detectedLang



                translationNotes = result.notes



            } catch (e: Exception) {



                e.printStackTrace()



            } finally {



                isTranslating = false



            }



        }



    }











    // 选中某个候选词并触发后续二元预测联想



    val handlePickCandidate: (String) -> Unit = { cand ->



        if (isTranslateEnabled) {



            inputText += cand



        } else {



            onCommitText(cand)



        }



        t9Digits = ""



        pinyin26Query = ""



        composingDisplay = ""



        isCandidateExpanded = false







        // 搜狗级：Bigram 下一词预测联想



        val nextPredictions = pinyinEngine.predictNextWords(cand)



        if (nextPredictions.isNotEmpty()) {



            candidates = nextPredictions



            composingDisplay = "联想:"



            isPredictionMode = true



        } else {



            candidates = emptyList()



            isPredictionMode = false



        }



        lastCommittedWord = cand



    }



    // 搜狗级：异步协程毫秒级检索，支持模糊音智能纠错，彻底解耦 UI 渲染线程



    LaunchedEffect(t9Digits, activeFilter, isFuzzyEnabled) {



        if (t9Digits.isEmpty()) {



            activeFilter = null



            pinyinFilters = emptyList()



            if (pinyin26Query.isEmpty() && !isPredictionMode) {



                candidates = emptyList()



                composingDisplay = ""



            }



        } else {



            isPredictionMode = false



            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {



                val filter = activeFilter



                if (filter != null) {



                    val filteredCandidates = pinyinEngine.getCandidatesForPinyin(filter, isFuzzyEnabled)



                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {



                        candidates = filteredCandidates



                        composingDisplay = filter



                    }



                } else {



                    val res = pinyinEngine.searchByT9(t9Digits, isFuzzyEnabled)



                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {



                        candidates = res.candidates



                        composingDisplay = res.formattedPinyin



                        pinyinFilters = res.pinyinFilters



                    }



                }



            }



        }



    }







    LaunchedEffect(pinyin26Query, isFuzzyEnabled) {



        if (pinyin26Query.isEmpty()) {



            if (t9Digits.isEmpty() && !isPredictionMode) {



                candidates = emptyList()



                composingDisplay = ""



            }



        } else {



            isPredictionMode = false



            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {



                val res = pinyinEngine.searchByPinyin(pinyin26Query, isFuzzyEnabled)



                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {



                    candidates = res.candidates



                    composingDisplay = res.formattedPinyin



                }



            }



        }



    }







    // 处理长按删除键：清空所有输入



    val handleLongDelete: () -> Unit = {



        if (t9Digits.isNotEmpty()) {



            t9Digits = ""



            candidates = emptyList()



        } else if (pinyin26Query.isNotEmpty()) {



            pinyin26Query = ""



            candidates = emptyList()



        } else if (isTranslateEnabled && inputText.isNotEmpty()) {



            inputText = ""



            translatedText = ""



        } else {



            onDeleteAll()



        }



    }







    // 处理单次删除



    val handleSingleDelete: () -> Unit = {



        if (t9Digits.isNotEmpty()) {



            t9Digits = t9Digits.dropLast(1)



        } else if (pinyin26Query.isNotEmpty()) {



            pinyin26Query = pinyin26Query.dropLast(1)



        } else if (isTranslateEnabled && inputText.isNotEmpty()) {



            inputText = inputText.dropLast(1)



        } else {



            onDeleteBackward()



        }



    }







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .background(SogouTheme.KeyboardBg)



            .padding(bottom = 6.dp)



    ) {



        // ================= 0. 搜狗级：AI 划词/复制悬浮气泡胶囊 (检测到剪切板新内容) =================



        if (showCopyTranslateCapsule && latestCopiedSnippet.isNotBlank()) {



            Row(



                modifier = Modifier



                    .fillMaxWidth()



                    .padding(horizontal = 8.dp, vertical = 2.dp)



                    .clip(RoundedCornerShape(8.dp))



                    .background(SogouTheme.ToolbarBg)



                    .clickable {



                        inputText = latestCopiedSnippet



                        if (!isTranslateEnabled) {



                            isTranslateEnabled = true



                            preferencesManager.setTranslateEnabled(true)



                        }



                        triggerTranslation()



                        showCopyTranslateCapsule = false



                    }



                    .padding(horizontal = 10.dp, vertical = 6.dp),



                verticalAlignment = Alignment.CenterVertically



            ) {



                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(14.dp))



                Spacer(modifier = Modifier.width(6.dp))



                Text(



                    text = "AI 剪切板翻译: \"${latestCopiedSnippet.take(16)}\"...",



                    color = SogouTheme.TextPrimary,



                    fontSize = 11.sp,



                    maxLines = 1,



                    overflow = TextOverflow.Ellipsis,



                    modifier = Modifier.weight(1f)



                )



                Spacer(modifier = Modifier.width(6.dp))



                Text("一键翻译 ❯", color = SogouTheme.KeyOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)



                Spacer(modifier = Modifier.width(4.dp))



                Icon(



                    Icons.Default.Close,



                    contentDescription = "关闭提示",



                    tint = SogouTheme.TextSecondary,



                    modifier = Modifier



                        .size(16.dp)



                        .clickable { showCopyTranslateCapsule = false }



                )



            }



        }







        // ================= 1. 顶部工具栏 (含模式切换、Emoji、语音、编辑光标工具) =================



        TopToolbar(



            isTranslateEnabled = isTranslateEnabled,



            onToggleTranslate = {



                isTranslateEnabled = it



                preferencesManager.setTranslateEnabled(it)



                if (!it) {



                    inputText = ""



                    translatedText = ""



                }



            },



            currentMode = currentMode,



            onModeSelected = {



                currentMode = it



                preferencesManager.saveDefaultMode(it)



                if (inputText.isNotBlank()) {



                    triggerTranslation()



                }



            },



            currentLayout = currentLayout,



            onOpenClipboard = {



                refreshClipboard()



                val nextLayout = if (currentLayout == KeyboardLayoutType.CLIPBOARD) KeyboardLayoutType.CHINESE_9KEY else KeyboardLayoutType.CLIPBOARD

                updateLayout(nextLayout)



            },



            onOpenEmoji = {



                val nextLayout = if (currentLayout == KeyboardLayoutType.EMOJI) KeyboardLayoutType.CHINESE_9KEY else KeyboardLayoutType.EMOJI

                updateLayout(nextLayout)



            },



            isFuzzyEnabled = isFuzzyEnabled,



            onToggleFuzzy = {



                isFuzzyEnabled = it



                preferencesManager.setFuzzyPinyinEnabled(it)



            },



            onMoveCursorLeft = onMoveCursorLeft,



            onMoveCursorRight = onMoveCursorRight,



            onCopy = onCopyText,



            onCut = onCutText,



            onPaste = onPasteText,



            onSwitchIme = onSwitchToNextInputMethod



        )







        // ================= 2. 翻译状态栏 =================



        if (isTranslateEnabled) {



            DualPanePreviewBar(



                inputText = inputText,



                translatedText = translatedText,



                detectedLanguage = detectedLanguage,



                translationNotes = translationNotes,



                isTranslating = isTranslating,



                onTranslateClick = { triggerTranslation() },



                onClearInput = {



                    inputText = ""



                    translatedText = ""



                    t9Digits = ""



                    pinyin26Query = ""



                    candidates = emptyList()



                },



                onCommit = {



                    val textToCommit = if (translatedText.isNotBlank()) translatedText else inputText



                    if (textToCommit.isNotBlank()) {



                        onCommitText(textToCommit)



                        inputText = ""



                        translatedText = ""



                        t9Digits = ""



                        pinyin26Query = ""



                        candidates = emptyList()



                    }



                }



            )



        }







        // ================= 3. 拼音候选词条 (固定占位一行，高度 38dp，无论有无候选均不跳动挤压键盘) =================



        if (currentLayout == KeyboardLayoutType.CHINESE_9KEY || currentLayout == KeyboardLayoutType.CHINESE_26KEY) {



            CandidateSelectionStrip(



                composingInfo = composingDisplay,



                candidates = candidates,



                isExpanded = isCandidateExpanded,



                onToggleExpand = { isCandidateExpanded = !isCandidateExpanded },



                onSelectCandidate = handlePickCandidate



            )



        }







        // ================= 搜狗1:1：候选词全屏展开筛选大面板 (点击 ⌄ 展开，左侧拼音，中间候选，右侧操作) =================



        if (isCandidateExpanded && (candidates.isNotEmpty() || pinyinFilters.isNotEmpty())) {



            ExpandedCandidatePanel(



                candidates = candidates,



                pinyinFilters = pinyinFilters,



                activeFilter = activeFilter,



                onSelectFilter = { filter ->



                    activeFilter = if (activeFilter == filter) null else filter



                },
                onResetFilter = { activeFilter = null },



                onSelectCandidate = handlePickCandidate,



                onDelete = handleSingleDelete,



                onClear = {



                    t9Digits = ""



                    pinyin26Query = ""



                    activeFilter = null



                    candidates = emptyList()



                    isCandidateExpanded = false



                },



                onClose = { isCandidateExpanded = false }



            )



        }







        // ================= 4. 越南语声调与特殊字母工具栏 =================



        if (currentLayout == KeyboardLayoutType.VIETNAMESE) {



            VietnameseToneStrip(



                onAppendTone = { toneChar ->



                    if (isTranslateEnabled) {



                        inputText += toneChar



                    } else {



                        onCommitText(toneChar)



                    }



                }



            )



        }







        // ================= 5. 虚拟键盘主体按键区域 (支持长按整删/剪贴板面板) =================



        when (currentLayout) {



            KeyboardLayoutType.CLIPBOARD -> {



                ClipboardPanel(



                    history = clipboardHistory,



                    onSelect = { text ->



                        if (isTranslateEnabled) inputText += text else onCommitText(text)



                        updateLayout(KeyboardLayoutType.CHINESE_9KEY)



                    },



                    onClose = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) }



                )



            }







            KeyboardLayoutType.EMOJI -> {



                EmojiPanel(



                    onSelectEmoji = { emoji ->



                        if (isTranslateEnabled) inputText += emoji else onCommitText(emoji)



                    },



                    onDelete = handleSingleDelete,



                    onClose = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) }



                )



            }







            KeyboardLayoutType.CHINESE_9KEY -> {



                Chinese9KeyPad(



                    isTranslateEnabled = isTranslateEnabled,



                    onDigitPress = { digit -> t9Digits += digit },



                    onPunctuationPress = handleSmartSymbolInput,



                    onSpace = {



                        if (candidates.isNotEmpty()) {



                            handlePickCandidate(candidates[0])



                        } else {



                            if (isTranslateEnabled) inputText += " " else onCommitText(" ")



                        }



                    },



                    onMoveCursorLeft = onMoveCursorLeft,



                    onMoveCursorRight = onMoveCursorRight,



                    onDelete = handleSingleDelete,



                    onLongDelete = handleLongDelete,



                    onSwitchTo26 = { updateLayout(KeyboardLayoutType.CHINESE_26KEY) },



                    onSwitchToEnglish = { updateLayout(KeyboardLayoutType.ENGLISH) },



                    onSwitchToVietnamese = { updateLayout(KeyboardLayoutType.VIETNAMESE) },



                    onSwitchToSymbols = { updateLayout(KeyboardLayoutType.SYMBOLS) },



                    onTranslateAction = { triggerTranslation() },



                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }



                )



            }







            KeyboardLayoutType.CHINESE_26KEY -> {



                QwertyPad(



                    layoutType = KeyboardLayoutType.CHINESE_26KEY,



                    isTranslateEnabled = isTranslateEnabled,



                    onCharPress = { char ->



                        pinyin26Query += char.lowercase()



                    },



                    onSpace = {



                        if (candidates.isNotEmpty()) {



                            handlePickCandidate(candidates[0])



                        } else {



                            if (isTranslateEnabled) inputText += " " else onCommitText(" ")



                        }



                    },



                    onMoveCursorLeft = onMoveCursorLeft,



                    onMoveCursorRight = onMoveCursorRight,



                    onDelete = handleSingleDelete,



                    onLongDelete = handleLongDelete,



                    onSwitchTo9Key = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) },



                    onSwitchToEnglish = { updateLayout(KeyboardLayoutType.ENGLISH) },



                    onSwitchToVietnamese = { updateLayout(KeyboardLayoutType.VIETNAMESE) },



                    onSwitchToSymbols = { updateLayout(KeyboardLayoutType.SYMBOLS) },



                    onTranslateAction = { triggerTranslation() },



                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }



                )



            }







            KeyboardLayoutType.ENGLISH -> {



                QwertyPad(



                    layoutType = KeyboardLayoutType.ENGLISH,



                    isTranslateEnabled = isTranslateEnabled,



                    onCharPress = { char ->



                        if (isTranslateEnabled) inputText += char else onCommitText(char)



                    },



                    onSpace = {



                        if (isTranslateEnabled) inputText += " " else onCommitText(" ")



                    },



                    onMoveCursorLeft = onMoveCursorLeft,



                    onMoveCursorRight = onMoveCursorRight,



                    onDelete = handleSingleDelete,



                    onLongDelete = handleLongDelete,



                    onSwitchTo9Key = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) },



                    onSwitchToEnglish = { updateLayout(KeyboardLayoutType.CHINESE_26KEY) },



                    onSwitchToVietnamese = { updateLayout(KeyboardLayoutType.VIETNAMESE) },



                    onSwitchToSymbols = { updateLayout(KeyboardLayoutType.SYMBOLS) },



                    onTranslateAction = { triggerTranslation() },



                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }



                )



            }







            KeyboardLayoutType.VIETNAMESE -> {



                VietnameseNativePad(



                    isTranslateEnabled = isTranslateEnabled,



                    onCharPress = { char ->



                        if (isTranslateEnabled) inputText += char else onCommitText(char)



                    },



                    onSpace = {



                        if (isTranslateEnabled) inputText += " " else onCommitText(" ")



                    },



                    onDelete = handleSingleDelete,



                    onLongDelete = handleLongDelete,



                    onSwitchToChinese = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) },



                    onSwitchToEnglish = { updateLayout(KeyboardLayoutType.ENGLISH) },



                    onSwitchToSymbols = { updateLayout(KeyboardLayoutType.SYMBOLS) },



                    onTranslateAction = { triggerTranslation() },



                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }



                )



            }







            KeyboardLayoutType.SYMBOLS -> {



                SymbolAndCurrencyPad(



                    onSymbolPress = handleSmartSymbolInput,



                    onSpace = handleSpaceKeyWithPeriodCheck,



                    onEmojiSwitch = { updateLayout(KeyboardLayoutType.EMOJI) },



                    onDelete = handleSingleDelete,



                    onLongDelete = handleLongDelete,



                    onReturnToKeyboard = { updateLayout(KeyboardLayoutType.CHINESE_9KEY) },



                    onEnter = { onPerformEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEND) }



                )



            }



        }



    }



}







/**



 * 顶部工具栏 (横向滚动条，保证在任何屏幕宽度下，打字切换、剪贴板、光标移动、复制剪切粘贴、语音、切换输入法全部完整可见且不被遮挡)



 */



@Composable



fun TopToolbar(



    isTranslateEnabled: Boolean,



    onToggleTranslate: (Boolean) -> Unit,



    currentMode: TranslationMode,



    onModeSelected: (TranslationMode) -> Unit,



    currentLayout: KeyboardLayoutType,



    onOpenClipboard: () -> Unit,



    onOpenEmoji: () -> Unit,



    isFuzzyEnabled: Boolean = true,



    onToggleFuzzy: (Boolean) -> Unit = {},



    onMoveCursorLeft: () -> Unit,



    onMoveCursorRight: () -> Unit,



    onCopy: () -> Unit,



    onCut: () -> Unit,



    onPaste: () -> Unit,



    onSwitchIme: () -> Unit



) {



    Row(



        modifier = Modifier



            .fillMaxWidth()



            .background(SogouTheme.ToolbarBg)



            .padding(horizontal = 4.dp, vertical = 4.dp)



            .horizontalScroll(rememberScrollState()),



        verticalAlignment = Alignment.CenterVertically,



        horizontalArrangement = Arrangement.spacedBy(6.dp)



    ) {



        // 1. 打字 / 翻译 核心模式切换开关



        Button(



            onClick = { onToggleTranslate(!isTranslateEnabled) },



            colors = ButtonDefaults.buttonColors(



                containerColor = if (isTranslateEnabled) SogouTheme.KeyOrange else SogouTheme.ToolbarBtnBg



            ),



            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),



            shape = RoundedCornerShape(6.dp),



            modifier = Modifier.height(30.dp)



        ) {



            Icon(



                Icons.Default.Translate,



                contentDescription = null,



                modifier = Modifier.size(13.dp),



                tint = if (isTranslateEnabled) Color.White else SogouTheme.TextPrimary



            )



            Spacer(modifier = Modifier.width(3.dp))



            Text(



                if (isTranslateEnabled) "AI翻译" else "普通打字",



                fontSize = 11.sp,



                fontWeight = FontWeight.Bold,



                color = if (isTranslateEnabled) Color.White else SogouTheme.TextPrimary



            )



        }







        // 搜狗式：Emoji 表情面板快捷按钮



        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(if (currentLayout == KeyboardLayoutType.EMOJI) SogouTheme.KeyOrange else SogouTheme.ToolbarBtnBg)



                .clickable { onOpenEmoji() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("😊", fontSize = 13.sp)



            Spacer(modifier = Modifier.width(3.dp))



            Text("表情", fontSize = 11.sp, color = if (currentLayout == KeyboardLayoutType.EMOJI) Color.White else SogouTheme.TextPrimary, fontWeight = FontWeight.Medium)



        }







        // 搜狗式：模糊拼音智能纠错开关胶囊



        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(if (isFuzzyEnabled) SogouTheme.KeyOrange else SogouTheme.ToolbarBtnBg)



                .clickable { onToggleFuzzy(!isFuzzyEnabled) }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text(if (isFuzzyEnabled) "模糊音:开" else "模糊音:关", fontSize = 11.sp, color = if (isFuzzyEnabled) Color.White else SogouTheme.TextPrimary, fontWeight = FontWeight.Medium)



        }







        // 2. 剪贴板按钮 (带文字标签与高亮)



        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(if (currentLayout == KeyboardLayoutType.CLIPBOARD) SogouTheme.KeyOrange else SogouTheme.ToolbarBtnBg)



                .clickable { onOpenClipboard() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Icon(Icons.Default.ContentPaste, contentDescription = "剪贴板", tint = if (currentLayout == KeyboardLayoutType.CLIPBOARD) Color.White else SogouTheme.TextPrimary, modifier = Modifier.size(13.dp))



            Spacer(modifier = Modifier.width(3.dp))



            Text("剪贴板", fontSize = 11.sp, color = if (currentLayout == KeyboardLayoutType.CLIPBOARD) Color.White else SogouTheme.TextPrimary, fontWeight = FontWeight.Medium)



        }







        // 3. 复制、剪切、粘贴 独立显眼按钮



        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(SogouTheme.ToolbarBtnBg)



                .clickable { onCopy() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("复制", fontSize = 11.sp, color = SogouTheme.TextPrimary, fontWeight = FontWeight.Medium)



        }







        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(SogouTheme.ToolbarBtnBg)



                .clickable { onCut() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("剪切", fontSize = 11.sp, color = SogouTheme.TextPrimary, fontWeight = FontWeight.Medium)



        }







        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(SogouTheme.ToolbarBtnBg)



                .clickable { onPaste() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("粘贴", fontSize = 11.sp, color = SogouTheme.KeyOrange, fontWeight = FontWeight.Bold)



        }







        // 4. 光标移动按键 (大号箭头，方便左右微调)



        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(SogouTheme.ToolbarBtnBg)



                .clickable { onMoveCursorLeft() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Icon(Icons.Default.ArrowBack, contentDescription = "光标左移", tint = Color.White, modifier = Modifier.size(14.dp))



            Text("光标左", fontSize = 10.sp, color = SogouTheme.TextSecondary)



        }







        Row(



            modifier = Modifier



                .height(30.dp)



                .clip(RoundedCornerShape(6.dp))



                .background(SogouTheme.ToolbarBtnBg)



                .clickable { onMoveCursorRight() }



                .padding(horizontal = 8.dp),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("光标右", fontSize = 10.sp, color = SogouTheme.TextSecondary)



            Icon(Icons.Default.ArrowForward, contentDescription = "光标右移", tint = Color.White, modifier = Modifier.size(14.dp))



        }











        // 6. 切换输入法地球图标



        IconButton(



            onClick = onSwitchIme,



            modifier = Modifier



                .size(30.dp)



                .background(SogouTheme.ToolbarBtnBg, CircleShape)



        ) {



            Icon(



                Icons.Default.Language,



                contentDescription = "切换输入法",



                tint = SogouTheme.KeyOrange,



                modifier = Modifier.size(15.dp)



            )



        }



    }



}







/**



 * 搜狗式常用 Emoji 与表情符号面板 (分类浏览：常用、表情手势、爱心生活、工作物品)



 */



@Composable



fun EmojiPanel(



    onSelectEmoji: (String) -> Unit,



    onDelete: () -> Unit,



    onClose: () -> Unit



) {



    var selectedCategory by remember { mutableStateOf(0) }



    val categories = listOf("常用表情", "手势动作", "爱心生活", "动物食物")







    val emojiList = when (selectedCategory) {



        0 -> listOf(



            "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",



            "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",



            "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩",



            "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "😣", "😖",



            "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯"



        )



        1 -> listOf(



            "👍", "👎", "👌", "🤌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙",



            "👈", "👉", "👆", "🖕", "👇", "☝️", "👋", "🤚", "🖐️", "✋",



            "🖖", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️", "💪", "🦾",



            "👂", "🦻", "👃", "👀", "👁️", "👅", "👄", "💋", "🫂", "👣"



        )



        2 -> listOf(



            "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔",



            "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️",



            "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐",



            "⭐", "🌟", "✨", "⚡", "☄️", "💥", "🔥", "🌈", "☀️", "🌙"



        )



        else -> listOf(



            "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯",



            "🦁", "🐮", "🐷", "🐸", "🐵", "🐔", "🐧", "🐦", "🐤", "🦆",



            "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍈",



            "☕", "🍵", "🧃", "🥤", "🧋", "🍺", "🍻", "🥂", "🍷", "🥃"



        )



    }







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .height(230.dp)



            .background(Color(0xFF181F2F))



            .padding(horizontal = 6.dp, vertical = 4.dp)



    ) {



        // 顶部操作栏



        Row(



            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),



            horizontalArrangement = Arrangement.SpaceBetween,



            verticalAlignment = Alignment.CenterVertically



        ) {



            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {



                categories.forEachIndexed { idx, cat ->



                    val isSel = selectedCategory == idx



                    Text(



                        text = cat,



                        fontSize = 11.sp,



                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,



                        color = if (isSel) Color.White else Color(0xFF94A3B8),



                        modifier = Modifier



                            .clip(RoundedCornerShape(4.dp))



                            .background(if (isSel) Color(0xFF0284C7) else Color(0xFF242E44))



                            .clickable { selectedCategory = idx }



                            .padding(horizontal = 8.dp, vertical = 4.dp)



                    )



                }



            }







            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {



                Box(



                    modifier = Modifier



                        .height(28.dp)



                        .clip(RoundedCornerShape(4.dp))



                        .background(SogouTheme.KeyActionBg)



                        .clickable { onDelete() }



                        .padding(horizontal = 8.dp),



                    contentAlignment = Alignment.Center



                ) {



                    Text("⌫ 退格", fontSize = 11.sp, color = Color.White)



                }







                Text(



                    text = "返回键盘 ❯",



                    fontSize = 11.sp,



                    fontWeight = FontWeight.Bold,



                    color = Color(0xFF38BDF8),



                    modifier = Modifier.clickable { onClose() }.padding(4.dp)



                )



            }



        }







        Spacer(modifier = Modifier.height(4.dp))







        // Emoji 5列瀑布流滚动网格



        LazyVerticalGrid(



            columns = GridCells.Fixed(8),



            modifier = Modifier.fillMaxSize(),



            horizontalArrangement = Arrangement.spacedBy(4.dp),



            verticalArrangement = Arrangement.spacedBy(4.dp)



        ) {



            items(emojiList) { emoji ->



                Box(



                    modifier = Modifier



                        .aspectRatio(1f)



                        .clip(RoundedCornerShape(6.dp))



                        .background(Color(0xFF242E44))



                        .clickable { onSelectEmoji(emoji) },



                    contentAlignment = Alignment.Center



                ) {



                    Text(emoji, fontSize = 20.sp)



                }



            }



        }



    }



}







/**



 * 剪贴板历史管理面板



 */



@Composable



fun ClipboardPanel(



    history: List<String>,



    onSelect: (String) -> Unit,



    onClose: () -> Unit



) {



    Column(



        modifier = Modifier



            .fillMaxWidth()



            .height(210.dp)



            .background(Color(0xFF181F2F))



            .padding(8.dp)



    ) {



        Row(



            modifier = Modifier.fillMaxWidth(),



            horizontalArrangement = Arrangement.SpaceBetween,



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text("📋 剪贴板历史 (点击直接粘贴上屏)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))



            IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {



                Icon(Icons.Default.Close, contentDescription = "关闭", tint = SogouTheme.TextSecondary, modifier = Modifier.size(16.dp))



            }



        }







        Spacer(modifier = Modifier.height(6.dp))







        if (history.isEmpty()) {



            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {



                Text("剪贴板当前为空，复制文本后将自动在此列出", fontSize = 12.sp, color = Color(0xFF64748B))



            }



        } else {



            Column(



                modifier = Modifier



                    .fillMaxSize()



                    .verticalScroll(rememberScrollState()),



                verticalArrangement = Arrangement.spacedBy(6.dp)



            ) {



                history.forEach { item ->



                    Box(



                        modifier = Modifier



                            .fillMaxWidth()



                            .clip(RoundedCornerShape(6.dp))



                            .background(Color(0xFF242E44))



                            .clickable { onSelect(item) }



                            .padding(horizontal = 10.dp, vertical = 8.dp)



                    ) {



                        Text(item, fontSize = 13.sp, color = SogouTheme.TextPrimary, maxLines = 3, overflow = TextOverflow.Ellipsis)



                    }



                }



            }



        }



    }



}







/**



 * 双栏预览条



 */



@Composable



fun DualPanePreviewBar(



    inputText: String,



    translatedText: String,



    detectedLanguage: String,



    translationNotes: String,



    isTranslating: Boolean,



    onTranslateClick: () -> Unit,



    onClearInput: () -> Unit,



    onCommit: () -> Unit



) {



    if (inputText.isBlank() && translatedText.isBlank()) {



        Box(



            modifier = Modifier



                .fillMaxWidth()



                .padding(horizontal = 8.dp, vertical = 2.dp)



                .background(Color(0xFF1B202E), RoundedCornerShape(8.dp))



                .padding(horizontal = 10.dp, vertical = 7.dp),



            contentAlignment = Alignment.CenterStart



        ) {



            Text(



                text = "💡 打完字后点击【翻译】即可调用 Gemini AI 互译...",



                color = SogouTheme.TextSecondary,



                fontSize = 12.sp



            )



        }



        return



    }







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .padding(horizontal = 6.dp, vertical = 2.dp)



            .background(Color(0xFF1B202E), RoundedCornerShape(8.dp))



            .padding(8.dp)



    ) {



        // 1. 原文行



        Row(



            modifier = Modifier.fillMaxWidth(),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text(



                text = "原文:",



                fontSize = 11.sp,



                fontWeight = FontWeight.Bold,



                color = Color(0xFF94A3B8),



                modifier = Modifier.width(36.dp)



            )



            Text(



                text = inputText,



                fontSize = 13.sp,



                color = SogouTheme.TextPrimary,



                maxLines = 1,



                overflow = TextOverflow.Ellipsis,



                modifier = Modifier.weight(1f)



            )







            IconButton(onClick = onClearInput, modifier = Modifier.size(22.dp)) {



                Icon(Icons.Default.Close, contentDescription = "清空", tint = Color(0xFF64748B), modifier = Modifier.size(14.dp))



            }







            Spacer(modifier = Modifier.width(4.dp))







            Button(



                onClick = onTranslateClick,



                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),



                shape = RoundedCornerShape(6.dp),



                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),



                modifier = Modifier.height(28.dp)



            ) {



                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color(0xFFFBBF24))



                Spacer(modifier = Modifier.width(3.dp))



                Text("翻译", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)



            }



        }







        Spacer(modifier = Modifier.height(4.dp))







        // 2. 译文行 + 一键上屏按钮



        Row(



            modifier = Modifier.fillMaxWidth(),



            verticalAlignment = Alignment.CenterVertically



        ) {



            Text(



                text = "译文:",



                fontSize = 11.sp,



                fontWeight = FontWeight.Bold,



                color = Color(0xFF10B981),



                modifier = Modifier.width(36.dp)



            )







            if (isTranslating) {



                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {



                    CircularProgressIndicator(



                        modifier = Modifier.size(12.dp),



                        color = Color(0xFF10B981),



                        strokeWidth = 2.dp



                    )



                    Spacer(modifier = Modifier.width(6.dp))



                    Text("AI 翻译中...", fontSize = 12.sp, color = Color(0xFF10B981))



                }



            } else {



                Text(



                    text = translatedText.ifEmpty { "输入完成后点右上方【翻译】" },



                    fontSize = 13.sp,



                    fontWeight = FontWeight.Bold,



                    color = if (translatedText.isNotEmpty()) Color(0xFF34D399) else Color(0xFF64748B),



                    maxLines = 2,



                    overflow = TextOverflow.Ellipsis,



                    modifier = Modifier.weight(1f)



                )



            }







            Spacer(modifier = Modifier.width(6.dp))







            Button(



                onClick = onCommit,



                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),



                shape = RoundedCornerShape(6.dp),



                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),



                modifier = Modifier.height(30.dp)



            ) {



                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(11.dp), tint = Color.White)



                Spacer(modifier = Modifier.width(4.dp))



                Text("上屏", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)



            }



        }



    }



}







/**



 * 拼音候选词条 (搜狗式固定一行 38dp 空间，有字显示候选列表，右侧带【⌄/⌃ 展开多行网格】按钮)



 */



@Composable



fun CandidateSelectionStrip(



    composingInfo: String,



    candidates: List<String>,



    isExpanded: Boolean,



    onToggleExpand: () -> Unit,



    onSelectCandidate: (String) -> Unit



) {



    Row(



        modifier = Modifier



            .fillMaxWidth()



            .height(38.dp)



            .background(SogouTheme.CandidateStripBg)



            .padding(horizontal = 4.dp, vertical = 2.dp),



        verticalAlignment = Alignment.CenterVertically



    ) {



        // 左侧横向滚动候选条



        Row(



            modifier = Modifier



                .weight(1f)



                .horizontalScroll(rememberScrollState()),



            verticalAlignment = Alignment.CenterVertically,



            horizontalArrangement = Arrangement.spacedBy(6.dp)



        ) {



            if (composingInfo.isNotBlank()) {



                Text(composingInfo, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SogouTheme.ComposingText)



            }







            if (candidates.isEmpty()) {



                Text(



                    text = "拼音候选词区 (左右滑动空格可挪动光标)",



                    color = SogouTheme.CandidateBorder,



                    fontSize = 12.sp



                )



            } else {



                candidates.forEachIndexed { index, cand ->



                    Box(



                        modifier = Modifier



                            .clip(RoundedCornerShape(5.dp))



                            .background(SogouTheme.ToolbarBtnBg)



                            .clickable { onSelectCandidate(cand) }



                            .padding(horizontal = 10.dp, vertical = 5.dp)



                    ) {



                        Text(



                            text = "${index + 1}. $cand",



                            fontSize = 14.sp,



                            fontWeight = FontWeight.Medium,



                            color = SogouTheme.TextPrimary



                        )



                    }



                }



            }



        }







        // 右侧网格展开按钮 (搜狗式下拉网格，一键展开全部同音字与词组)



        if (candidates.isNotEmpty()) {



            Box(



                modifier = Modifier



                    .size(34.dp)



                    .clip(RoundedCornerShape(5.dp))



                    .background(if (isExpanded) Color(0xFF0284C7) else Color(0xFF1E2536))



                    .clickable { onToggleExpand() },



                contentAlignment = Alignment.Center



            ) {



                Icon(



                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,



                    contentDescription = "展开候选词",



                    tint = Color.White,



                    modifier = Modifier.size(20.dp)



                )



            }



        }



    }



}







/**



 * 搜狗式 1:1 复刻候选词展开筛选面板



 * 结构：



 * - 左侧：拼音过滤垂直列 (kei, lei, ke, le, j) 点选立即过滤出当前读音全部单字与词组



 * - 中间：4 列大字号候选词主表格 (累、类、雷、垒、擂、蕾...)



 * - 右侧：功能控制侧栏 (返回/收起、⌫退格、重输清空、拼/笔分流)



 */



@Composable



fun ExpandedCandidatePanel(



    candidates: List<String>,



    pinyinFilters: List<String>,



    activeFilter: String?,



    onSelectFilter: (String) -> Unit,
    onResetFilter: () -> Unit,



    onSelectCandidate: (String) -> Unit,



    onDelete: () -> Unit,



    onClear: () -> Unit,



    onClose: () -> Unit



) {



    Row(



        modifier = Modifier



            .fillMaxWidth()



            .height(250.dp)



            .background(SogouTheme.ExpandedPanelBg)



            .padding(2.dp)



    ) {



        // 1. 左侧：拼音过滤垂直列 (kei, lei, ke, le, j 等)



        if (pinyinFilters.isNotEmpty()) {



            Column(



                modifier = Modifier



                    .width(62.dp)



                    .fillMaxHeight()



                    .background(Color(0xFFFFFFFF), RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))



                    .verticalScroll(rememberScrollState()),



                horizontalAlignment = Alignment.CenterHorizontally



            ) {



                pinyinFilters.forEach { filter ->



                    val isSelected = activeFilter == filter



                    Box(



                        modifier = Modifier



                            .fillMaxWidth()



                            .height(48.dp)



                            .background(if (isSelected) Color(0xFFE5E7EB) else Color.Transparent)



                            .clickable { onSelectFilter(filter) },



                        contentAlignment = Alignment.Center



                    ) {



                        Text(



                            text = filter,



                            fontSize = 14.sp,



                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,



                            color = if (isSelected) SogouTheme.KeyOrange else SogouTheme.TextPrimary



                        )



                    }



                }



            }



            Spacer(modifier = Modifier.width(2.dp))



        }







        // 2. 中间：4 列大字号候选词主网格



        Column(



            modifier = Modifier



                .weight(1f)



                .fillMaxHeight()



                .background(Color(0xFFFFFFFF), RoundedCornerShape(4.dp))



                .padding(horizontal = 4.dp, vertical = 2.dp)



        ) {



            if (candidates.isEmpty()) {



                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {



                    Text("无对应候选词", fontSize = 13.sp, color = Color(0xFF9CA3AF))



                }



            } else {



                LazyVerticalGrid(



                    columns = GridCells.Fixed(4),



                    modifier = Modifier.fillMaxSize(),



                    horizontalArrangement = Arrangement.spacedBy(4.dp),



                    verticalArrangement = Arrangement.spacedBy(4.dp)



                ) {



                    items(candidates) { cand ->



                        Box(



                            modifier = Modifier



                                .height(48.dp)



                                .clip(RoundedCornerShape(6.dp))



                                .background(Color(0xFFFFFFFF))



                                .clickable { onSelectCandidate(cand) },



                            contentAlignment = Alignment.Center



                        ) {



                            Text(



                                text = cand,



                                fontSize = 18.sp,



                                fontWeight = FontWeight.Normal,



                                color = Color(0xFF111827),



                                maxLines = 1,



                                overflow = TextOverflow.Ellipsis



                            )



                        }



                    }



                }



            }



        }







        Spacer(modifier = Modifier.width(2.dp))







        // 3. 右侧：搜狗式独立功能按键侧栏 (返回、⌫、重输、拼/笔)



        Column(



            modifier = Modifier



                .width(62.dp)



                .fillMaxHeight(),



            verticalArrangement = Arrangement.spacedBy(3.dp)



        ) {



            Box(



                modifier = Modifier



                    .fillMaxWidth()



                    .weight(1f)



                    .clip(RoundedCornerShape(6.dp))



                    .background(SogouTheme.KeyActionBg)



                    .clickable { onClose() },



                contentAlignment = Alignment.Center



            ) {



                Text("返回", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))



            }







            Box(



                modifier = Modifier



                    .fillMaxWidth()



                    .weight(1f)



                    .clip(RoundedCornerShape(6.dp))



                    .background(SogouTheme.KeyActionBg)



                    .clickable { onDelete() },



                contentAlignment = Alignment.Center



            ) {



                Text("⌫", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))



            }







            Box(



                modifier = Modifier



                    .fillMaxWidth()



                    .weight(1f)



                    .clip(RoundedCornerShape(6.dp))



                    .background(SogouTheme.KeyActionBg)



                    .clickable { onClear() },



                contentAlignment = Alignment.Center



            ) {



                Text("重输", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1F2937))



            }







            Box(



                modifier = Modifier



                    .fillMaxWidth()



                    .weight(1f)



                    .clip(RoundedCornerShape(6.dp))



                    .background(SogouTheme.KeyActionBg)



                    .clickable { onResetFilter() },



                contentAlignment = Alignment.Center



            ) {



                Column(horizontalAlignment = Alignment.CenterHorizontally) {



                    Text("全", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F2937))



                    Text("/字", fontSize = 9.sp, color = Color(0xFF6B7280))



                }



            }



        }



    }



}







/**



 * 越南语完整拼写字母直选扩展栏 (去除了多余的单独声调符号，全部直接提供带调的最终独立拼写字母)



 */



@Composable



fun VietnameseToneStrip(



    onAppendTone: (String) -> Unit



) {



    var selectedTab by remember { mutableStateOf(0) } // 0: A/Ă/Â族, 1: E/Ê族, 2: O/Ô/Ơ族, 3: U/Ư/I/Y族, 4: 特殊辅音(Đ)







    val tabs = listOf("A/Ă/Â", "E/Ê", "O/Ô/Ơ", "U/Ư/I/Y", "Đ")







    val aFamily = listOf(



        "a", "á", "à", "ả", "ã", "ạ",



        "ă", "ắ", "ằ", "ẳ", "ẵ", "ặ",



        "â", "ấ", "ầ", "ẩ", "ẫ", "ậ"



    )







    val eFamily = listOf(



        "e", "é", "è", "ẻ", "ẽ", "ẹ",



        "ê", "ế", "ề", "ể", "ễ", "ệ"



    )







    val oFamily = listOf(



        "o", "ó", "ò", "ỏ", "õ", "ọ",



        "ô", "ố", "ồ", "ổ", "ỗ", "ộ",



        "ơ", "ớ", "ờ", "ở", "ỡ", "ợ"



    )







    val uiyFamily = listOf(



        "u", "ú", "ù", "ủ", "ũ", "ụ",



        "ư", "ứ", "ừ", "ử", "ữ", "ự",



        "i", "í", "ì", "ỉ", "ĩ", "ị",



        "y", "ý", "ỳ", "ỷ", "ỹ", "ỵ"



    )







    val dFamily = listOf("đ", "Đ")







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .background(Color(0xFF141926))



            .padding(horizontal = 4.dp, vertical = 3.dp)



    ) {



        // 顶部母音族分类标签



        Row(



            modifier = Modifier



                .fillMaxWidth()



                .horizontalScroll(rememberScrollState()),



            horizontalArrangement = Arrangement.spacedBy(6.dp)



        ) {



            tabs.forEachIndexed { idx, tabTitle ->



                val isSelected = selectedTab == idx



                Text(



                    text = tabTitle,



                    fontSize = 12.sp,



                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,



                    color = if (isSelected) Color.White else Color(0xFF94A3B8),



                    modifier = Modifier



                        .clip(RoundedCornerShape(4.dp))



                        .background(if (isSelected) Color(0xFF0284C7) else Color(0xFF1E2536))



                        .clickable { selectedTab = idx }



                        .padding(horizontal = 10.dp, vertical = 4.dp)



                )



            }



        }







        Spacer(modifier = Modifier.height(4.dp))







        // 对应分类下的所有拼写字母列表 (横向平滑滚动，大字号、直接点选)



        Row(



            modifier = Modifier



                .fillMaxWidth()



                .horizontalScroll(rememberScrollState()),



            verticalAlignment = Alignment.CenterVertically,



            horizontalArrangement = Arrangement.spacedBy(6.dp)



        ) {



            val currentList = when (selectedTab) {



                0 -> aFamily



                1 -> eFamily



                2 -> oFamily



                3 -> uiyFamily



                else -> dFamily



            }







            currentList.forEach { letter ->



                Box(



                    modifier = Modifier



                        .size(36.dp)



                        .clip(RoundedCornerShape(6.dp))



                        .background(Color(0xFF26354D))



                        .clickable { onAppendTone(letter) },



                    contentAlignment = Alignment.Center



                ) {



                    Text(letter, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)



                }



            }



        }



    }



}







/**



 * ================= 中文九宫格 (T9) 键盘 =================



 */



@Composable



fun Chinese9KeyPad(



    isTranslateEnabled: Boolean,



    onDigitPress: (String) -> Unit,



    onPunctuationPress: (String) -> Unit,



    onSpace: () -> Unit,



    onMoveCursorLeft: () -> Unit,



    onMoveCursorRight: () -> Unit,



    onDelete: () -> Unit,



    onLongDelete: () -> Unit,



    onSwitchTo26: () -> Unit,



    onSwitchToEnglish: () -> Unit,



    onSwitchToVietnamese: () -> Unit,



    onSwitchToSymbols: () -> Unit,



    onTranslateAction: () -> Unit,



    onEnter: () -> Unit



) {



    Row(



        modifier = Modifier



            .fillMaxWidth()



            .padding(horizontal = 4.dp, vertical = 2.dp),



        horizontalArrangement = Arrangement.spacedBy(4.dp)



    ) {



        // 左列：快捷标点



        Column(



            modifier = Modifier.width(48.dp),



            verticalArrangement = Arrangement.spacedBy(4.dp)



        ) {



            listOf("，", "。", "？", "！").forEach { punc ->



                ActionKey(label = punc, modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                    onPunctuationPress(punc)



                }



            }



        }







        // 中间：3x3 九宫格数字键 + 底部辅助行



        Column(



            modifier = Modifier.weight(1f),



            verticalArrangement = Arrangement.spacedBy(4.dp)



        ) {



            val t9Keys = listOf(



                listOf("1" to "符/标点", "2" to "ABC", "3" to "DEF"),



                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),



                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ")



            )







            t9Keys.forEach { row ->



                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



                    row.forEach { (digit, letters) ->



                        Box(



                            modifier = Modifier



                                .weight(1f)



                                .height(48.dp)



                                .clip(RoundedCornerShape(7.dp))



                                .background(SogouTheme.KeyCharBg)



                                .clickable {



                                    if (digit == "1") onSwitchToSymbols()



                                    else onDigitPress(digit)



                                },



                            contentAlignment = Alignment.Center



                        ) {



                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {



                                Text(digit, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = SogouTheme.ComposingText)



                                Text(letters, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = SogouTheme.TextSecondary)



                            }



                        }



                    }



                }



            }







            // 底部辅助行



            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



                ActionKey(label = "全拼", modifier = Modifier.weight(1f).height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                    onSwitchTo26()



                }



                ActionKey(label = "英文", modifier = Modifier.weight(1f).height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                    onSwitchToEnglish()



                }



                SpaceBarKey(



                    label = "空格 (选词)",



                    modifier = Modifier.weight(2.2f).height(48.dp),



                    onClick = onSpace,



                    onMoveCursorLeft = onMoveCursorLeft,



                    onMoveCursorRight = onMoveCursorRight



                )



                ActionKey(label = "越语", modifier = Modifier.weight(1f).height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                    onSwitchToVietnamese()



                }



            }



        }







        // 右列：操作键 (退格长按整删、符号、换行、发送/翻译)



        Column(



            modifier = Modifier.width(54.dp),



            verticalArrangement = Arrangement.spacedBy(4.dp)



        ) {



            DeleteKey(



                modifier = Modifier.fillMaxWidth().height(48.dp),



                onClick = onDelete,



                onLongClick = onLongDelete



            )



            ActionKey(label = "?123", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                onSwitchToSymbols()



            }



            ActionKey(label = "换行", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = SogouTheme.KeyActionBg) {



                onPunctuationPress("\n")



            }



            if (isTranslateEnabled) {



                ActionKey(label = "翻译", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = SogouTheme.KeyOrange) {



                    onTranslateAction()



                }



            } else {



                ActionKey(label = "发送", modifier = Modifier.fillMaxWidth().height(48.dp), bgColor = SogouTheme.KeyOrange) {



                    onEnter()



                }



            }



        }



    }



}







/**



 * ================= QWERTY 键盘 (支持 中文26键全拼 与 纯英文键盘) =================



 */



@Composable



fun QwertyPad(



    layoutType: KeyboardLayoutType,



    isTranslateEnabled: Boolean,



    onCharPress: (String) -> Unit,



    onSpace: () -> Unit,



    onMoveCursorLeft: () -> Unit,



    onMoveCursorRight: () -> Unit,



    onDelete: () -> Unit,



    onLongDelete: () -> Unit,



    onSwitchTo9Key: () -> Unit,



    onSwitchToEnglish: () -> Unit,



    onSwitchToVietnamese: () -> Unit,



    onSwitchToSymbols: () -> Unit,



    onTranslateAction: () -> Unit,



    onEnter: () -> Unit



) {



    var isShifted by remember { mutableStateOf(false) }







    val row1Keys = listOf("Q" to "1", "W" to "2", "E" to "3", "R" to "4", "T" to "5", "Y" to "6", "U" to "7", "I" to "8", "O" to "9", "P" to "0")



    val row2Keys = listOf("A" to "!", "S" to "@", "D" to "#", "F" to "$", "G" to "%", "H" to "&", "J" to "*", "K" to "(", "L" to ")")



    val row3Keys = listOf("Z" to "-", "X" to "+", "C" to "=", "V" to "/", "B" to "_", "N" to ",", "M" to "?")







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .padding(horizontal = 4.dp, vertical = 2.dp),



        verticalArrangement = Arrangement.spacedBy(5.dp)



    ) {



        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



            row1Keys.forEach { (key, num) ->



                val display = if (isShifted) key else key.lowercase()



                SwipeableCharKey(



                    letter = display,



                    subSymbol = num,



                    modifier = Modifier.weight(1f).height(48.dp),



                    onClick = { onCharPress(display) },



                    onSwipeUp = { onCharPress(it) }



                )



            }



        }







        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



            row2Keys.forEach { (key, sym) ->



                val display = if (isShifted) key else key.lowercase()



                SwipeableCharKey(



                    letter = display,



                    subSymbol = sym,



                    modifier = Modifier.weight(1f).height(48.dp),



                    onClick = { onCharPress(display) },



                    onSwipeUp = { onCharPress(it) }



                )



            }



        }







        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



            ActionKey(



                label = if (isShifted) "⇧ 大写" else "⇧",



                modifier = Modifier.weight(1.4f).height(48.dp),



                bgColor = if (isShifted) Color(0xFF38BDF8) else Color(0xFF232938)



            ) {



                isShifted = !isShifted



            }



            row3Keys.forEach { (key, sym) ->



                val display = if (isShifted) key else key.lowercase()



                SwipeableCharKey(



                    letter = display,



                    subSymbol = sym,



                    modifier = Modifier.weight(1f).height(48.dp),



                    onClick = { onCharPress(display) },



                    onSwipeUp = { onCharPress(it) }



                )



            }



            DeleteKey(



                modifier = Modifier.weight(1.4f).height(48.dp),



                onClick = onDelete,



                onLongClick = onLongDelete



            )



        }







        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



            ActionKey(label = "?123", modifier = Modifier.weight(1.4f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToSymbols() }



            if (layoutType == KeyboardLayoutType.CHINESE_26KEY) {



                ActionKey(label = "九宫", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchTo9Key() }



                ActionKey(label = "英", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToEnglish() }



            } else {



                ActionKey(label = "中", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchTo9Key() }



                ActionKey(label = "越", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToVietnamese() }



            }



            SpaceBarKey(



                label = if (layoutType == KeyboardLayoutType.CHINESE_26KEY) "空格 (选词)" else "Space",



                modifier = Modifier.weight(3.5f).height(48.dp),



                onClick = onSpace,



                onMoveCursorLeft = onMoveCursorLeft,



                onMoveCursorRight = onMoveCursorRight



            )



            ActionKey(label = ".", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF2C3446)) { onCharPress(".") }



            if (isTranslateEnabled) {



                ActionKey(label = "翻译", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onTranslateAction() }



            } else {



                ActionKey(label = "发送", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onEnter() }



            }



        }



    }



}







/**



 * ================= 越南语原生键盘 =================



 */



@Composable



fun VietnameseNativePad(



    isTranslateEnabled: Boolean,



    onCharPress: (String) -> Unit,



    onSpace: () -> Unit,



    onDelete: () -> Unit,



    onLongDelete: () -> Unit,



    onSwitchToChinese: () -> Unit,



    onSwitchToEnglish: () -> Unit,



    onSwitchToSymbols: () -> Unit,



    onTranslateAction: () -> Unit,



    onEnter: () -> Unit



) {



    var isShifted by remember { mutableStateOf(false) }







    val row1 = listOf("Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "Ư", "Ơ")



    val row2 = listOf("A", "S", "D", "F", "G", "H", "J", "K", "L", "Đ", "Ê")



    val row3 = listOf("Z", "X", "C", "V", "B", "N", "M", "Ă", "Â", "Ô")







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .padding(horizontal = 2.dp, vertical = 2.dp),



        verticalArrangement = Arrangement.spacedBy(5.dp)



    ) {



        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {



            row1.forEach { key ->



                val display = if (isShifted) key else key.lowercase()



                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }



            }



        }







        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {



            row2.forEach { key ->



                val display = if (isShifted) key else key.lowercase()



                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }



            }



        }







        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {



            ActionKey(



                label = if (isShifted) "⇧ 大写" else "⇧",



                modifier = Modifier.weight(1.3f).height(48.dp),



                bgColor = if (isShifted) Color(0xFF38BDF8) else Color(0xFF232938)



            ) { isShifted = !isShifted }



            row3.forEach { key ->



                val display = if (isShifted) key else key.lowercase()



                CharKey(label = display, modifier = Modifier.weight(1f).height(48.dp)) { onCharPress(display) }



            }



            DeleteKey(



                modifier = Modifier.weight(1.3f).height(48.dp),



                onClick = onDelete,



                onLongClick = onLongDelete



            )



        }







        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {



            ActionKey(label = "?123", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToSymbols() }



            ActionKey(label = "中文", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToChinese() }



            ActionKey(label = "英文", modifier = Modifier.weight(1.2f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onSwitchToEnglish() }



            ActionKey(label = "Space", modifier = Modifier.weight(3.5f).height(48.dp), bgColor = Color(0xFF2C3446)) { onSpace() }



            ActionKey(label = ".", modifier = Modifier.weight(1f).height(48.dp), bgColor = Color(0xFF2C3446)) { onCharPress(".") }



            if (isTranslateEnabled) {



                ActionKey(label = "翻译", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onTranslateAction() }



            } else {



                ActionKey(label = "发送", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onEnter() }



            }



        }



    }



}







/**



 * ================= 全功能超全符号键盘 (?123 拥有 标点、货币、数学、特殊符号多分类选项卡) =================



 */



@Composable



fun SymbolAndCurrencyPad(



    onSymbolPress: (String) -> Unit,



    onSpace: () -> Unit,



    onDelete: () -> Unit,



    onLongDelete: () -> Unit,



    onReturnToKeyboard: () -> Unit,



    onEmojiSwitch: () -> Unit = {},



    onEnter: () -> Unit



) {



    var symbolCategory by remember { mutableStateOf(0) } // 0: 常用标点, 1: 货币金融, 2: 数学序号, 3: 特殊箭头/表情







    val categoryTabs = listOf("常用标点", "货币金融", "数学序号", "特殊与箭头")







    val symbolRows = when (symbolCategory) {



        0 -> listOf(



            listOf("，", "。", "！", "？", "：", "；", "、", "…", "—", "~"),



            listOf("“", "”", "‘", "’", "（", "）", "【", "】", "《", "》"),



            listOf("/", "\\", "|", "@", "#", "%", "&", "*", "_", "-"),



            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")



        )



        1 -> listOf(



            listOf("₫", "¥", "$", "€", "£", "₩", "HK$", "NT$", "฿", "₽"),



            listOf("₹", "元", "角", "分", "‰", "‱", "万", "亿", "K", "M"),



            listOf("+", "-", "×", "÷", "=", "≈", "≠", "≤", "≥", "%"),



            listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")



        )



        2 -> listOf(



            listOf("①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩"),



            listOf("⑴", "⑵", "⑶", "⑷", "⑸", "⒈", "⒉", "⒊", "⒋", "⒌"),



            listOf("√", "±", "×", "÷", "≠", "∞", "°", "℃", "℉", "π"),



            listOf("∑", "∏", "∫", "∮", "∠", "⊥", "△", "∵", "∴", "‰")



        )



        else -> listOf(



            listOf("→", "←", "↑", "↓", "↔", "↕", "⇒", "⇐", "⇑", "⇓"),



            listOf("✓", "✔", "✕", "✖", "★", "☆", "◆", "◇", "▲", "▼"),



            listOf("●", "○", "■", "□", "♥", "❤", "☺", "😊", "👍", "🙏"),



            listOf("•", "·", "°", "§", "¶", "※", "©", "®", "™", "№")



        )



    }







    Column(



        modifier = Modifier



            .fillMaxWidth()



            .padding(horizontal = 4.dp, vertical = 2.dp),



        verticalArrangement = Arrangement.spacedBy(4.dp)



    ) {



        // 符号分类选择 Tab



        Row(



            modifier = Modifier



                .fillMaxWidth()



                .padding(vertical = 2.dp),



            horizontalArrangement = Arrangement.spacedBy(4.dp)



        ) {



            categoryTabs.forEachIndexed { index, tabName ->



                Box(



                    modifier = Modifier



                        .weight(1f)



                        .height(30.dp)



                        .clip(RoundedCornerShape(6.dp))



                        .background(if (symbolCategory == index) Color(0xFF0284C7) else Color(0xFF1E2638))



                        .clickable { symbolCategory = index },



                    contentAlignment = Alignment.Center



                ) {



                    Text(



                        tabName,



                        fontSize = 11.sp,



                        fontWeight = if (symbolCategory == index) FontWeight.Bold else FontWeight.Normal,



                        color = if (symbolCategory == index) Color.White else Color(0xFF94A3B8)



                    )



                }



            }



        }







        // 符号网格按键



        symbolRows.forEach { row ->



            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



                row.forEach { sym ->



                    Box(



                        modifier = Modifier



                            .weight(1f)



                            .height(44.dp)



                            .clip(RoundedCornerShape(6.dp))



                            .background(



                                if (sym == "₫" || sym == "¥" || sym == "$" || sym == "€") Color(0xFF065F46)



                                else Color(0xFF283042)



                            )



                            .clickable { onSymbolPress(sym) },



                        contentAlignment = Alignment.Center



                    ) {



                        Text(



                            text = sym,



                            fontSize = 15.sp,



                            fontWeight = if (sym == "₫" || sym == "¥") FontWeight.Bold else FontWeight.Medium,



                            color = if (sym == "₫" || sym == "¥") Color(0xFF34D399) else Color.White



                        )



                    }



                }



            }



        }







        // 底部控制行 (含返回键盘、Emoji 表情、空格、退格整删与发送)



        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {



            ActionKey(label = "返回键盘", modifier = Modifier.weight(1.6f).height(48.dp), bgColor = SogouTheme.KeyActionBg) { onReturnToKeyboard() }



            ActionKey(label = "😊 表情", modifier = Modifier.weight(1.3f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onEmojiSwitch() }



            ActionKey(label = "空格 (双击出句号)", modifier = Modifier.weight(3.2f).height(48.dp), bgColor = Color(0xFF2C3446)) { onSpace() }



            DeleteKey(



                modifier = Modifier.weight(1.3f).height(48.dp),



                onClick = onDelete,



                onLongClick = onLongDelete



            )



            ActionKey(label = "发送", modifier = Modifier.weight(1.5f).height(48.dp), bgColor = SogouTheme.KeyOrange) { onEnter() }



        }



    }



}







/**



 * 支持单击与长按全部删除的删除键组件



 */



@OptIn(ExperimentalFoundationApi::class)



@Composable



fun DeleteKey(



    modifier: Modifier = Modifier,



    onClick: () -> Unit,



    onLongClick: () -> Unit



) {



    Box(



        modifier = modifier



            .clip(RoundedCornerShape(7.dp))



            .background(SogouTheme.KeyActionBg)



            .combinedClickable(



                onClick = onClick,



                onLongClick = onLongClick



            ),



        contentAlignment = Alignment.Center



    ) {



        Column(horizontalAlignment = Alignment.CenterHorizontally) {



            Text(text = "⌫", color = SogouTheme.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)



            Text(text = "长按整删", color = Color(0xFF94A3B8), fontSize = 8.sp)



        }



    }



}







/**



 * 搜狗式点划字符按键组件 (支持轻量上划输入对应数字/符号，常规点击输入字母)



 */



@Composable



fun SwipeableCharKey(



    letter: String,



    subSymbol: String = "",



    modifier: Modifier = Modifier,



    onClick: () -> Unit,



    onSwipeUp: (String) -> Unit



) {



    var dragOffsetY by remember { mutableStateOf(0f) }



    val swipeThreshold = -30f // 向上拖动超过 30 像素判定为上划







    Box(



        modifier = modifier



            .clip(RoundedCornerShape(7.dp))



            .background(SogouTheme.KeyCharBg)



            .pointerInput(letter, subSymbol) {



                detectDragGestures(



                    onDragStart = { dragOffsetY = 0f },



                    onDrag = { change, dragAmount ->



                        change.consume()



                        dragOffsetY += dragAmount.y



                    },



                    onDragEnd = {



                        if (subSymbol.isNotEmpty() && dragOffsetY <= swipeThreshold) {



                            onSwipeUp(subSymbol)



                        }



                        dragOffsetY = 0f



                    },



                    onDragCancel = { dragOffsetY = 0f }



                )



            }



            .clickable(onClick = onClick),



        contentAlignment = Alignment.Center



    ) {



        Column(



            horizontalAlignment = Alignment.CenterHorizontally,



            verticalArrangement = Arrangement.Center



        ) {



            if (subSymbol.isNotEmpty()) {



                Text(



                    text = subSymbol,



                    color = SogouTheme.TextSecondary,



                    fontSize = 9.sp,



                    fontWeight = FontWeight.Bold,



                    modifier = Modifier.padding(bottom = 1.dp)



                )



            }



            Text(



                text = letter,



                color = SogouTheme.TextPrimary,



                fontSize = 16.sp,



                fontWeight = FontWeight.SemiBold



            )



        }



    }



}







/**



 * 字符按键组件



 */



@Composable



fun CharKey(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {



    Box(



        modifier = modifier



            .clip(RoundedCornerShape(7.dp))



            .background(SogouTheme.KeyCharBg)



            .clickable(onClick = onClick),



        contentAlignment = Alignment.Center



    ) {



        Text(text = label, color = SogouTheme.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)



    }



}







/**



 * 空格键组件 (集成：单击上屏/输入空格、左右平滑滑动精准挪动光标)



 */



@Composable



fun SpaceBarKey(



    label: String,



    modifier: Modifier = Modifier,



    onClick: () -> Unit,



    onMoveCursorLeft: () -> Unit,



    onMoveCursorRight: () -> Unit



) {



    var accumulatedDrag by remember { mutableStateOf(0f) }



    val dragThreshold = 28f // 每拖动 28 像素移动一个字符光标







    Box(



        modifier = modifier



            .clip(RoundedCornerShape(7.dp))



            .background(SogouTheme.KeyCharBg)



            .pointerInput(Unit) {



                detectDragGestures(



                    onDragStart = { accumulatedDrag = 0f },



                    onDrag = { change, dragAmount ->



                        change.consume()



                        accumulatedDrag += dragAmount.x



                        if (accumulatedDrag >= dragThreshold) {



                            onMoveCursorRight()



                            accumulatedDrag = 0f



                        } else if (accumulatedDrag <= -dragThreshold) {



                            onMoveCursorLeft()



                            accumulatedDrag = 0f



                        }



                    }



                )



            }



            .clickable(onClick = onClick),



        contentAlignment = Alignment.Center



    ) {



        Column(horizontalAlignment = Alignment.CenterHorizontally) {



            Text(text = label, color = SogouTheme.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)



            Text(text = "↔ 滑动移光标", color = SogouTheme.TextSecondary, fontSize = 8.sp)



        }



    }



}







/**



 * 功能/操作按键组件



 */



@Composable



fun ActionKey(label: String, modifier: Modifier = Modifier, bgColor: Color, onClick: () -> Unit) {



    Box(



        modifier = modifier



            .clip(RoundedCornerShape(7.dp))



            .background(bgColor)



            .clickable(onClick = onClick),



        contentAlignment = Alignment.Center



    ) {



        Text(text = label, color = SogouTheme.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)



    }



}



