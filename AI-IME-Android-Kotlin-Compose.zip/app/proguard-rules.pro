# TransIME Proguard Rules
-keep class com.transime.ime.** { *; }
-dontwarn com.transime.ime.**
